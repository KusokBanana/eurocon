<?php

return [
    [
        'first_name' => 'Arch',
        'last_name' => 'Ryan',
        'avatar' => 'M02.png',
    ],
    [
        'first_name' => 'Dewayne',
        'last_name' => 'Klein',
        'avatar' => 'A01.png',
    ],
    [
        'first_name' => 'Tommie',
        'last_name' => 'McClure',
        'avatar' => 'L03.png',
    ],
    [
        'first_name' => 'Devante',
        'last_name' => 'Jenkins',
        'avatar' => 'E05.png',
    ],
    [
        'first_name' => 'Deion',
        'last_name' => 'King',
        'avatar' => 'N02.png',
    ],
    [
        'first_name' => 'Pierce',
        'last_name' => 'Beer',
        'avatar' => 'I04.png',
    ],
    [
        'first_name' => 'Ari',
        'last_name' => 'Weber',
        'avatar' => 'J04.png',
    ],
    [
        'first_name' => 'Fidel',
        'last_name' => 'Bartell',
        'avatar' => 'A02.png',
    ],
    [
        'first_name' => 'Hilton',
        'last_name' => 'Corkery',
        'avatar' => 'D04.png',
    ],
    [
        'first_name' => 'Darion',
        'last_name' => 'Dietrich',
        'avatar' => 'G03.png',
    ],
    [
        'first_name' => 'Oliver',
        'last_name' => 'Pollich',
        'avatar' => 'J05.png',
    ],
    [
        'first_name' => 'Sean',
        'last_name' => 'Leuschke',
        'avatar' => 'G02.png',
    ],
    [
        'first_name' => 'Cicero',
        'last_name' => 'Reinger',
        'avatar' => 'L05.png',
    ],
    [
        'first_name' => 'Bud',
        'last_name' => 'Pfannerstill',
        'avatar' => 'E03.png',
    ],
    [
        'first_name' => 'Elmore',
        'last_name' => 'Reynolds',
        'avatar' => 'A01.png',
    ],
    [
        'first_name' => 'Cristian',
        'last_name' => 'Ebert',
        'avatar' => 'L01.png',
    ],
    [
        'first_name' => 'Bernhard',
        'last_name' => 'Sanford',
        'avatar' => 'F01.png',
    ],
    [
        'first_name' => 'Walter',
        'last_name' => 'Harvey',
        'avatar' => 'O01.png',
    ],
    [
        'first_name' => 'Malachi',
        'last_name' => 'Lakin',
        'avatar' => 'G01.png',
    ],
    [
        'first_name' => 'Jairo',
        'last_name' => 'Ward',
        'avatar' => 'C04.png',
    ],
];
