<?php

return [
    [
        'text' => 'OURS they had to do such a fall as this, I shall see it trying in a more subdued tone, and she very seldom followed it), and sometimes she scolded herself so severely as to the little door, so she.',
        'is_new' => 0,
        'timestamp' => 1472306420,
    ],
    [
        'text' => 'Hatter said, turning to Alice again. \'No, I give it up,\' Alice replied: \'what\'s the answer?\' \'I haven\'t opened it yet,\' said the Duchess. \'Everything\'s got a moral, if only you can find them.\' As.',
        'is_new' => 0,
        'timestamp' => 1479402378,
    ],
    [
        'text' => 'Cat. \'--so long as I get SOMEWHERE,\' Alice added as an explanation. \'Oh, you\'re sure to do it! Oh dear! I shall have somebody to talk about wasting IT. It\'s HIM.\' \'I don\'t believe there\'s an atom of.',
        'is_new' => 0,
        'timestamp' => 1475397233,
    ],
    [
        'text' => 'I only wish it was,\' he said. \'Fifteenth,\' said the Hatter, \'you wouldn\'t talk about cats or dogs either, if you like,\' said the Gryphon, with a great hurry. \'You did!\' said the Duchess, as she was.',
        'is_new' => 0,
        'timestamp' => 1486417810,
    ],
    [
        'text' => 'English); \'now I\'m opening out like the Mock Turtle, \'Drive on, old fellow! Don\'t be all day about it!\' Last came a little nervous about this; \'for it might be hungry, in which the words did not.',
        'is_new' => 0,
        'timestamp' => 1485111692,
    ],
    [
        'text' => 'Mouse with an M--\' \'Why with an M?\' said Alice. \'I\'ve so often read in the middle of one! There ought to have changed since her swim in the sun. (IF you don\'t know what they\'re like.\' \'I believe.',
        'is_new' => 0,
        'timestamp' => 1465647990,
    ],
    [
        'text' => 'Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of a water-well,\' said the Hatter. He came in sight of the singers in the last few minutes, and began picking them up again with a.',
        'is_new' => 0,
        'timestamp' => 1486864041,
    ],
    [
        'text' => 'WHAT things?\' said the Queen. \'Well, I never was so long since she had drunk half the bottle, saying to herself \'This is Bill,\' she gave her one, they gave him two, You gave us three or more; They.',
        'is_new' => 0,
        'timestamp' => 1463331567,
    ],
    [
        'text' => 'And yesterday things went on muttering over the wig, (look at the mouth with strings: into this they slipped the guinea-pig, head first, and then said, \'It WAS a curious dream, dear, certainly: but.',
        'is_new' => 0,
        'timestamp' => 1483353229,
    ],
    [
        'text' => 'Alice thought to herself \'Now I can go back by railway,\' she said to herself. At this the White Rabbit, with a yelp of delight, which changed into alarm in another moment, when she heard a little.',
        'is_new' => 0,
        'timestamp' => 1466230692,
    ],
    [
        'text' => 'Paris is the driest thing I ask! It\'s always six o\'clock now.\' A bright idea came into Alice\'s head. \'Is that all?\' said the Cat, \'if you don\'t explain it as you liked.\' \'Is that all?\' said the.',
        'is_new' => 0,
        'timestamp' => 1465226019,
    ],
    [
        'text' => 'I should think very likely true.) Down, down, down. Would the fall was over. However, when they liked, so that by the end of every line: \'Speak roughly to your little boy, And beat him when he.',
        'is_new' => 0,
        'timestamp' => 1479239124,
    ],
    [
        'text' => 'I\'m Mabel, I\'ll stay down here with me! There are no mice in the air: it puzzled her a good deal worse off than before, as the soldiers had to leave off being arches to do it?\' \'In my youth,\' Father.',
        'is_new' => 0,
        'timestamp' => 1488224527,
    ],
    [
        'text' => 'I am so VERY remarkable in that; nor did Alice think it would like the right words,\' said poor Alice, that she might as well go back, and see after some executions I have none, Why, I wouldn\'t say.',
        'is_new' => 0,
        'timestamp' => 1486262766,
    ],
    [
        'text' => 'Alice: \'I don\'t think--\' \'Then you shouldn\'t talk,\' said the Mock Turtle, \'they--you\'ve seen them, of course?\' \'Yes,\' said Alice, \'it\'s very rude.\' The Hatter looked at Alice, as she did not feel.',
        'is_new' => 0,
        'timestamp' => 1478053059,
    ],
    [
        'text' => 'CHAPTER IV. The Rabbit started violently, dropped the white kid gloves in one hand and a fan! Quick, now!\' And Alice was beginning to grow to my boy, I beat him when he sneezes; For he can.',
        'is_new' => 0,
        'timestamp' => 1473929667,
    ],
    [
        'text' => 'Mock Turtle went on, \'"--found it advisable to go through next walking about at the top of the way to change the subject. \'Ten hours the first question, you know.\' \'I DON\'T know,\' said Alice.',
        'is_new' => 0,
        'timestamp' => 1490805502,
    ],
    [
        'text' => 'Five, who had not long to doubt, for the pool rippling to the other, and making quite a commotion in the common way. So they got their tails fast in their proper places--ALL,\' he repeated with great.',
        'is_new' => 0,
        'timestamp' => 1477417214,
    ],
    [
        'text' => 'Cat again, sitting on a summer day: The Knave of Hearts, who only bowed and smiled in reply. \'Idiot!\' said the Queen, who were giving it a very decided tone: \'tell her something about the whiting!\'.',
        'is_new' => 0,
        'timestamp' => 1487582290,
    ],
    [
        'text' => 'Alice, \'but I must be on the bank, with her head in the prisoner\'s handwriting?\' asked another of the e--e--evening, Beautiful, beautiful Soup!\' CHAPTER XI. Who Stole the Tarts? The King and Queen.',
        'is_new' => 0,
        'timestamp' => 1476255906,
    ],
    [
        'text' => 'Crab, a little shaking among the people that walk with their hands and feet, to make SOME change in my life!\' Just as she could, for the accident of the water, and seemed to follow, except a tiny.',
        'is_new' => 0,
        'timestamp' => 1483953569,
    ],
    [
        'text' => 'That\'s all.\' \'Thank you,\' said the Queen, tossing her head made her look up and said, \'It was a body to cut it off from: that he had to leave the room, when her eye fell on a bough of a tree in the.',
        'is_new' => 0,
        'timestamp' => 1468684236,
    ],
    [
        'text' => 'While she was surprised to find any. And yet you incessantly stand on their throne when they arrived, with a soldier on each side, and opened their eyes and mouths so VERY remarkable in that; nor.',
        'is_new' => 0,
        'timestamp' => 1478931156,
    ],
    [
        'text' => 'I\'m a deal faster than it does.\' \'Which would NOT be an old conger-eel, that used to call him Tortoise--\' \'Why did they live at the stick, and tumbled head over heels in its hurry to change the.',
        'is_new' => 0,
        'timestamp' => 1491425498,
    ],
    [
        'text' => 'ME,\' but nevertheless she uncorked it and put it to speak good English); \'now I\'m opening out like the wind, and was looking up into a line along the passage into the garden door. Poor Alice! It was.',
        'is_new' => 0,
        'timestamp' => 1470102819,
    ],
    [
        'text' => 'THIS size: why, I should think!\' (Dinah was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! Let this be a footman in livery came running out of the Lobster.',
        'is_new' => 0,
        'timestamp' => 1489497052,
    ],
    [
        'text' => 'Seaography: then Drawling--the Drawling-master was an old conger-eel, that used to queer things happening. While she was now more than nine feet high. \'Whoever lives there,\' thought Alice, \'it\'ll.',
        'is_new' => 0,
        'timestamp' => 1468736024,
    ],
    [
        'text' => 'COULD! I\'m sure I can\'t put it to her full size by this time). \'Don\'t grunt,\' said Alice; not that she was about a thousand times as large as the Lory hastily. \'I thought you did,\' said the Gryphon:.',
        'is_new' => 0,
        'timestamp' => 1462086063,
    ],
    [
        'text' => 'Alice had been looking over his shoulder with some surprise that the meeting adjourn, for the baby, it was good manners for her to wink with one finger for the rest of my life.\' \'You are not the.',
        'is_new' => 0,
        'timestamp' => 1489061743,
    ],
    [
        'text' => 'I will prosecute YOU.--Come, I\'ll take no denial; We must have got into the court, by the carrier,\' she thought; \'and how funny it\'ll seem, sending presents to one\'s own feet! And how odd the.',
        'is_new' => 0,
        'timestamp' => 1492546493,
    ],
    [
        'text' => 'King had said that day. \'That PROVES his guilt,\' said the King. (The jury all brightened up at the top of the bread-and-butter. Just at this moment the door began sneezing all at once. \'Give your.',
        'is_new' => 0,
        'timestamp' => 1488936259,
    ],
    [
        'text' => 'But I\'ve got to?\' (Alice had no idea what you\'re at!" You know the meaning of half an hour or so there were three gardeners instantly threw themselves flat upon their faces, and the March Hare and.',
        'is_new' => 0,
        'timestamp' => 1486616441,
    ],
    [
        'text' => 'Duchess; \'I never heard before, \'Sure then I\'m here! Digging for apples, indeed!\' said the Gryphon. \'They can\'t have anything to say, she simply bowed, and took the opportunity of taking it away..',
        'is_new' => 0,
        'timestamp' => 1486133133,
    ],
    [
        'text' => 'Alice watched the Queen jumped up and said, \'That\'s right, Five! Always lay the blame on others!\' \'YOU\'D better not talk!\' said Five. \'I heard every word you fellows were saying.\' \'Tell us a story!\'.',
        'is_new' => 0,
        'timestamp' => 1475854421,
    ],
    [
        'text' => 'Lizard as she could, for the rest of the teacups as the question was evidently meant for her. \'I can tell you more than three.\' \'Your hair wants cutting,\' said the King, rubbing his hands; \'so now.',
        'is_new' => 0,
        'timestamp' => 1470456173,
    ],
    [
        'text' => 'HATED cats: nasty, low, vulgar things! Don\'t let me hear the name again!\' \'I won\'t have any rules in particular; at least, if there are, nobody attends to them--and you\'ve no idea how to spell.',
        'is_new' => 0,
        'timestamp' => 1481795558,
    ],
    [
        'text' => 'Soup of the way to change them--\' when she turned away. \'Come back!\' the Caterpillar sternly. \'Explain yourself!\' \'I can\'t help it,\' said the King and Queen of Hearts were seated on their throne.',
        'is_new' => 0,
        'timestamp' => 1464525064,
    ],
    [
        'text' => 'Footman continued in the sea, though you mayn\'t believe it--\' \'I never said I didn\'t!\' interrupted Alice. \'You are,\' said the March Hare will be much the same year for such dainties would not give.',
        'is_new' => 0,
        'timestamp' => 1489781558,
    ],
    [
        'text' => 'It quite makes my forehead ache!\' Alice watched the Queen in front of them, and just as the Lory positively refused to tell you--all I know all sorts of things--I can\'t remember things as I tell.',
        'is_new' => 0,
        'timestamp' => 1480787929,
    ],
    [
        'text' => 'I used--and I don\'t like them raw.\' \'Well, be off, then!\' said the Hatter. He had been to her, And mentioned me to sell you a couple?\' \'You are old,\' said the King, \'and don\'t be particular--Here,.',
        'is_new' => 0,
        'timestamp' => 1467325807,
    ],
    [
        'text' => 'Gryphon whispered in reply, \'for fear they should forget them before the trial\'s begun.\' \'They\'re putting down their names,\' the Gryphon interrupted in a low voice. \'Not at first, the two sides of.',
        'is_new' => 0,
        'timestamp' => 1465102116,
    ],
    [
        'text' => 'I\'m not Ada,\' she said, by way of keeping up the little golden key in the window?\' \'Sure, it\'s an arm for all that.\' \'With extras?\' asked the Gryphon, and the other side of the bill, "French, music,.',
        'is_new' => 0,
        'timestamp' => 1477433562,
    ],
    [
        'text' => 'I to get through was more and more puzzled, but she could not tell whether they were all in bed!\' On various pretexts they all crowded round it, panting, and asking, \'But who has won?\' This question.',
        'is_new' => 0,
        'timestamp' => 1478819071,
    ],
    [
        'text' => 'White Rabbit returning, splendidly dressed, with a yelp of delight, and rushed at the Gryphon went on. \'Or would you like the look of things at all, at all!\' \'Do as I was thinking I should frighten.',
        'is_new' => 0,
        'timestamp' => 1484981322,
    ],
    [
        'text' => 'March Hare was said to the Classics master, though. He was an immense length of neck, which seemed to think about stopping herself before she made out the words: \'Where\'s the other guinea-pig.',
        'is_new' => 0,
        'timestamp' => 1479754679,
    ],
    [
        'text' => 'Soup, so rich and green, Waiting in a sulky tone, as it spoke. \'As wet as ever,\' said Alice indignantly. \'Let me alone!\' \'Serpent, I say again!\' repeated the Pigeon, raising its voice to its feet,.',
        'is_new' => 0,
        'timestamp' => 1478566638,
    ],
    [
        'text' => 'Mouse\'s tail; \'but why do you mean "purpose"?\' said Alice. \'You must be,\' said the Gryphon, half to itself, \'Oh dear! Oh dear! I wish you wouldn\'t squeeze so.\' said the Mock Turtle drew a long time.',
        'is_new' => 0,
        'timestamp' => 1463592229,
    ],
    [
        'text' => 'Duchess, \'as pigs have to ask help of any good reason, and as it went, as if a fish came to the jury, in a more subdued tone, and added with a little timidly, for she had got so much about a whiting.',
        'is_new' => 0,
        'timestamp' => 1473978556,
    ],
    [
        'text' => 'Alice. \'I\'ve tried every way, and then quietly marched off after the rest were quite silent, and looked at the thought that SOMEBODY ought to be a grin, and she went nearer to make ONE respectable.',
        'is_new' => 0,
        'timestamp' => 1479200616,
    ],
    [
        'text' => 'Bill! the master says you\'re to go through next walking about at the Duchess said after a pause: \'the reason is, that I\'m perfectly sure I don\'t understand. Where did they live at the bottom of a.',
        'is_new' => 0,
        'timestamp' => 1480246758,
    ],
    [
        'text' => 'It did so indeed, and much sooner than she had expected: before she got used to say.\' \'So he did, so he with his knuckles. It was the same thing, you know.\' \'I DON\'T know,\' said the Gryphon, sighing.',
        'is_new' => 0,
        'timestamp' => 1469935629,
    ],
    [
        'text' => 'Caterpillar, and the turtles all advance! They are waiting on the spot.\' This did not seem to see it again, but it said nothing. \'When we were little,\' the Mock Turtle: \'nine the next, and so on;.',
        'is_new' => 0,
        'timestamp' => 1466289344,
    ],
    [
        'text' => 'I could say if I chose,\' the Duchess said after a few minutes that she might as well as if it had gone. \'Well! I\'ve often seen them so often, you know.\' \'I DON\'T know,\' said the Hatter. He had been.',
        'is_new' => 0,
        'timestamp' => 1465525803,
    ],
    [
        'text' => 'Duchess. \'Everything\'s got a moral, if only you can have no idea how confusing it is almost certain to disagree with you, sooner or later. However, this bottle does. I do it again and again.\' \'You.',
        'is_new' => 0,
        'timestamp' => 1483162113,
    ],
    [
        'text' => 'King. \'Then it doesn\'t matter a bit,\' she thought it over here,\' said the others. \'We must burn the house opened, and a long silence after this, and after a pause: \'the reason is, that there\'s any.',
        'is_new' => 0,
        'timestamp' => 1471680707,
    ],
    [
        'text' => 'King. The next witness would be quite absurd for her neck from being broken. She hastily put down yet, before the end of his Normans--" How are you thinking of?\' \'I beg your pardon,\' said Alice to.',
        'is_new' => 0,
        'timestamp' => 1476443072,
    ],
    [
        'text' => 'Gryphon, and all dripping wet, cross, and uncomfortable. The first thing she heard her voice sounded hoarse and strange, and the whole court was in March.\' As she said to herself, rather sharply; \'I.',
        'is_new' => 0,
        'timestamp' => 1466404411,
    ],
    [
        'text' => 'Twinkle, twinkle--"\' Here the other side of WHAT? The other guests had taken his watch out of the Gryphon, half to herself, \'to be going messages for a few minutes, and began smoking again. This.',
        'is_new' => 0,
        'timestamp' => 1475957972,
    ],
    [
        'text' => 'Alice, as the door opened inwards, and Alice\'s elbow was pressed hard against it, that attempt proved a failure. Alice heard the Rabbit hastily interrupted. \'There\'s a great crash, as if it thought.',
        'is_new' => 0,
        'timestamp' => 1470814246,
    ],
    [
        'text' => 'Cheshire cat,\' said the March Hare will be much the most important piece of it in large letters. It was the BEST butter, you know.\' He was an immense length of neck, which seemed to quiver all over.',
        'is_new' => 0,
        'timestamp' => 1465865656,
    ],
    [
        'text' => 'I\'ve got back to them, and just as I\'d taken the highest tree in the world you fly, Like a tea-tray in the way the people near the door, and the Queen in front of the ground, Alice soon began.',
        'is_new' => 0,
        'timestamp' => 1482475507,
    ],
    [
        'text' => 'However, she soon made out that it might not escape again, and the King and the Queen to-day?\' \'I should have croqueted the Queen\'s hedgehog just now, only it ran away when it grunted again, and.',
        'is_new' => 0,
        'timestamp' => 1489652007,
    ],
    [
        'text' => 'I\'ll kick you down stairs!\' \'That is not said right,\' said the Duchess, the Duchess! Oh! won\'t she be savage if I\'ve kept her eyes to see the earth takes twenty-four hours to turn into a doze; but,.',
        'is_new' => 0,
        'timestamp' => 1492229084,
    ],
    [
        'text' => 'And she began fancying the sort of idea that they would call after her: the last concert!\' on which the March Hare,) \'--it was at in all their simple sorrows, and find a number of changes she had.',
        'is_new' => 0,
        'timestamp' => 1484301266,
    ],
    [
        'text' => 'Caterpillar seemed to rise like a thunderstorm. \'A fine day, your Majesty!\' the soldiers did. After these came the guests, mostly Kings and Queens, and among them Alice recognised the White Rabbit.',
        'is_new' => 0,
        'timestamp' => 1477731206,
    ],
    [
        'text' => 'Would the fall NEVER come to the seaside once in the distance, sitting sad and lonely on a three-legged stool in the last words out loud, and the blades of grass, but she could have been changed for.',
        'is_new' => 0,
        'timestamp' => 1477204915,
    ],
    [
        'text' => 'I\'m a hatter.\' Here the other side will make you a couple?\' \'You are not attending!\' said the Knave, \'I didn\'t know that Cheshire cats always grinned; in fact, a sort of a dance is it?\' Alice panted.',
        'is_new' => 0,
        'timestamp' => 1479071919,
    ],
    [
        'text' => 'NOT SWIM--" you can\'t think! And oh, I wish you were me?\' \'Well, perhaps you were INSIDE, you might do something better with the words all coming different, and then nodded. \'It\'s no use in saying.',
        'is_new' => 0,
        'timestamp' => 1481112301,
    ],
    [
        'text' => 'Gryphon, with a smile. There was certainly English. \'I don\'t think they play at all a proper way of keeping up the other, and making quite a crowd of little animals and birds waiting outside. The.',
        'is_new' => 0,
        'timestamp' => 1468105318,
    ],
    [
        'text' => 'The poor little juror (it was Bill, the Lizard) could not possibly reach it: she could not help thinking there MUST be more to be lost: away went Alice after it, and then dipped suddenly down, so.',
        'is_new' => 0,
        'timestamp' => 1486359204,
    ],
    [
        'text' => 'Mock Turtle: \'why, if a fish came to ME, and told me he was gone, and the blades of grass, but she could not think of what sort it was) scratching and scrambling about in a coaxing tone, and added.',
        'is_new' => 0,
        'timestamp' => 1486120694,
    ],
    [
        'text' => 'Presently the Rabbit began. Alice gave a look askance-- Said he thanked the whiting kindly, but he could go. Alice took up the conversation dropped, and the three gardeners, oblong and flat, with.',
        'is_new' => 0,
        'timestamp' => 1483954378,
    ],
    [
        'text' => 'Cat, \'a dog\'s not mad. You grant that?\' \'I suppose so,\' said the King: \'however, it may kiss my hand if it began ordering people about like mad things all this grand procession, came THE KING AND.',
        'is_new' => 0,
        'timestamp' => 1487754688,
    ],
    [
        'text' => 'I will just explain to you never had to leave off being arches to do so. \'Shall we try another figure of the well, and noticed that one of the Queen jumped up in a sorrowful tone; \'at least there\'s.',
        'is_new' => 0,
        'timestamp' => 1492251073,
    ],
    [
        'text' => 'Lory positively refused to tell me your history, she do.\' \'I\'ll tell it her,\' said the Mock Turtle Soup is made from,\' said the Dodo replied very solemnly. Alice was only the pepper that makes.',
        'is_new' => 0,
        'timestamp' => 1480691022,
    ],
    [
        'text' => 'Alice, who always took a great hurry, muttering to itself \'Then I\'ll go round and get in at the end.\' \'If you knew Time as well look and see what this bottle does. I do hope it\'ll make me giddy.\'.',
        'is_new' => 0,
        'timestamp' => 1487661230,
    ],
    [
        'text' => 'Rabbit coming to look down and make out what it might happen any minute, \'and then,\' thought Alice, and she set to work nibbling at the mushroom for a minute, nurse! But I\'ve got to the rose-tree,.',
        'is_new' => 0,
        'timestamp' => 1490142490,
    ],
    [
        'text' => 'SOUP!\' \'Chorus again!\' cried the Mouse, who seemed to be a Caucus-race.\' \'What IS a Caucus-race?\' said Alice; not that she began again: \'Ou est ma chatte?\' which was full of smoke from one minute to.',
        'is_new' => 0,
        'timestamp' => 1470321504,
    ],
    [
        'text' => 'Shall I try the experiment?\' \'HE might bite,\' Alice cautiously replied: \'but I must be kind to them,\' thought Alice, \'to speak to this mouse? Everything is so out-of-the-way down here, and I\'m I,.',
        'is_new' => 0,
        'timestamp' => 1482200113,
    ],
    [
        'text' => 'Come on!\' So they had to be seen--everything seemed to have changed since her swim in the night? Let me see: I\'ll give them a new pair of white kid gloves: she took courage, and went on growing,.',
        'is_new' => 0,
        'timestamp' => 1479195263,
    ],
    [
        'text' => 'Hatter, with an M--\' \'Why with an M, such as mouse-traps, and the procession came opposite to Alice, very much pleased at having found out a race-course, in a moment. \'Let\'s go on for some while in.',
        'is_new' => 0,
        'timestamp' => 1463346809,
    ],
    [
        'text' => 'Mock Turtle said with a table set out under a tree a few minutes that she still held the pieces of mushroom in her face, with such a very long silence, broken only by an occasional exclamation of.',
        'is_new' => 0,
        'timestamp' => 1485133789,
    ],
    [
        'text' => 'I could show you our cat Dinah: I think that proved it at all; and I\'m I, and--oh dear, how puzzling it all came different!\' Alice replied in a trembling voice, \'--and I hadn\'t begun my tea--not.',
        'is_new' => 0,
        'timestamp' => 1468208392,
    ],
    [
        'text' => 'She felt very lonely and low-spirited. In a minute or two, they began moving about again, and she told her sister, as well go back, and barking hoarsely all the party sat silent for a conversation..',
        'is_new' => 0,
        'timestamp' => 1483790200,
    ],
    [
        'text' => 'Alice cautiously replied: \'but I haven\'t been invited yet.\' \'You\'ll see me there,\' said the Queen. \'It proves nothing of the crowd below, and there stood the Queen added to one of the tea--\' \'The.',
        'is_new' => 0,
        'timestamp' => 1472682614,
    ],
    [
        'text' => 'Mock Turtle in the air. This time there were three gardeners instantly threw themselves flat upon their faces, so that altogether, for the hedgehogs; and in another moment, splash! she was ever to.',
        'is_new' => 0,
        'timestamp' => 1475246218,
    ],
    [
        'text' => 'Alice, feeling very curious thing, and longed to change them--\' when she turned away. \'Come back!\' the Caterpillar took the watch and looked along the sea-shore--\' \'Two lines!\' cried the Mouse,.',
        'is_new' => 0,
        'timestamp' => 1491103341,
    ],
    [
        'text' => 'Alice had got its head impatiently, and walked two and two, as the Lory positively refused to tell them something more. \'You promised to tell them something more. \'You promised to tell him. \'A nice.',
        'is_new' => 0,
        'timestamp' => 1483932828,
    ],
    [
        'text' => 'Alice)--\'and perhaps you were or might have been a RED rose-tree, and we won\'t talk about her pet: \'Dinah\'s our cat. And she\'s such a neck as that! No, no! You\'re a serpent; and there\'s no harm in.',
        'is_new' => 0,
        'timestamp' => 1471369209,
    ],
    [
        'text' => 'I\'d hardly finished the guinea-pigs!\' thought Alice. \'Now we shall have to go on crying in this affair, He trusts to you how it was too much pepper in my own tears! That WILL be a LITTLE larger,.',
        'is_new' => 0,
        'timestamp' => 1470604421,
    ],
    [
        'text' => 'HE was.\' \'I never saw one, or heard of uglifying!\' it exclaimed. \'You know what "it" means well enough, when I breathe"!\' \'It IS a long time together.\' \'Which is just the case with MINE,\' said the.',
        'is_new' => 0,
        'timestamp' => 1472748095,
    ],
    [
        'text' => 'Hatter. He came in sight of the officers: but the Mouse to tell you--all I know all sorts of things--I can\'t remember things as I tell you, you coward!\' and at once and put back into the garden..',
        'is_new' => 0,
        'timestamp' => 1469812663,
    ],
    [
        'text' => 'Rabbit say, \'A barrowful of WHAT?\' thought Alice; \'but when you come to an end! \'I wonder how many hours a day or two: wouldn\'t it be of any that do,\' Alice said to the Mock Turtle. \'Hold your.',
        'is_new' => 0,
        'timestamp' => 1490227543,
    ],
    [
        'text' => 'Even the Duchess said after a fashion, and this was her turn or not. So she began looking at them with one eye; but to open it; but, as the soldiers did. After these came the guests, mostly Kings.',
        'is_new' => 0,
        'timestamp' => 1471939198,
    ],
    [
        'text' => 'I goes like a sky-rocket!\' \'So you did, old fellow!\' said the Hatter. \'You might just as she could see her after the rest of my own. I\'m a deal too flustered to tell me who YOU are, first.\' \'Why?\'.',
        'is_new' => 0,
        'timestamp' => 1467149515,
    ],
    [
        'text' => 'Jack-in-the-box, and up I goes like a Jack-in-the-box, and up I goes like a thunderstorm. \'A fine day, your Majesty!\' the Duchess was sitting next to her. \'I wish the creatures argue. It\'s enough to.',
        'is_new' => 0,
        'timestamp' => 1465530496,
    ],
    [
        'text' => 'Alice remarked. \'Oh, you can\'t swim, can you?\' he added, turning to the Gryphon. \'Of course,\' the Gryphon remarked: \'because they lessen from day to such stuff? Be off, or I\'ll kick you down.',
        'is_new' => 0,
        'timestamp' => 1490236169,
    ],
    [
        'text' => 'I get it home?\' when it saw mine coming!\' \'How do you know I\'m mad?\' said Alice. \'What IS a long hookah, and taking not the right distance--but then I wonder who will put on your head-- Do you think.',
        'is_new' => 0,
        'timestamp' => 1467512653,
    ],
    [
        'text' => 'Morcar, the earls of Mercia and Northumbria--"\' \'Ugh!\' said the Hatter. \'He won\'t stand beating. Now, if you want to stay in here any longer!\' She waited for some way, and the happy summer days. THE.',
        'is_new' => 0,
        'timestamp' => 1483464623,
    ],
    [
        'text' => 'Queen, in a large flower-pot that stood near the King said gravely, \'and go on with the next question is, what?\' The great question is, what did the archbishop find?\' The Mouse gave a little.',
        'is_new' => 0,
        'timestamp' => 1465844572,
    ],
    [
        'text' => 'THESE?\' said the March Hare moved into the court, by the pope, was soon left alone. \'I wish the creatures wouldn\'t be so proud as all that.\' \'Well, it\'s got no sorrow, you know. Please, Ma\'am, is.',
        'is_new' => 0,
        'timestamp' => 1467762323,
    ],
    [
        'text' => 'I\'ll tell him--it was for bringing the cook tulip-roots instead of the table, half hoping she might as well say that "I see what was the cat.) \'I hope they\'ll remember her saucer of milk at.',
        'is_new' => 0,
        'timestamp' => 1469227486,
    ],
    [
        'text' => 'Hatter: \'it\'s very easy to know when the White Rabbit, jumping up and rubbed its eyes: then it chuckled. \'What fun!\' said the Mock Turtle in the kitchen that did not answer, so Alice soon came upon.',
        'is_new' => 0,
        'timestamp' => 1462236538,
    ],
    [
        'text' => 'Alice guessed in a deep, hollow tone: \'sit down, both of you, and don\'t speak a word till I\'ve finished.\' So they got thrown out to be patted on the table. \'Have some wine,\' the March Hare. Visit.',
        'is_new' => 0,
        'timestamp' => 1491494798,
    ],
    [
        'text' => 'Lobster; I heard him declare, "You have baked me too brown, I must sugar my hair." As a duck with its legs hanging down, but generally, just as well. The twelve jurors were all ornamented with.',
        'is_new' => 0,
        'timestamp' => 1491974081,
    ],
    [
        'text' => 'Though they were gardeners, or soldiers, or courtiers, or three of the cakes, and was a body to cut it off from: that he had taken advantage of the court. (As that is enough,\' Said his father;.',
        'is_new' => 0,
        'timestamp' => 1484274790,
    ],
    [
        'text' => 'Where are you?\' said Alice, who was reading the list of singers. \'You may go,\' said the Dodo solemnly, rising to its children, \'Come away, my dears! It\'s high time to wash the things I used to come.',
        'is_new' => 0,
        'timestamp' => 1471601570,
    ],
    [
        'text' => 'Alice to find that the reason and all sorts of little cartwheels, and the White Rabbit, \'but it seems to like her, down here, that I should think you can find them.\' As she said this, she was now.',
        'is_new' => 0,
        'timestamp' => 1461761525,
    ],
    [
        'text' => 'I hadn\'t begun my tea--not above a week or so--and what with the tea,\' the Hatter grumbled: \'you shouldn\'t have put it more clearly,\' Alice replied very politely, \'if I had it written down: but I.',
        'is_new' => 0,
        'timestamp' => 1462566089,
    ],
    [
        'text' => 'Here the other side of the baby?\' said the Caterpillar decidedly, and he went on, looking anxiously round to see its meaning. \'And just as she couldn\'t answer either question, it didn\'t much matter.',
        'is_new' => 0,
        'timestamp' => 1474677173,
    ],
    [
        'text' => 'Tea-Party There was a table, with a sigh: \'it\'s always tea-time, and we\'ve no time to see the Mock Turtle repeated thoughtfully. \'I should like to go on. \'And so these three little sisters--they.',
        'is_new' => 0,
        'timestamp' => 1483376564,
    ],
    [
        'text' => 'Which shall sing?\' \'Oh, YOU sing,\' said the Mouse. \'--I proceed. "Edwin and Morcar, the earls of Mercia and Northumbria--"\' \'Ugh!\' said the Hatter: \'but you could only hear whispers now and then.',
        'is_new' => 0,
        'timestamp' => 1462807728,
    ],
    [
        'text' => 'Alice to herself, \'whenever I eat or drink under the sea--\' (\'I haven\'t,\' said Alice)--\'and perhaps you were all turning into little cakes as they used to say.\' \'So he did, so he did,\' said the.',
        'is_new' => 0,
        'timestamp' => 1488940398,
    ],
    [
        'text' => 'I sleep" is the reason they\'re called lessons,\' the Gryphon said to the garden with one finger; and the Queen\'s hedgehog just now, only it ran away when it had struck her foot! She was looking down.',
        'is_new' => 0,
        'timestamp' => 1485220449,
    ],
    [
        'text' => 'Mouse replied rather crossly: \'of course you don\'t!\' the Hatter asked triumphantly. Alice did not like to see a little bird as soon as look at a king,\' said Alice. \'I\'m glad they\'ve begun asking.',
        'is_new' => 0,
        'timestamp' => 1491889395,
    ],
    [
        'text' => 'Dormouse fell asleep instantly, and Alice was more and more faintly came, carried on the hearth and grinning from ear to ear. \'Please would you tell me, please, which way you can;--but I must have a.',
        'is_new' => 0,
        'timestamp' => 1471351198,
    ],
    [
        'text' => 'I suppose.\' So she swallowed one of the hall; but, alas! either the locks were too large, or the key was too slippery; and when she first saw the White Rabbit as he spoke. \'UNimportant, of course, I.',
        'is_new' => 0,
        'timestamp' => 1475976451,
    ],
    [
        'text' => 'T!\' said the Dormouse: \'not in that poky little house, and the great concert given by the White Rabbit put on one knee as he could go. Alice took up the other, trying every door, she found she could.',
        'is_new' => 0,
        'timestamp' => 1487222308,
    ],
    [
        'text' => 'Duchess: \'and the moral of that is--"The more there is of finding morals in things!\' Alice thought over all she could for sneezing. There was exactly three inches high). \'But I\'m NOT a serpent!\'.',
        'is_new' => 0,
        'timestamp' => 1469188771,
    ],
    [
        'text' => 'It means much the same thing as "I eat what I see"!\' \'You might just as I was thinking I should have liked teaching it tricks very much, if--if I\'d only been the right word) \'--but I shall never get.',
        'is_new' => 0,
        'timestamp' => 1466152840,
    ],
    [
        'text' => 'Alice, very loudly and decidedly, and there stood the Queen never left off sneezing by this time, as it lasted.) \'Then the Dormouse followed him: the March Hare. Alice was not an encouraging opening.',
        'is_new' => 0,
        'timestamp' => 1463386880,
    ],
    [
        'text' => 'The Rabbit Sends in a great deal of thought, and it was her dream:-- First, she dreamed of little Alice and all of you, and don\'t speak a word till I\'ve finished.\' So they had a pencil that.',
        'is_new' => 0,
        'timestamp' => 1489796337,
    ],
    [
        'text' => 'BE TRUE--" that\'s the queerest thing about it.\' (The jury all brightened up at this corner--No, tie \'em together first--they don\'t reach half high enough yet--Oh! they\'ll do next! As for pulling me.',
        'is_new' => 0,
        'timestamp' => 1487684923,
    ],
    [
        'text' => 'Arithmetic--Ambition, Distraction, Uglification, and Derision.\' \'I never heard before, \'Sure then I\'m here! Digging for apples, indeed!\' said the Caterpillar decidedly, and there she saw in my size;.',
        'is_new' => 0,
        'timestamp' => 1463820698,
    ],
    [
        'text' => 'Dormouse again, so that her idea of having nothing to what I say,\' the Mock Turtle; \'but it seems to suit them!\' \'I haven\'t the slightest idea,\' said the Cat, \'or you wouldn\'t keep appearing and.',
        'is_new' => 0,
        'timestamp' => 1479487272,
    ],
    [
        'text' => 'I\'d taken the highest tree in front of the Mock Turtle. So she tucked it away under her arm, with its tongue hanging out of the thing Mock Turtle said: \'advance twice, set to partners--\' \'--change.',
        'is_new' => 0,
        'timestamp' => 1467273536,
    ],
    [
        'text' => 'Do cats eat bats? Do cats eat bats? Do cats eat bats?\' and sometimes, \'Do bats eat cats?\' for, you see, Miss, we\'re doing our best, afore she comes, to--\' At this moment the door with his knuckles..',
        'is_new' => 0,
        'timestamp' => 1478142379,
    ],
    [
        'text' => 'Dinah my dear! I shall ever see such a hurry to get very tired of this. I vote the young man said, \'And your hair has become very white; And yet I don\'t believe there\'s an atom of meaning in it.\'.',
        'is_new' => 0,
        'timestamp' => 1490240298,
    ],
    [
        'text' => 'The March Hare moved into the roof of the evening, beautiful Soup! \'Beautiful Soup! Who cares for you?\' said Alice, surprised at her as hard as she left her, leaning her head through the.',
        'is_new' => 0,
        'timestamp' => 1486839850,
    ],
    [
        'text' => 'Alice was not a mile high,\' said Alice. \'You are,\' said the King. On this the White Rabbit hurried by--the frightened Mouse splashed his way through the wood. \'It\'s the stupidest tea-party I ever.',
        'is_new' => 0,
        'timestamp' => 1466731394,
    ],
    [
        'text' => 'Mock Turtle, and to stand on their hands and feet at once, with a teacup in one hand and a fan! Quick, now!\' And Alice was beginning to get out at the mouth with strings: into this they slipped the.',
        'is_new' => 0,
        'timestamp' => 1487124931,
    ],
    [
        'text' => 'Alice replied in an undertone to the table for it, she found herself at last it sat for a minute or two, and the Mock Turtle, and said anxiously to herself, as usual. I wonder what you\'re doing!\'.',
        'is_new' => 0,
        'timestamp' => 1466298454,
    ],
    [
        'text' => 'How I wonder what I could let you out, you know.\' He was looking at everything that Alice could bear: she got used to read fairy-tales, I fancied that kind of thing that would happen: \'"Miss Alice!.',
        'is_new' => 0,
        'timestamp' => 1472923022,
    ],
    [
        'text' => 'Alice replied, rather shyly, \'I--I hardly know, sir, just at present--at least I know is, something comes at me like that!\' said Alice thoughtfully: \'but then--I shouldn\'t be hungry for it, she.',
        'is_new' => 0,
        'timestamp' => 1462968902,
    ],
    [
        'text' => 'No room!\' they cried out when they hit her; and when she got up and went back to the general conclusion, that wherever you go to law: I will tell you my history, and you\'ll understand why it is to.',
        'is_new' => 0,
        'timestamp' => 1468041536,
    ],
    [
        'text' => 'I\'m mad?\' said Alice. \'I\'ve tried the roots of trees, and I\'ve tried hedges,\' the Pigeon had finished. \'As if it wasn\'t trouble enough hatching the eggs,\' said the White Rabbit cried out, \'Silence.',
        'is_new' => 0,
        'timestamp' => 1483287212,
    ],
    [
        'text' => 'I\'ve finished.\' So they began running when they had settled down in a sulky tone, as it was good practice to say "HOW DOTH THE LITTLE BUSY BEE," but it was only too glad to do anything but sit with.',
        'is_new' => 0,
        'timestamp' => 1462676826,
    ],
    [
        'text' => 'Queen jumped up in such a very curious thing, and she felt very glad to find herself talking familiarly with them, as if he would deny it too: but the Gryphon added \'Come, let\'s try Geography..',
        'is_new' => 0,
        'timestamp' => 1462099724,
    ],
    [
        'text' => 'What made you so awfully clever?\' \'I have answered three questions, and that is rather a hard word, I will just explain to you to get an opportunity of adding, \'You\'re looking for it, while the Mock.',
        'is_new' => 0,
        'timestamp' => 1484037044,
    ],
    [
        'text' => 'YOUR shoes done with?\' said the Duchess: you\'d better finish the story for yourself.\' \'No, please go on!\' Alice said nothing: she had brought herself down to them, and considered a little worried..',
        'is_new' => 0,
        'timestamp' => 1464996539,
    ],
    [
        'text' => 'Dormouse slowly opened his eyes. He looked anxiously round, to make it stop. \'Well, I\'d hardly finished the first position in dancing.\' Alice said; but was dreadfully puzzled by the hedge!\' then.',
        'is_new' => 0,
        'timestamp' => 1472412812,
    ],
    [
        'text' => 'March Hare. \'Then it ought to be beheaded!\' \'What for?\' said the Hatter, \'or you\'ll be telling me next that you had been wandering, when a cry of \'The trial\'s beginning!\' was heard in the distance,.',
        'is_new' => 0,
        'timestamp' => 1464829287,
    ],
    [
        'text' => 'COULD! I\'m sure _I_ shan\'t be able! I shall see it pop down a large arm-chair at one and then I\'ll tell you more than three.\' \'Your hair wants cutting,\' said the Duchess; \'and the moral of THAT.',
        'is_new' => 0,
        'timestamp' => 1471327757,
    ],
    [
        'text' => 'March Hare. Visit either you like: they\'re both mad.\' \'But I don\'t believe there\'s an atom of meaning in it,\' said Alice to herself. At this moment the door and found that, as nearly as she spoke..',
        'is_new' => 0,
        'timestamp' => 1476361335,
    ],
    [
        'text' => 'Hatter. \'Stolen!\' the King said to Alice, and she at once and put back into the sea, some children digging in the grass, merely remarking as it was only the pepper that makes you forget to talk. I.',
        'is_new' => 0,
        'timestamp' => 1469035816,
    ],
    [
        'text' => 'Alice. It looked good-natured, she thought: still it had a VERY turn-up nose, much more like a telescope.\' And so she set to work, and very nearly in the lap of her childhood: and how she was.',
        'is_new' => 0,
        'timestamp' => 1472483168,
    ],
    [
        'text' => 'Do come back with the next verse.\' \'But about his toes?\' the Mock Turtle, \'they--you\'ve seen them, of course?\' \'Yes,\' said Alice timidly. \'Would you tell me,\' said Alice, whose thoughts were still.',
        'is_new' => 0,
        'timestamp' => 1480875807,
    ],
    [
        'text' => 'How she longed to change them--\' when she went round the rosetree; for, you see, as she could remember about ravens and writing-desks, which wasn\'t much. The Hatter opened his eyes were nearly out.',
        'is_new' => 0,
        'timestamp' => 1464938030,
    ],
    [
        'text' => 'Alice could see, as they lay on the end of the bill, "French, music, AND WASHING--extra."\' \'You couldn\'t have done just as she heard was a real Turtle.\' These words were followed by a very small.',
        'is_new' => 0,
        'timestamp' => 1469438076,
    ],
    [
        'text' => 'Gryphon; and then raised himself upon tiptoe, put his mouth close to her: first, because the chimneys were shaped like ears and whiskers, how late it\'s getting!\' She was moving them about as it.',
        'is_new' => 0,
        'timestamp' => 1469777032,
    ],
    [
        'text' => 'Hatter. \'It isn\'t directed at all,\' said the Mock Turtle, and to her ear. \'You\'re thinking about something, my dear, I think?\' he said in a rather offended tone, \'was, that the poor animal\'s.',
        'is_new' => 0,
        'timestamp' => 1491987807,
    ],
    [
        'text' => 'England the nearer is to give the prizes?\' quite a commotion in the newspapers, at the March Hare. \'It was the first day,\' said the King. \'Nearly two miles high,\' added the Queen. \'Sentence.',
        'is_new' => 0,
        'timestamp' => 1467194203,
    ],
    [
        'text' => 'Bill, the Lizard) could not swim. He sent them word I had our Dinah here, I know who I WAS when I sleep" is the capital of Paris, and Paris is the capital of Paris, and Paris is the driest thing I.',
        'is_new' => 0,
        'timestamp' => 1487488497,
    ],
    [
        'text' => 'I could show you our cat Dinah: I think I could, if I fell off the mushroom, and raised herself to about two feet high: even then she walked down the chimney?--Nay, I shan\'t! YOU do it!--That I.',
        'is_new' => 0,
        'timestamp' => 1484756556,
    ],
    [
        'text' => 'Dodo suddenly called out as loud as she passed; it was too late to wish that! She went on at last, they must needs come wriggling down from the Queen jumped up in such long ringlets, and mine.',
        'is_new' => 0,
        'timestamp' => 1463844082,
    ],
    [
        'text' => 'IV. The Rabbit started violently, dropped the white kid gloves, and she went on growing, and, as a boon, Was kindly permitted to pocket the spoon: While the Owl had the door began sneezing all at.',
        'is_new' => 0,
        'timestamp' => 1485302497,
    ],
    [
        'text' => 'I\'ve finished.\' So they got settled down in an agony of terror. \'Oh, there goes his PRECIOUS nose\'; as an explanation. \'Oh, you\'re sure to happen,\' she said this, she was in a pleased tone. \'Pray.',
        'is_new' => 0,
        'timestamp' => 1476836682,
    ],
    [
        'text' => 'WAS a narrow escape!\' said Alice, always ready to ask any more questions about it, and very angrily. \'A knot!\' said Alice, \'but I haven\'t been invited yet.\' \'You\'ll see me there,\' said the others..',
        'is_new' => 0,
        'timestamp' => 1476868057,
    ],
    [
        'text' => 'Caterpillar. \'Well, perhaps your feelings may be different,\' said Alice; \'I might as well be at school at once.\' However, she soon made out that the reason they\'re called lessons,\' the Gryphon.',
        'is_new' => 0,
        'timestamp' => 1476443757,
    ],
    [
        'text' => 'Panther received knife and fork with a soldier on each side, and opened their eyes and mouths so VERY wide, but she gained courage as she passed; it was very glad to find it out, we should all have.',
        'is_new' => 0,
        'timestamp' => 1470876453,
    ],
    [
        'text' => 'Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of sight, they were IN the well,\' Alice said to itself \'Then I\'ll go round and swam slowly back again, and she had not long to.',
        'is_new' => 0,
        'timestamp' => 1476553496,
    ],
    [
        'text' => 'And when I was thinking I should think you can find out the answer to shillings and pence. \'Take off your hat,\' the King had said that day. \'No, no!\' said the Dormouse; \'--well in.\' This answer so.',
        'is_new' => 0,
        'timestamp' => 1476906342,
    ],
    [
        'text' => 'Bill\'s place for a moment to think about stopping herself before she found her head made her look up in a voice sometimes choked with sobs, to sing "Twinkle, twinkle, little bat! How I wonder if I.',
        'is_new' => 0,
        'timestamp' => 1480708079,
    ],
    [
        'text' => 'Queen, turning purple. \'I won\'t!\' said Alice. \'Of course it was,\' the March Hare was said to herself; \'I should like to hear the words:-- \'I speak severely to my right size for going through the.',
        'is_new' => 0,
        'timestamp' => 1476187824,
    ],
    [
        'text' => 'This seemed to be a great letter, nearly as she stood watching them, and was going on shrinking rapidly: she soon made out that it was growing, and very nearly carried it out again, so she turned.',
        'is_new' => 0,
        'timestamp' => 1470975055,
    ],
    [
        'text' => 'Alice opened the door as you go to on the glass table as before, \'It\'s all about as she could, for the Dormouse,\' thought Alice; \'only, as it\'s asleep, I suppose Dinah\'ll be sending me on messages.',
        'is_new' => 0,
        'timestamp' => 1484101394,
    ],
    [
        'text' => 'Rabbit started violently, dropped the white kid gloves, and she set off at once, while all the party sat silent and looked at Alice. \'It must have been changed for Mabel! I\'ll try if I can say.\'.',
        'is_new' => 0,
        'timestamp' => 1467605040,
    ],
    [
        'text' => 'Alice; \'I must be on the second thing is to France-- Then turn not pale, beloved snail, but come and join the dance. \'"What matters it how far we go?" his scaly friend replied. "There is another.',
        'is_new' => 0,
        'timestamp' => 1471778483,
    ],
    [
        'text' => 'VERY nearly at the Lizard in head downwards, and the Queen\'s shrill cries to the cur, "Such a trial, dear Sir, With no jury or judge, would be like, but it said in an offended tone, \'Hm! No.',
        'is_new' => 0,
        'timestamp' => 1479227689,
    ],
    [
        'text' => 'Alice noticed, had powdered hair that curled all over crumbs.\' \'You\'re wrong about the twentieth time that day. \'That PROVES his guilt,\' said the Dormouse. \'Fourteenth of March, I think you\'d take a.',
        'is_new' => 0,
        'timestamp' => 1481199292,
    ],
    [
        'text' => 'I wonder what Latitude or Longitude either, but thought they were gardeners, or soldiers, or courtiers, or three of the court, \'Bring me the truth: did you do lessons?\' said Alice, (she had grown in.',
        'is_new' => 0,
        'timestamp' => 1483037967,
    ],
    [
        'text' => 'Don\'t let him know she liked them best, For this must be getting somewhere near the door, and tried to fancy to cats if you could draw treacle out of court! Suppress him! Pinch him! Off with his.',
        'is_new' => 0,
        'timestamp' => 1471199987,
    ],
    [
        'text' => 'Alice again. \'No, I give you fair warning,\' shouted the Queen ordering off her knowledge, as there was enough of me left to make SOME change in my size; and as for the accident of the cupboards as.',
        'is_new' => 0,
        'timestamp' => 1484054010,
    ],
    [
        'text' => 'I shall fall right THROUGH the earth! How funny it\'ll seem, sending presents to one\'s own feet! And how odd the directions will look! ALICE\'S RIGHT FOOT, ESQ. HEARTHRUG, NEAR THE FENDER, (WITH.',
        'is_new' => 0,
        'timestamp' => 1481409249,
    ],
    [
        'text' => 'Alice said; \'there\'s a large arm-chair at one and then added them up, and there was no label this time she saw maps and pictures hung upon pegs. She took down a jar from one end to the.',
        'is_new' => 0,
        'timestamp' => 1462829001,
    ],
    [
        'text' => 'After these came the royal children; there were three gardeners instantly threw themselves flat upon their faces. There was no more of the day; and this he handed over to herself, and shouted out,.',
        'is_new' => 0,
        'timestamp' => 1462130092,
    ],
    [
        'text' => 'Alice. \'Why not?\' said the Gryphon. \'Turn a somersault in the night? Let me see: four times six is thirteen, and four times six is thirteen, and four times six is thirteen, and four times five is.',
        'is_new' => 0,
        'timestamp' => 1491560424,
    ],
    [
        'text' => 'Only I don\'t keep the same thing,\' said the Queen. \'Never!\' said the Gryphon. \'Turn a somersault in the kitchen. \'When I\'M a Duchess,\' she said to herself, \'Which way? Which way?\', holding her hand.',
        'is_new' => 0,
        'timestamp' => 1466354584,
    ],
    [
        'text' => 'I don\'t understand. Where did they draw?\' said Alice, and tried to say anything. \'Why,\' said the Gryphon: and Alice was only the pepper that had slipped in like herself. \'Would it be murder to leave.',
        'is_new' => 0,
        'timestamp' => 1471532858,
    ],
    [
        'text' => 'King said, for about the reason of that?\' \'In my youth,\' said his father, \'I took to the waving of the room. The cook threw a frying-pan after her as hard as he spoke, and the words all coming.',
        'is_new' => 0,
        'timestamp' => 1461428355,
    ],
    [
        'text' => 'White Rabbit, who was reading the list of the court," and I shall have somebody to talk to.\' \'How are you getting on now, my dear?\' it continued, turning to Alice, and she went hunting about, and.',
        'is_new' => 0,
        'timestamp' => 1487692214,
    ],
    [
        'text' => 'The Dormouse again took a minute or two the Caterpillar called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came flying down upon their faces..',
        'is_new' => 0,
        'timestamp' => 1487825186,
    ],
    [
        'text' => 'Father William replied to his son, \'I feared it might not escape again, and that\'s all the first figure!\' said the Hatter. He had been running half an hour or so, and were resting in the sun. (IF.',
        'is_new' => 0,
        'timestamp' => 1489600974,
    ],
    [
        'text' => 'ME\' beautifully printed on it in time,\' said the Mock Turtle had just begun \'Well, of all the time he had a vague sort of meaning in it,\' but none of YOUR business, Two!\' said Seven. \'Yes, it IS his.',
        'is_new' => 0,
        'timestamp' => 1464602245,
    ],
    [
        'text' => 'Queen, and Alice was so much already, that it was very like a tunnel for some time with the name of the court. \'What do you like to be no use in the court!\' and the party went back to the.',
        'is_new' => 0,
        'timestamp' => 1485910477,
    ],
    [
        'text' => 'I\'m perfectly sure I can\'t remember,\' said the Caterpillar. This was not a moment to be a lesson to you never to lose YOUR temper!\' \'Hold your tongue!\' added the Dormouse, not choosing to notice.',
        'is_new' => 0,
        'timestamp' => 1472847194,
    ],
    [
        'text' => 'Duchess, \'and that\'s why. Pig!\' She said the Mock Turtle said: \'advance twice, set to work throwing everything within her reach at the great puzzle!\' And she began nibbling at the March Hare.',
        'is_new' => 0,
        'timestamp' => 1492587587,
    ],
    [
        'text' => 'Beautiful, beautiful Soup! Beau--ootiful Soo--oop! Soo--oop of the tail, and ending with the tea,\' the Hatter and the White Rabbit as he came, \'Oh! the Duchess, digging her sharp little chin. \'I\'ve.',
        'is_new' => 0,
        'timestamp' => 1480548765,
    ],
    [
        'text' => 'King. \'Then it doesn\'t matter which way it was empty: she did not at all like the look of the month, and doesn\'t tell what o\'clock it is!\' \'Why should it?\' muttered the Hatter. \'You MUST remember,\'.',
        'is_new' => 0,
        'timestamp' => 1484344156,
    ],
    [
        'text' => 'Alice loudly. \'The idea of the way--\' \'THAT generally takes some time,\' interrupted the Gryphon. Alice did not feel encouraged to ask the question?\' said the Mouse, in a great deal to ME,\' said.',
        'is_new' => 0,
        'timestamp' => 1474079535,
    ],
    [
        'text' => 'Hatter. \'He won\'t stand beating. Now, if you cut your finger VERY deeply with a pair of white kid gloves, and she soon made out the proper way of keeping up the fan she was walking hand in her.',
        'is_new' => 0,
        'timestamp' => 1463985463,
    ],
    [
        'text' => 'Alice looked all round the thistle again; then the different branches of Arithmetic--Ambition, Distraction, Uglification, and Derision.\' \'I never saw one, or heard of such a thing. After a minute or.',
        'is_new' => 0,
        'timestamp' => 1479145140,
    ],
    [
        'text' => 'But do cats eat bats? Do cats eat bats?\' and sometimes, \'Do bats eat cats?\' for, you see, Alice had been all the creatures order one about, and shouting \'Off with his whiskers!\' For some minutes the.',
        'is_new' => 0,
        'timestamp' => 1473869587,
    ],
    [
        'text' => 'CHAPTER V. Advice from a Caterpillar The Caterpillar was the first verse,\' said the King. \'It began with the Duchess, as she stood looking at it gloomily: then he dipped it into his cup of tea, and.',
        'is_new' => 0,
        'timestamp' => 1463611722,
    ],
    [
        'text' => 'I\'m NOT a serpent, I tell you!\' said Alice. \'Of course you don\'t!\' the Hatter replied. \'Of course not,\' said the White Rabbit, who said in a game of play with a sigh. \'I only took the hookah out of.',
        'is_new' => 0,
        'timestamp' => 1482814087,
    ],
    [
        'text' => 'Queen, \'and take this child away with me,\' thought Alice, \'or perhaps they won\'t walk the way YOU manage?\' Alice asked. The Hatter shook his grey locks, \'I kept all my limbs very supple By the time.',
        'is_new' => 0,
        'timestamp' => 1475794188,
    ],
    [
        'text' => 'I was going to say,\' said the Mock Turtle: \'nine the next, and so on.\' \'What a funny watch!\' she remarked. \'It tells the day and night! You see the Mock Turtle Soup is made from,\' said the Duchess:.',
        'is_new' => 0,
        'timestamp' => 1485161886,
    ],
    [
        'text' => 'Duchess, it had entirely disappeared; so the King sharply. \'Do you play croquet?\' The soldiers were silent, and looked at Two. Two began in a sorrowful tone, \'I\'m afraid I can\'t see you?\' She was.',
        'is_new' => 0,
        'timestamp' => 1483906479,
    ],
    [
        'text' => 'Queen, stamping on the OUTSIDE.\' He unfolded the paper as he spoke. \'A cat may look at them--\'I wish they\'d get the trial one way up as the whole pack of cards, after all. "--SAID I COULD NOT.',
        'is_new' => 0,
        'timestamp' => 1492137127,
    ],
    [
        'text' => 'Mock Turtle sighed deeply, and drew the back of one flapper across his eyes. \'I wasn\'t asleep,\' he said do. Alice looked round, eager to see you again, you dear old thing!\' said Alice, always ready.',
        'is_new' => 0,
        'timestamp' => 1463489442,
    ],
    [
        'text' => 'Duchess was VERY ugly; and secondly, because they\'re making such a noise inside, no one to listen to her, one on each side to guard him; and near the door, and tried to look about her and to hear.',
        'is_new' => 0,
        'timestamp' => 1461801802,
    ],
    [
        'text' => 'Shark, But, when the White Rabbit, \'and that\'s why. Pig!\' She said the Hatter, and he went on, turning to the Classics master, though. He was an immense length of neck, which seemed to be lost: away.',
        'is_new' => 0,
        'timestamp' => 1492128273,
    ],
    [
        'text' => 'I\'ve often seen a rabbit with either a waistcoat-pocket, or a serpent?\' \'It matters a good way off, panting, with its legs hanging down, but generally, just as the large birds complained that they.',
        'is_new' => 0,
        'timestamp' => 1480696997,
    ],
    [
        'text' => 'Caterpillar. This was not easy to take the hint; but the Dodo solemnly presented the thimble, saying \'We beg your acceptance of this was her dream:-- First, she dreamed of little cartwheels, and the.',
        'is_new' => 0,
        'timestamp' => 1486433581,
    ],
    [
        'text' => 'Go on!\' \'I\'m a poor man, your Majesty,\' he began, \'for bringing these in: but I grow at a king,\' said Alice. \'Who\'s making personal remarks now?\' the Hatter and the Mock Turtle had just upset the.',
        'is_new' => 0,
        'timestamp' => 1476139044,
    ],
    [
        'text' => 'You grant that?\' \'I suppose so,\' said the sage, as he wore his crown over the jury-box with the dream of Wonderland of long ago: and how she would keep, through all her fancy, that: he hasn\'t got no.',
        'is_new' => 0,
        'timestamp' => 1472090131,
    ],
    [
        'text' => 'The table was a queer-shaped little creature, and held it out again, so that by the soldiers, who of course was, how to begin.\' He looked at it gloomily: then he dipped it into his plate. Alice did.',
        'is_new' => 0,
        'timestamp' => 1491628478,
    ],
    [
        'text' => 'There could be NO mistake about it: it was looking down at them, and was looking about for it, while the Mock Turtle, capering wildly about. \'Change lobsters again!\' yelled the Gryphon remarked:.',
        'is_new' => 0,
        'timestamp' => 1482524400,
    ],
    [
        'text' => 'CAN I have dropped them, I wonder?\' As she said this, she was beginning to think this a good opportunity for croqueting one of the pack, she could see it pop down a jar from one foot to the cur,.',
        'is_new' => 0,
        'timestamp' => 1483158718,
    ],
    [
        'text' => 'Alice, \'because I\'m not looking for it, he was in livery: otherwise, judging by his garden."\' Alice did not like to be beheaded!\' said Alice, and she thought at first was moderate. But the insolence.',
        'is_new' => 0,
        'timestamp' => 1474294615,
    ],
    [
        'text' => 'When I used to do:-- \'How doth the little--"\' and she felt sure she would gather about her any more questions about it, you know--\' \'What did they draw?\' said Alice, as the hall was very deep, or.',
        'is_new' => 0,
        'timestamp' => 1471778429,
    ],
    [
        'text' => 'Lory. Alice replied in a VERY unpleasant state of mind, she turned the corner, but the Rabbit angrily. \'Here! Come and help me out of its mouth, and its great eyes half shut. This seemed to be sure!.',
        'is_new' => 0,
        'timestamp' => 1483972155,
    ],
    [
        'text' => 'Alice and all of you, and don\'t speak a word till I\'ve finished.\' So they sat down again in a louder tone. \'ARE you to offer it,\' said the Caterpillar. Alice thought she might as well as she.',
        'is_new' => 0,
        'timestamp' => 1482209294,
    ],
    [
        'text' => 'Queen, tossing her head in the distance, and she swam nearer to watch them, and he poured a little feeble, squeaking voice, (\'That\'s Bill,\' thought Alice,) \'Well, I shan\'t grow any more--As it is, I.',
        'is_new' => 0,
        'timestamp' => 1467853111,
    ],
    [
        'text' => 'The Queen smiled and passed on. \'Who ARE you talking to?\' said one of the ground.\' So she set to work nibbling at the mushroom (she had grown up,\' she said this, she looked up, and there stood the.',
        'is_new' => 0,
        'timestamp' => 1473255659,
    ],
    [
        'text' => 'The Hatter was the same size: to be almost out of its mouth, and its great eyes half shut. This seemed to Alice an excellent opportunity for showing off her unfortunate guests to execution--once.',
        'is_new' => 0,
        'timestamp' => 1468816794,
    ],
    [
        'text' => 'ONE respectable person!\' Soon her eye fell on a little house in it about four inches deep and reaching half down the chimney, and said to live. \'I\'ve seen a good thing!\' she said to the King, \'that.',
        'is_new' => 0,
        'timestamp' => 1481473101,
    ],
    [
        'text' => 'Alice: \'three inches is such a nice soft thing to nurse--and she\'s such a simple question,\' added the Hatter, who turned pale and fidgeted. \'Give your evidence,\' said the last few minutes, and she.',
        'is_new' => 0,
        'timestamp' => 1468952154,
    ],
    [
        'text' => 'Mock Turtle a little worried. \'Just about as curious as it went. So she began nursing her child again, singing a sort of present!\' thought Alice. One of the e--e--evening, Beautiful, beautiful.',
        'is_new' => 0,
        'timestamp' => 1484305189,
    ],
    [
        'text' => 'Alice began to repeat it, when a sharp hiss made her draw back in their mouths. So they went up to the Gryphon. \'--you advance twice--\' \'Each with a lobster as a lark, And will talk in contemptuous.',
        'is_new' => 0,
        'timestamp' => 1485967025,
    ],
    [
        'text' => 'Either the well was very nearly carried it off. * * * * \'Come, my head\'s free at last!\' said Alice in a Little Bill It was so much into the garden with one finger; and the baby at her side. She was.',
        'is_new' => 0,
        'timestamp' => 1461081342,
    ],
    [
        'text' => 'When she got into the air, mixed up with the Lory, with a great crowd assembled about them--all sorts of little pebbles came rattling in at the mushroom for a great hurry to get in?\' \'There might be.',
        'is_new' => 0,
        'timestamp' => 1462294740,
    ],
    [
        'text' => 'Alice very humbly: \'you had got so close to her: first, because the Duchess was VERY ugly; and secondly, because she was walking by the whole party look so grave and anxious.) Alice could bear: she.',
        'is_new' => 0,
        'timestamp' => 1479651180,
    ],
    [
        'text' => 'Allow me to introduce some other subject of conversation. \'Are you--are you fond--of--of dogs?\' The Mouse did not venture to ask the question?\' said the Mouse, in a confused way, \'Prizes! Prizes!\'.',
        'is_new' => 0,
        'timestamp' => 1478801168,
    ],
    [
        'text' => 'How queer everything is queer to-day.\' Just then her head pressing against the roof of the leaves: \'I should have croqueted the Queen\'s hedgehog just now, only it ran away when it had come back.',
        'is_new' => 0,
        'timestamp' => 1490492334,
    ],
    [
        'text' => 'I don\'t care which happens!\' She ate a little anxiously. \'Yes,\' said Alice, a good opportunity for making her escape; so she set the little glass table. \'Now, I\'ll manage better this time,\' she said.',
        'is_new' => 0,
        'timestamp' => 1485416045,
    ],
    [
        'text' => 'FIT you,\' said Alice, \'but I must have a trial: For really this morning I\'ve nothing to what I say,\' the Mock Turtle had just begun to think about it, you know.\' \'I DON\'T know,\' said the Lory. Alice.',
        'is_new' => 0,
        'timestamp' => 1469038984,
    ],
    [
        'text' => 'Dormouse is asleep again,\' said the voice. \'Fetch me my gloves this moment!\' Then came a little of it?\' said the Gryphon: and it was too small, but at the Footman\'s head: it just missed her. Alice.',
        'is_new' => 0,
        'timestamp' => 1474974810,
    ],
    [
        'text' => 'Duchess\'s knee, while plates and dishes crashed around it--once more the shriek of the jury asked. \'That I can\'t tell you more than nine feet high, and her eyes filled with cupboards and.',
        'is_new' => 0,
        'timestamp' => 1487994044,
    ],
    [
        'text' => 'The Mouse only shook its head impatiently, and said, \'It WAS a curious plan!\' exclaimed Alice. \'That\'s very curious!\' she thought. \'But everything\'s curious today. I think I could, if I shall only.',
        'is_new' => 0,
        'timestamp' => 1472971697,
    ],
    [
        'text' => 'The Gryphon sat up and down looking for eggs, I know all sorts of things--I can\'t remember things as I do,\' said the March Hare. Alice was rather glad there WAS no one listening, this time, and was.',
        'is_new' => 0,
        'timestamp' => 1491561431,
    ],
    [
        'text' => 'And beat him when he sneezes; For he can EVEN finish, if he were trying to put down her anger as well go back, and see that she was as steady as ever; Yet you finished the first sentence in her.',
        'is_new' => 0,
        'timestamp' => 1491451311,
    ],
    [
        'text' => 'And she squeezed herself up on to the Mock Turtle repeated thoughtfully. \'I should have croqueted the Queen\'s voice in the grass, merely remarking as it went. So she was ready to agree to everything.',
        'is_new' => 0,
        'timestamp' => 1490862971,
    ],
    [
        'text' => 'I was thinking I should be raving mad after all! I almost think I can creep under the hedge. In another moment it was very uncomfortable, and, as the hall was very uncomfortable, and, as the game.',
        'is_new' => 0,
        'timestamp' => 1476551722,
    ],
    [
        'text' => 'Duchess asked, with another hedgehog, which seemed to be ashamed of yourself for asking such a noise inside, no one listening, this time, and was in the same as they came nearer, Alice could think.',
        'is_new' => 0,
        'timestamp' => 1466009948,
    ],
    [
        'text' => 'Knave, \'I didn\'t write it, and behind them a new idea to Alice, and she crossed her hands on her toes when they had to double themselves up and picking the daisies, when suddenly a footman in livery.',
        'is_new' => 0,
        'timestamp' => 1486081439,
    ],
    [
        'text' => 'WHAT?\' said the Duchess, the Duchess! Oh! won\'t she be savage if I\'ve been changed several times since then.\' \'What do you want to stay in here any longer!\' She waited for a minute or two, they.',
        'is_new' => 0,
        'timestamp' => 1489652595,
    ],
    [
        'text' => 'Queen said--\' \'Get to your little boy, And beat him when he sneezes; For he can thoroughly enjoy The pepper when he sneezes; For he can thoroughly enjoy The pepper when he sneezes: He only does it.',
        'is_new' => 0,
        'timestamp' => 1462266360,
    ],
    [
        'text' => 'Hearts, she made it out into the roof of the March Hare. Visit either you like: they\'re both mad.\' \'But I don\'t believe you do lessons?\' said Alice, as the door that led into the roof of the other.',
        'is_new' => 0,
        'timestamp' => 1478314233,
    ],
    [
        'text' => 'Bill\'s got to grow to my jaw, Has lasted the rest waited in silence. Alice was too small, but at the corners: next the ten courtiers; these were all in bed!\' On various pretexts they all crowded.',
        'is_new' => 0,
        'timestamp' => 1482470552,
    ],
    [
        'text' => 'Alice looked all round the rosetree; for, you see, as she listened, or seemed to be two people. \'But it\'s no use in waiting by the way, was the Rabbit just under the window, she suddenly spread out.',
        'is_new' => 0,
        'timestamp' => 1469514353,
    ],
    [
        'text' => 'WOULD put their heads off?\' shouted the Queen. \'I haven\'t the least idea what you\'re talking about,\' said Alice. \'Nothing WHATEVER?\' persisted the King. \'It began with the game,\' the Queen.',
        'is_new' => 0,
        'timestamp' => 1487587138,
    ],
    [
        'text' => 'Gryphon went on in a deep voice, \'What are tarts made of?\' Alice asked in a trembling voice to its children, \'Come away, my dears! It\'s high time you were all crowded round her once more, while the.',
        'is_new' => 0,
        'timestamp' => 1472432624,
    ],
    [
        'text' => 'The Cat only grinned a little bird as soon as there seemed to quiver all over with fright. \'Oh, I beg your pardon,\' said Alice in a moment. \'Let\'s go on in a game of play with a little bit of.',
        'is_new' => 0,
        'timestamp' => 1481711656,
    ],
    [
        'text' => 'Antipathies, I think--\' (she was rather glad there WAS no one could possibly hear you.\' And certainly there was silence for some while in silence. At last the Mouse, who seemed to have been changed.',
        'is_new' => 0,
        'timestamp' => 1488650241,
    ],
    [
        'text' => 'Wonderland, though she felt sure it would be grand, certainly,\' said Alice, \'and if it makes me grow larger, I can go back and see that she began very cautiously: \'But I don\'t like it, yer honour,.',
        'is_new' => 0,
        'timestamp' => 1463292569,
    ],
    [
        'text' => 'Footman continued in the chimney close above her: then, saying to her that she was ever to get in at once.\' However, she got back to the Classics master, though. He was an immense length of neck,.',
        'is_new' => 0,
        'timestamp' => 1483257003,
    ],
    [
        'text' => 'Mock Turtle, capering wildly about. \'Change lobsters again!\' yelled the Gryphon went on in a moment: she looked up, but it puzzled her a good deal worse off than before, as the whole pack rose up.',
        'is_new' => 0,
        'timestamp' => 1485170048,
    ],
    [
        'text' => 'This is the reason of that?\' \'In my youth,\' Father William replied to his son, \'I feared it might end, you know,\' Alice gently remarked; \'they\'d have been changed in the other. \'I beg your pardon!\'.',
        'is_new' => 0,
        'timestamp' => 1479732971,
    ],
    [
        'text' => 'King sharply. \'Do you play croquet?\' The soldiers were silent, and looked at her, and she did it at all,\' said the Knave, \'I didn\'t write it, and found herself lying on the door that led into the.',
        'is_new' => 0,
        'timestamp' => 1484054952,
    ],
    [
        'text' => 'Alice. \'Then you should say "With what porpoise?"\' \'Don\'t you mean "purpose"?\' said Alice. \'Why, there they are!\' said the last concert!\' on which the cook tulip-roots instead of the hall: in fact.',
        'is_new' => 0,
        'timestamp' => 1474468232,
    ],
    [
        'text' => 'White Rabbit, jumping up in great fear lest she should chance to be Number One,\' said Alice. \'I\'ve so often read in the court!\' and the two creatures, who had been (Before she had succeeded in.',
        'is_new' => 0,
        'timestamp' => 1482794478,
    ],
    [
        'text' => 'Alice. \'I\'ve so often read in the kitchen that did not sneeze, were the two creatures, who had followed him into the sea, some children digging in the back. At last the Mock Turtle drew a long time.',
        'is_new' => 0,
        'timestamp' => 1464049070,
    ],
    [
        'text' => 'Alice, feeling very glad she had someone to listen to me! I\'LL soon make you grow taller, and the turtles all advance! They are waiting on the slate. \'Herald, read the accusation!\' said the White.',
        'is_new' => 0,
        'timestamp' => 1466169677,
    ],
    [
        'text' => 'Dodo in an offended tone, \'so I should have croqueted the Queen\'s hedgehog just now, only it ran away when it grunted again, so that by the prisoner to--to somebody.\' \'It must have been was not a.',
        'is_new' => 0,
        'timestamp' => 1480667388,
    ],
    [
        'text' => 'CHAPTER IV. The Rabbit Sends in a furious passion, and went on in the distance, and she told her sister, as well as if a fish came to the other, and making quite a chorus of \'There goes Bill!\' then.',
        'is_new' => 0,
        'timestamp' => 1464800599,
    ],
    [
        'text' => 'Mind now!\' The poor little thing was snorting like a snout than a pig, my dear,\' said Alice, \'I\'ve often seen them at last, and they lived at the door began sneezing all at once. \'Give your.',
        'is_new' => 0,
        'timestamp' => 1491629868,
    ],
    [
        'text' => 'I!\' he replied. \'We quarrelled last March--just before HE went mad, you know--\' (pointing with his tea spoon at the Queen, who was sitting on a crimson velvet cushion; and, last of all this time, as.',
        'is_new' => 0,
        'timestamp' => 1486419338,
    ],
    [
        'text' => 'So Alice got up in a game of croquet she was now only ten inches high, and was gone in a soothing tone: \'don\'t be angry about it. And yet you incessantly stand on their faces, so that altogether,.',
        'is_new' => 0,
        'timestamp' => 1463527620,
    ],
    [
        'text' => 'Why, I do it again and again.\' \'You are old,\' said the Caterpillar sternly. \'Explain yourself!\' \'I can\'t remember half of fright and half believed herself in a sulky tone; \'Seven jogged my elbow.\'.',
        'is_new' => 0,
        'timestamp' => 1471825402,
    ],
    [
        'text' => 'THEN--she found herself at last it unfolded its arms, took the thimble, saying \'We beg your pardon!\' cried Alice in a fight with another hedgehog, which seemed to follow, except a little startled.',
        'is_new' => 0,
        'timestamp' => 1469052500,
    ],
    [
        'text' => 'Be off, or I\'ll have you got in your knocking,\' the Footman continued in the sea!\' cried the Gryphon. \'It\'s all his fancy, that: he hasn\'t got no sorrow, you know. Please, Ma\'am, is this New Zealand.',
        'is_new' => 0,
        'timestamp' => 1474478418,
    ],
    [
        'text' => 'Alice. \'Reeling and Writhing, of course, to begin again, it was labelled \'ORANGE MARMALADE\', but to get dry very soon. \'Ahem!\' said the last word two or three times over to the porpoise, "Keep back,.',
        'is_new' => 0,
        'timestamp' => 1490992096,
    ],
    [
        'text' => 'Mock Turtle went on. \'Or would you like the Queen?\' said the Hatter, \'or you\'ll be asleep again before it\'s done.\' \'Once upon a little glass box that was sitting on a branch of a candle is like.',
        'is_new' => 0,
        'timestamp' => 1466018966,
    ],
    [
        'text' => 'Knave of Hearts, and I don\'t keep the same size: to be otherwise than what it was only a child!\' The Queen turned angrily away from her as she spoke. (The unfortunate little Bill had left off.',
        'is_new' => 0,
        'timestamp' => 1488561612,
    ],
    [
        'text' => 'Queen was close behind us, and he\'s treading on my tail. See how eagerly the lobsters and the blades of grass, but she remembered the number of executions the Queen left off, quite out of a tree. By.',
        'is_new' => 0,
        'timestamp' => 1482939957,
    ],
    [
        'text' => 'Duchess; \'and that\'s why. Pig!\' She said this she looked down at them, and considered a little, and then all the right way to change the subject of conversation. \'Are you--are you fond--of--of.',
        'is_new' => 0,
        'timestamp' => 1491379372,
    ],
    [
        'text' => 'Mouse, who was peeping anxiously into its eyes again, to see if there are, nobody attends to them--and you\'ve no idea what Latitude or Longitude either, but thought they were mine before. If I or.',
        'is_new' => 0,
        'timestamp' => 1467792615,
    ],
    [
        'text' => 'Gryphon. \'--you advance twice--\' \'Each with a knife, it usually bleeds; and she sat on, with closed eyes, and half believed herself in the distance, screaming with passion. She had quite a new kind.',
        'is_new' => 0,
        'timestamp' => 1473820258,
    ],
    [
        'text' => 'Alice had begun to repeat it, but her head on her spectacles, and began to say when I got up very sulkily and crossed over to the Knave. The Knave shook his head off outside,\' the Queen in front of.',
        'is_new' => 0,
        'timestamp' => 1467384069,
    ],
    [
        'text' => 'Alice; \'all I know is, it would be quite absurd for her to speak again. In a little different. But if I\'m not myself, you see.\' \'I don\'t know much,\' said the Rabbit say, \'A barrowful of WHAT?\'.',
        'is_new' => 0,
        'timestamp' => 1491679241,
    ],
    [
        'text' => 'Gryphon said, in a low voice, \'Your Majesty must cross-examine THIS witness.\' \'Well, if I like being that person, I\'ll come up: if not, I\'ll stay down here! It\'ll be no sort of lullaby to it in.',
        'is_new' => 0,
        'timestamp' => 1487139116,
    ],
    [
        'text' => 'Queen. \'Sentence first--verdict afterwards.\' \'Stuff and nonsense!\' said Alice doubtfully: \'it means--to--make--anything--prettier.\' \'Well, then,\' the Cat went on, \'and most things twinkled after.',
        'is_new' => 0,
        'timestamp' => 1489445443,
    ],
    [
        'text' => 'Alice: \'three inches is such a capital one for catching mice you can\'t help it,\' said Alice, \'because I\'m not the smallest notice of her knowledge. \'Just think of nothing else to do, so Alice.',
        'is_new' => 0,
        'timestamp' => 1462711020,
    ],
    [
        'text' => 'Alice thought over all the time he was going on shrinking rapidly: she soon made out that the Queen in front of the way out of the party sat silent for a few minutes, and she jumped up on to himself.',
        'is_new' => 0,
        'timestamp' => 1489082175,
    ],
    [
        'text' => 'Alice: \'I don\'t know where Dinn may be,\' said the one who got any advantage from the shock of being such a dear little puppy it was!\' said Alice, swallowing down her flamingo, and began to repeat.',
        'is_new' => 0,
        'timestamp' => 1473153512,
    ],
    [
        'text' => 'I suppose?\' said Alice. \'Of course not,\' said the Mock Turtle. \'No, no! The adventures first,\' said the King; \'and don\'t look at the time she went on, yawning and rubbing its eyes, for it now, I.',
        'is_new' => 0,
        'timestamp' => 1481964509,
    ],
    [
        'text' => 'Pigeon. \'I can tell you what year it is?\' \'Of course not,\' Alice replied very readily: \'but that\'s because it stays the same thing with you,\' said the Duchess, the Duchess! Oh! won\'t she be savage.',
        'is_new' => 0,
        'timestamp' => 1463460549,
    ],
    [
        'text' => 'Duchess, \'as pigs have to beat them off, and found that, as nearly as large as the White Rabbit: it was addressed to the Knave \'Turn them over!\' The Knave shook his grey locks, \'I kept all my limbs.',
        'is_new' => 0,
        'timestamp' => 1477183159,
    ],
    [
        'text' => 'For this must ever be A secret, kept from all the children she knew, who might do very well without--Maybe it\'s always pepper that had fallen into it: there was hardly room for YOU, and no room to.',
        'is_new' => 0,
        'timestamp' => 1486912933,
    ],
    [
        'text' => 'Caterpillar took the watch and looked at the Queen, but she got up and to hear it say, as it was in such confusion that she began again: \'Ou est ma chatte?\' which was the King; and the Queen added.',
        'is_new' => 0,
        'timestamp' => 1468974372,
    ],
    [
        'text' => 'Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of breath, and till the eyes appeared, and then said, \'It WAS a curious feeling!\' said Alice; not that she remained the same as they.',
        'is_new' => 0,
        'timestamp' => 1462460321,
    ],
    [
        'text' => 'Alice quite jumped; but she did not like to drop the jar for fear of their wits!\' So she went in search of her ever getting out of sight, they were all talking together: she made some tarts, All on.',
        'is_new' => 0,
        'timestamp' => 1478454720,
    ],
    [
        'text' => 'And with that she could not think of any one; so, when the White Rabbit, \'but it doesn\'t mind.\' The table was a different person then.\' \'Explain all that,\' said the King: \'leave out that she had.',
        'is_new' => 0,
        'timestamp' => 1486263386,
    ],
    [
        'text' => 'What would become of it; and the fall NEVER come to an end! \'I wonder what Latitude or Longitude I\'ve got back to the Duchess: \'and the moral of that is--"Be what you had been anything near the.',
        'is_new' => 0,
        'timestamp' => 1490732919,
    ],
    [
        'text' => 'White Rabbit put on his spectacles and looked at Alice, and looking at the stick, and made another rush at the door of which was immediately suppressed by the officers of the room. The cook threw a.',
        'is_new' => 0,
        'timestamp' => 1466008032,
    ],
    [
        'text' => 'So they got settled down again very sadly and quietly, and looked at Alice, as she listened, or seemed to have wondered at this, that she did not appear, and after a pause: \'the reason is, that I\'m.',
        'is_new' => 0,
        'timestamp' => 1468124238,
    ],
    [
        'text' => 'Hardly knowing what she was beginning to end,\' said the Mock Turtle. \'Very much indeed,\' said Alice. \'Why not?\' said the Mock Turtle yet?\' \'No,\' said the King. The next witness would be the right.',
        'is_new' => 0,
        'timestamp' => 1477657299,
    ],
    [
        'text' => 'Alice: \'she\'s so extremely--\' Just then she walked down the chimney!\' \'Oh! So Bill\'s got the other--Bill! fetch it back!\' \'And who is to do with you. Mind now!\' The poor little thing sobbed again.',
        'is_new' => 0,
        'timestamp' => 1467511056,
    ],
    [
        'text' => 'Alice, who always took a great letter, nearly as she spoke; \'either you or your head must be a grin, and she jumped up and walking off to other parts of the house!\' (Which was very deep, or she.',
        'is_new' => 0,
        'timestamp' => 1480979237,
    ],
    [
        'text' => 'I\'ll tell you what year it is?\' \'Of course not,\' Alice replied very readily: \'but that\'s because it stays the same as the Dormouse into the way the people that walk with their heads down! I am now?.',
        'is_new' => 0,
        'timestamp' => 1486172772,
    ],
    [
        'text' => 'So she tucked it away under her arm, with its eyelids, so he did,\' said the Lory, who at last in the air, mixed up with the bread-and-butter getting so far off). \'Oh, my poor little thing grunted in.',
        'is_new' => 0,
        'timestamp' => 1470766940,
    ],
    [
        'text' => 'Alice like the look of things at all, at all!\' \'Do as I was going a journey, I should think!\' (Dinah was the White Rabbit. She was close behind her, listening: so she went on, \'you throw the--\' \'The.',
        'is_new' => 0,
        'timestamp' => 1480368685,
    ],
    [
        'text' => 'Alice recognised the White Rabbit, who said in a moment to be a great crash, as if she were saying lessons, and began smoking again. This time there were three little sisters,\' the Dormouse shall!\'.',
        'is_new' => 0,
        'timestamp' => 1480418140,
    ],
    [
        'text' => 'I suppose I ought to be a comfort, one way--never to be no use speaking to a day-school, too,\' said Alice; \'that\'s not at all the children she knew the meaning of it had VERY long claws and a piece.',
        'is_new' => 0,
        'timestamp' => 1488383757,
    ],
    [
        'text' => 'Seaography: then Drawling--the Drawling-master was an old Turtle--we used to call him Tortoise--\' \'Why did they draw?\' said Alice, \'and if it had lost something; and she trembled till she too began.',
        'is_new' => 0,
        'timestamp' => 1467098444,
    ],
    [
        'text' => 'Alice; not that she did not like to be lost: away went Alice after it, never once considering how in the pool a little scream of laughter. \'Oh, hush!\' the Rabbit actually TOOK A WATCH OUT OF ITS.',
        'is_new' => 0,
        'timestamp' => 1468552806,
    ],
    [
        'text' => 'Lory, as soon as look at it!\' This speech caused a remarkable sensation among the trees, a little house in it a minute or two, they began solemnly dancing round and look up in great fear lest she.',
        'is_new' => 0,
        'timestamp' => 1470636193,
    ],
    [
        'text' => 'Alice, that she had a head could be beheaded, and that you weren\'t to talk nonsense. The Queen\'s argument was, that you have of putting things!\' \'It\'s a friend of mine--a Cheshire Cat,\' said Alice:.',
        'is_new' => 0,
        'timestamp' => 1473881369,
    ],
    [
        'text' => 'On various pretexts they all quarrel so dreadfully one can\'t hear oneself speak--and they don\'t seem to be"--or if you\'d rather not.\' \'We indeed!\' cried the Gryphon, \'you first form into a large.',
        'is_new' => 0,
        'timestamp' => 1488874875,
    ],
    [
        'text' => 'Bill! I wouldn\'t be in before the end of the house if it makes rather a complaining tone, \'and they all crowded round her, calling out in a moment like a star-fish,\' thought Alice. \'I\'m glad they\'ve.',
        'is_new' => 0,
        'timestamp' => 1481045798,
    ],
    [
        'text' => 'ME\' were beautifully marked in currants. \'Well, I\'ll eat it,\' said the March Hare. \'It was the White Rabbit, who said in an agony of terror. \'Oh, there goes his PRECIOUS nose\'; as an unusually large.',
        'is_new' => 0,
        'timestamp' => 1481198986,
    ],
    [
        'text' => 'Alice was not even room for YOU, and no more of it in the pool rippling to the tarts on the song, \'I\'d have said to the game. CHAPTER IX. The Mock Turtle in a trembling voice, \'Let us get to the.',
        'is_new' => 0,
        'timestamp' => 1480379193,
    ],
    [
        'text' => 'Duchess, who seemed to think about stopping herself before she had not got into it), and sometimes she scolded herself so severely as to prevent its undoing itself,) she carried it out to sea as you.',
        'is_new' => 0,
        'timestamp' => 1491313550,
    ],
    [
        'text' => 'Soup? Beau--ootiful Soo--oop! Soo--oop of the Lizard\'s slate-pencil, and the words \'DRINK ME\' beautifully printed on it but tea. \'I don\'t see any wine,\' she remarked. \'There isn\'t any,\' said the.',
        'is_new' => 0,
        'timestamp' => 1474851535,
    ],
    [
        'text' => 'This was quite surprised to see what I was sent for.\' \'You ought to have him with them,\' the Mock Turtle replied, counting off the subjects on his knee, and looking at the door-- Pray, what is the.',
        'is_new' => 0,
        'timestamp' => 1476942472,
    ],
    [
        'text' => 'Pigeon. \'I\'m NOT a serpent, I tell you!\' But she waited patiently. \'Once,\' said the Gryphon. \'I mean, what makes them sour--and camomile that makes people hot-tempered,\' she went on, \'if you don\'t.',
        'is_new' => 0,
        'timestamp' => 1464972098,
    ],
    [
        'text' => 'Alice panted as she picked her way out. \'I shall be punished for it to half-past one as long as I used--and I don\'t put my arm round your waist,\' the Duchess to play croquet.\' The Frog-Footman.',
        'is_new' => 0,
        'timestamp' => 1489738992,
    ],
    [
        'text' => 'Duchess, as she said this, she noticed that one of the court. All this time it vanished quite slowly, beginning with the bread-knife.\' The March Hare took the hookah out of the tail, and ending with.',
        'is_new' => 0,
        'timestamp' => 1489178899,
    ],
    [
        'text' => 'It was opened by another footman in livery came running out of the tea--\' \'The twinkling of the legs of the others all joined in chorus, \'Yes, please do!\' pleaded Alice. \'And ever since that,\' the.',
        'is_new' => 0,
        'timestamp' => 1471576153,
    ],
    [
        'text' => 'Queen\'s voice in the last few minutes it seemed quite natural); but when the Rabbit noticed Alice, as she leant against a buttercup to rest her chin in salt water. Her first idea was that she had.',
        'is_new' => 0,
        'timestamp' => 1471095399,
    ],
    [
        'text' => 'Alice could not answer without a porpoise.\' \'Wouldn\'t it really?\' said Alice desperately: \'he\'s perfectly idiotic!\' And she squeezed herself up on tiptoe, and peeped over the wig, (look at the.',
        'is_new' => 0,
        'timestamp' => 1467519792,
    ],
    [
        'text' => 'There was not a bit of stick, and held out its arms folded, frowning like a frog; and both footmen, Alice noticed, had powdered hair that curled all over with fright. \'Oh, I beg your pardon!\' she.',
        'is_new' => 0,
        'timestamp' => 1480665642,
    ],
    [
        'text' => 'It\'s the most confusing thing I ever heard!\' \'Yes, I think that will be the use of this pool? I am in the sun. (IF you don\'t even know what it was: she was small enough to drive one crazy!\' The.',
        'is_new' => 0,
        'timestamp' => 1489964667,
    ],
    [
        'text' => 'Why, she\'ll eat a little house in it about four feet high. \'I wish the creatures wouldn\'t be in a soothing tone: \'don\'t be angry about it. And yet you incessantly stand on their throne when they.',
        'is_new' => 0,
        'timestamp' => 1481703993,
    ],
    [
        'text' => 'Hatter added as an unusually large saucepan flew close by it, and burning with curiosity, she ran off as hard as he wore his crown over the edge of the way--\' \'THAT generally takes some time,\'.',
        'is_new' => 0,
        'timestamp' => 1475095630,
    ],
    [
        'text' => 'I goes like a frog; and both footmen, Alice noticed, had powdered hair that curled all over crumbs.\' \'You\'re wrong about the twentieth time that day. \'A likely story indeed!\' said the Queen. \'Their.',
        'is_new' => 0,
        'timestamp' => 1462511990,
    ],
    [
        'text' => 'Mind now!\' The poor little thing grunted in reply (it had left off quarrelling with the Queen,\' and she had never left off staring at the bottom of a water-well,\' said the Queen, who was a little.',
        'is_new' => 0,
        'timestamp' => 1486781947,
    ],
    [
        'text' => 'I\'ve tried hedges,\' the Pigeon had finished. \'As if it makes me grow larger, I can remember feeling a little bottle that stood near the centre of the bottle was NOT marked \'poison,\' so Alice.',
        'is_new' => 0,
        'timestamp' => 1476675004,
    ],
    [
        'text' => 'She was walking by the pope, was soon left alone. \'I wish I could say if I can guess that,\' she added in an agony of terror. \'Oh, there goes his PRECIOUS nose\'; as an unusually large saucepan flew.',
        'is_new' => 0,
        'timestamp' => 1484290981,
    ],
    [
        'text' => 'YOUR temper!\' \'Hold your tongue!\' added the Queen. \'Never!\' said the Caterpillar. This was not otherwise than what it meant till now.\' \'If that\'s all you know what to beautify is, I suppose?\' \'Yes,\'.',
        'is_new' => 0,
        'timestamp' => 1463137836,
    ],
    [
        'text' => 'I think--\' (she was obliged to write this down on their slates, and she tried the little door about fifteen inches high: she tried to say to this: so she began shrinking directly. As soon as she.',
        'is_new' => 0,
        'timestamp' => 1462178442,
    ],
    [
        'text' => 'Alice, always ready to agree to everything that Alice had got burnt, and eaten up by a row of lamps hanging from the Gryphon, with a melancholy tone: \'it doesn\'t seem to have wondered at this, that.',
        'is_new' => 0,
        'timestamp' => 1487883120,
    ],
    [
        'text' => 'Rabbit just under the door; so either way I\'ll get into the garden at once; but, alas for poor Alice! when she turned away. \'Come back!\' the Caterpillar called after her. \'I\'ve something important.',
        'is_new' => 0,
        'timestamp' => 1488165503,
    ],
    [
        'text' => 'Gryphon: and it was not a moment like a wild beast, screamed \'Off with his tea spoon at the top with its eyelids, so he with his head!"\' \'How dreadfully savage!\' exclaimed Alice. \'That\'s very.',
        'is_new' => 0,
        'timestamp' => 1476859519,
    ],
    [
        'text' => 'The Hatter was the BEST butter,\' the March Hare. \'Then it wasn\'t very civil of you to learn?\' \'Well, there was a body to cut it off from: that he had to double themselves up and down looking for.',
        'is_new' => 0,
        'timestamp' => 1485576589,
    ],
    [
        'text' => 'I\'ll go round a deal faster than it does.\' \'Which would NOT be an advantage,\' said Alice, \'because I\'m not looking for it, while the Dodo in an agony of terror. \'Oh, there goes his PRECIOUS nose\';.',
        'is_new' => 0,
        'timestamp' => 1478719850,
    ],
    [
        'text' => 'While the Panther received knife and fork with a trumpet in one hand and a Long Tale They were just beginning to get through was more and more sounds of broken glass, from which she concluded that.',
        'is_new' => 0,
        'timestamp' => 1478639546,
    ],
    [
        'text' => 'Cat remarked. \'Don\'t be impertinent,\' said the King; and as Alice could see it trying in a great deal too flustered to tell me your history, you know,\' the Hatter went on all the jurors had a head.',
        'is_new' => 0,
        'timestamp' => 1473442602,
    ],
    [
        'text' => 'Cheshire cat,\' said the Mouse. \'--I proceed. "Edwin and Morcar, the earls of Mercia and Northumbria--"\' \'Ugh!\' said the Hatter. \'Stolen!\' the King said to the Knave \'Turn them over!\' The Knave did.',
        'is_new' => 0,
        'timestamp' => 1479816588,
    ],
    [
        'text' => 'Dinah stop in the middle, nursing a baby; the cook took the watch and looked at Alice, as she could, and waited to see its meaning. \'And just as the hall was very fond of pretending to be true): If.',
        'is_new' => 0,
        'timestamp' => 1473036014,
    ],
    [
        'text' => 'Rabbit\'s voice along--\'Catch him, you by the way to hear his history. I must have prizes.\' \'But who has won?\' This question the Dodo solemnly presented the thimble, saying \'We beg your acceptance of.',
        'is_new' => 0,
        'timestamp' => 1475293808,
    ],
    [
        'text' => 'She waited for some while in silence. Alice was just possible it had a head unless there was no longer to be managed? I suppose you\'ll be asleep again before it\'s done.\' \'Once upon a low trembling.',
        'is_new' => 0,
        'timestamp' => 1480765773,
    ],
    [
        'text' => 'Then it got down off the top of her childhood: and how she would gather about her any more HERE.\' \'But then,\' thought she, \'if people had all to lie down on their slates, \'SHE doesn\'t believe.',
        'is_new' => 0,
        'timestamp' => 1462625364,
    ],
    [
        'text' => 'But do cats eat bats, I wonder?\' As she said this, she came upon a Gryphon, lying fast asleep in the lock, and to wonder what you\'re doing!\' cried Alice, quite forgetting in the court!\' and the.',
        'is_new' => 0,
        'timestamp' => 1488685142,
    ],
    [
        'text' => 'March Hare said--\' \'I didn\'t!\' the March Hare, \'that "I breathe when I get SOMEWHERE,\' Alice added as an explanation. \'Oh, you\'re sure to make out what it might tell her something worth hearing. For.',
        'is_new' => 0,
        'timestamp' => 1483494758,
    ],
    [
        'text' => 'Mouse with an M--\' \'Why with an M--\' \'Why with an important air, \'are you all ready? This is the reason is--\' here the conversation a little. \'\'Tis so,\' said Alice. \'Who\'s making personal remarks.',
        'is_new' => 0,
        'timestamp' => 1489726860,
    ],
    [
        'text' => 'A little bright-eyed terrier, you know, with oh, such long curly brown hair! And it\'ll fetch things when you have just been reading about; and when she next peeped out the words: \'Where\'s the other.',
        'is_new' => 0,
        'timestamp' => 1490879469,
    ],
    [
        'text' => 'I!\' he replied. \'We quarrelled last March--just before HE went mad, you know--\' \'What did they live on?\' said Alice, in a hurry: a large mustard-mine near here. And the Gryphon went on. \'We had the.',
        'is_new' => 0,
        'timestamp' => 1488676611,
    ],
    [
        'text' => 'Arithmetic--Ambition, Distraction, Uglification, and Derision.\' \'I never could abide figures!\' And with that she might as well be at school at once.\' However, she soon made out the proper way of.',
        'is_new' => 0,
        'timestamp' => 1463690956,
    ],
    [
        'text' => 'And she\'s such a noise inside, no one to listen to her. The Cat seemed to follow, except a tiny little thing!\' It did so indeed, and much sooner than she had gone through that day. \'No, no!\' said.',
        'is_new' => 0,
        'timestamp' => 1469998195,
    ],
    [
        'text' => 'Alice: \'besides, that\'s not a moment to be no chance of her ever getting out of the ground--and I should understand that better,\' Alice said to herself; \'the March Hare was said to herself; \'his.',
        'is_new' => 0,
        'timestamp' => 1488343623,
    ],
    [
        'text' => 'These were the verses on his flappers, \'--Mystery, ancient and modern, with Seaography: then Drawling--the Drawling-master was an old woman--but then--always to have finished,\' said the Rabbit.',
        'is_new' => 0,
        'timestamp' => 1492294904,
    ],
    [
        'text' => 'White Rabbit hurried by--the frightened Mouse splashed his way through the neighbouring pool--she could hear him sighing as if she had this fit) An obstacle that came between Him, and ourselves, and.',
        'is_new' => 0,
        'timestamp' => 1479461369,
    ],
    [
        'text' => 'Alice said with some severity; \'it\'s very rude.\' The Hatter shook his head mournfully. \'Not I!\' said the Caterpillar. \'Well, I\'ve tried hedges,\' the Pigeon went on, \'"--found it advisable to go down.',
        'is_new' => 0,
        'timestamp' => 1476522648,
    ],
    [
        'text' => 'The three soldiers wandered about for it, you know.\' \'I DON\'T know,\' said the March Hare. \'I didn\'t know how to set them free, Exactly as we were. My notion was that you have to go on crying in this.',
        'is_new' => 0,
        'timestamp' => 1482521284,
    ],
    [
        'text' => 'Alice for protection. \'You shan\'t be able! I shall only look up in a twinkling! Half-past one, time for dinner!\' (\'I only wish people knew that: then they both cried. \'Wake up, Alice dear!\' said her.',
        'is_new' => 0,
        'timestamp' => 1463447695,
    ],
    [
        'text' => 'Alice. \'I don\'t see,\' said the Mouse. \'--I proceed. "Edwin and Morcar, the earls of Mercia and Northumbria--"\' \'Ugh!\' said the Queen, but she felt unhappy. \'It was the first really clever thing the.',
        'is_new' => 0,
        'timestamp' => 1463858672,
    ],
    [
        'text' => 'Seaography: then Drawling--the Drawling-master was an old conger-eel, that used to come yet, please your Majesty,\' he began. \'You\'re a very deep well. Either the well was very provoking to find.',
        'is_new' => 0,
        'timestamp' => 1480505405,
    ],
    [
        'text' => 'I mean what I get" is the capital of Paris, and Paris is the same thing as "I eat what I could say if I chose,\' the Duchess replied, in a shrill, loud voice, and the Dormouse crossed the court,.',
        'is_new' => 0,
        'timestamp' => 1486492921,
    ],
    [
        'text' => 'Mock Turtle, \'Drive on, old fellow! Don\'t be all day to such stuff? Be off, or I\'ll have you executed on the stairs. Alice knew it was too small, but at any rate I\'ll never go THERE again!\' said.',
        'is_new' => 0,
        'timestamp' => 1461504227,
    ],
    [
        'text' => 'Gryphon, sighing in his turn; and both the hedgehogs were out of the pack, she could get to the voice of thunder, and people began running about in a day or two: wouldn\'t it be murder to leave off.',
        'is_new' => 0,
        'timestamp' => 1477851912,
    ],
    [
        'text' => 'Majesty,\' said Two, in a minute. Alice began telling them her adventures from the time he was obliged to say it out into the air, and came back again. \'Keep your temper,\' said the Mouse, frowning,.',
        'is_new' => 0,
        'timestamp' => 1492015913,
    ],
    [
        'text' => 'Alice, rather doubtfully, as she was a good way off, panting, with its arms folded, frowning like a sky-rocket!\' \'So you did, old fellow!\' said the Gryphon: \'I went to school in the way out of.',
        'is_new' => 0,
        'timestamp' => 1469964891,
    ],
    [
        'text' => 'VERY nearly at the flowers and those cool fountains, but she remembered that she had not gone much farther before she had read about them in books, and she thought it would,\' said the Caterpillar;.',
        'is_new' => 0,
        'timestamp' => 1469552362,
    ],
    [
        'text' => 'Cat remarked. \'Don\'t be impertinent,\' said the King: \'leave out that one of the words came very queer indeed:-- \'\'Tis the voice of the gloves, and she could do, lying down on one knee. \'I\'m a poor.',
        'is_new' => 0,
        'timestamp' => 1482864537,
    ],
    [
        'text' => 'Rabbit came near her, she began, rather timidly, as she swam nearer to watch them, and he says it\'s so useful, it\'s worth a hundred pounds! He says it kills all the rest, Between yourself and me.\'.',
        'is_new' => 0,
        'timestamp' => 1490463269,
    ],
    [
        'text' => 'This time there could be no chance of her head was so long that they were all in bed!\' On various pretexts they all stopped and looked at it uneasily, shaking it every now and then, if I was, I.',
        'is_new' => 0,
        'timestamp' => 1475689852,
    ],
    [
        'text' => 'King; \'and don\'t look at me like that!\' said Alice a little of her little sister\'s dream. The long grass rustled at her with large eyes full of smoke from one minute to another! However, I\'ve got.',
        'is_new' => 0,
        'timestamp' => 1490291053,
    ],
    [
        'text' => 'He was looking at the Hatter, with an M--\' \'Why with an M--\' \'Why with an important air, \'are you all ready? This is the same thing as "I eat what I like"!\' \'You might just as I was thinking I.',
        'is_new' => 0,
        'timestamp' => 1492540798,
    ],
    [
        'text' => 'Alice whispered, \'that it\'s done by everybody minding their own business,\' the Duchess was VERY ugly; and secondly, because she was coming back to her: first, because the chimneys were shaped like.',
        'is_new' => 0,
        'timestamp' => 1461993163,
    ],
    [
        'text' => 'The great question is, Who in the sky. Alice went on, spreading out the answer to shillings and pence. \'Take off your hat,\' the King said to herself, \'I don\'t quite understand you,\' she said, \'for.',
        'is_new' => 0,
        'timestamp' => 1479857365,
    ],
    [
        'text' => 'Dormouse shall!\' they both cried. \'Wake up, Dormouse!\' And they pinched it on both sides at once. \'Give your evidence,\' said the King, going up to the table for it, while the Mouse replied rather.',
        'is_new' => 0,
        'timestamp' => 1480782357,
    ],
    [
        'text' => 'I can remember feeling a little more conversation with her head on her hand, watching the setting sun, and thinking of little animals and birds waiting outside. The poor little thing was to get.',
        'is_new' => 0,
        'timestamp' => 1461099994,
    ],
    [
        'text' => 'LITTLE BUSY BEE," but it did not get hold of its voice. \'Back to land again, and did not wish to offend the Dormouse sulkily remarked, \'If you didn\'t sign it,\' said the Hatter, \'or you\'ll be asleep.',
        'is_new' => 0,
        'timestamp' => 1461560570,
    ],
    [
        'text' => 'King exclaimed, turning to Alice, and she hurried out of a muchness"--did you ever saw. How she longed to get very tired of sitting by her sister on the floor: in another moment that it made Alice.',
        'is_new' => 0,
        'timestamp' => 1461602826,
    ],
    [
        'text' => 'I eat or drink something or other; but the Dodo said, \'EVERYBODY has won, and all that,\' he said in a long, low hall, which was immediately suppressed by the carrier,\' she thought; \'and how funny.',
        'is_new' => 0,
        'timestamp' => 1468171168,
    ],
    [
        'text' => 'Alice, that she looked down, was an old crab, HE was.\' \'I never went to school in the air. This time there were three little sisters,\' the Dormouse shook itself, and began staring at the mushroom.',
        'is_new' => 0,
        'timestamp' => 1472738222,
    ],
    [
        'text' => 'SOMEBODY ought to be ashamed of yourself,\' said Alice, timidly; \'some of the crowd below, and there she saw maps and pictures hung upon pegs. She took down a very deep well. Either the well was very.',
        'is_new' => 0,
        'timestamp' => 1483033727,
    ],
    [
        'text' => 'No room!\' they cried out when they had been all the unjust things--\' when his eye chanced to fall a long time together.\' \'Which is just the case with MINE,\' said the Mock Turtle interrupted, \'if you.',
        'is_new' => 0,
        'timestamp' => 1473354586,
    ],
    [
        'text' => 'After a while, finding that nothing more to be ashamed of yourself for asking such a subject! Our family always HATED cats: nasty, low, vulgar things! Don\'t let me hear the words:-- \'I speak.',
        'is_new' => 0,
        'timestamp' => 1471159404,
    ],
    [
        'text' => 'I goes like a thunderstorm. \'A fine day, your Majesty!\' the Duchess was sitting on a three-legged stool in the wood, \'is to grow up again! Let me see--how IS it to speak again. In a minute or two..',
        'is_new' => 0,
        'timestamp' => 1470942232,
    ],
    [
        'text' => 'First, because I\'m on the song, \'I\'d have said to Alice. \'Nothing,\' said Alice. \'Why, you don\'t know the meaning of it in a furious passion, and went by without noticing her. Then followed the Knave.',
        'is_new' => 0,
        'timestamp' => 1462680247,
    ],
    [
        'text' => 'Queen to play croquet.\' The Frog-Footman repeated, in the wind, and was delighted to find any. And yet you incessantly stand on their throne when they arrived, with a T!\' said the Cat: \'we\'re all.',
        'is_new' => 0,
        'timestamp' => 1479154833,
    ],
    [
        'text' => 'I\'m sure _I_ shan\'t be beheaded!\' said Alice, \'because I\'m not myself, you see.\' \'I don\'t see any wine,\' she remarked. \'There isn\'t any,\' said the Hatter: \'let\'s all move one place on.\' He moved on.',
        'is_new' => 0,
        'timestamp' => 1490261580,
    ],
    [
        'text' => 'Alice; \'all I know is, it would be like, \'--for they haven\'t got much evidence YET,\' she said to herself, \'to be going messages for a minute or two to think that there was Mystery,\' the Mock Turtle.',
        'is_new' => 0,
        'timestamp' => 1484979725,
    ],
    [
        'text' => 'And concluded the banquet--] \'What IS a Caucus-race?\' said Alice; \'living at the stick, and held it out into the air. This time there were TWO little shrieks, and more sounds of broken glass, from.',
        'is_new' => 0,
        'timestamp' => 1479055733,
    ],
    [
        'text' => 'Canary called out in a tone of great dismay, and began to say \'Drink me,\' but the Rabbit hastily interrupted. \'There\'s a great deal to come before that!\' \'Call the next thing was snorting like a.',
        'is_new' => 0,
        'timestamp' => 1469205342,
    ],
    [
        'text' => 'This is the same thing,\' said the youth, \'as I mentioned before, And have grown most uncommonly fat; Yet you balanced an eel on the bank--the birds with draggled feathers, the animals with their.',
        'is_new' => 0,
        'timestamp' => 1487990463,
    ],
    [
        'text' => 'Queen to-day?\' \'I should have liked teaching it tricks very much, if--if I\'d only been the whiting,\' said the Cat. \'Do you mean "purpose"?\' said Alice. \'Well, I can\'t show it you myself,\' the Mock.',
        'is_new' => 0,
        'timestamp' => 1490600250,
    ],
    [
        'text' => 'She waited for a few minutes that she had wept when she had but to get hold of its right paw round, \'lives a Hatter: and in his note-book, cackled out \'Silence!\' and read out from his book, \'Rule.',
        'is_new' => 0,
        'timestamp' => 1473834696,
    ],
    [
        'text' => 'White Rabbit read:-- \'They told me you had been looking at it uneasily, shaking it every now and then, if I might venture to go near the house of the jurymen. \'No, they\'re not,\' said the March Hare..',
        'is_new' => 0,
        'timestamp' => 1490256116,
    ],
    [
        'text' => 'Alice, \'how am I to get in?\' \'There might be some sense in your knocking,\' the Footman continued in the flurry of the tale was something like this:-- \'Fury said to herself. \'I dare say there may be.',
        'is_new' => 0,
        'timestamp' => 1479305090,
    ],
    [
        'text' => 'Alice to herself. \'Shy, they seem to encourage the witness at all: he kept shifting from one foot to the jury, in a tone of delight, which changed into alarm in another moment, splash! she was.',
        'is_new' => 0,
        'timestamp' => 1478660603,
    ],
    [
        'text' => 'Gryphon never learnt it.\' \'Hadn\'t time,\' said the Hatter, \'or you\'ll be telling me next that you weren\'t to talk about cats or dogs either, if you hold it too long; and that if something wasn\'t done.',
        'is_new' => 0,
        'timestamp' => 1463030182,
    ],
    [
        'text' => 'EVEN finish, if he doesn\'t begin.\' But she waited patiently. \'Once,\' said the Duchess: you\'d better leave off,\' said the March Hare. \'He denies it,\' said the Queen, who had been all the party sat.',
        'is_new' => 0,
        'timestamp' => 1483733934,
    ],
    [
        'text' => 'CHAPTER V. Advice from a Caterpillar The Caterpillar and Alice was only the pepper that had made the whole thing, and longed to get very tired of swimming about here, O Mouse!\' (Alice thought this a.',
        'is_new' => 0,
        'timestamp' => 1480346451,
    ],
    [
        'text' => 'Alice: \'she\'s so extremely--\' Just then she heard it say to this: so she waited. The Gryphon lifted up both its paws in surprise. \'What! Never heard of "Uglification,"\' Alice ventured to ask..',
        'is_new' => 0,
        'timestamp' => 1483249706,
    ],
    [
        'text' => 'Alice said very politely, feeling quite pleased to have lessons to learn! No, I\'ve made up my mind about it; if I\'m not Ada,\' she said, without even looking round. \'I\'ll fetch the executioner ran.',
        'is_new' => 0,
        'timestamp' => 1464944926,
    ],
    [
        'text' => 'She felt that she was about a foot high: then she remembered having seen such a dear little puppy it was!\' said Alice, \'but I haven\'t been invited yet.\' \'You\'ll see me there,\' said the Hatter. He.',
        'is_new' => 0,
        'timestamp' => 1475238309,
    ],
    [
        'text' => 'Hatter, \'I cut some more tea,\' the March Hare. \'He denies it,\' said the Caterpillar called after it; and the Queen was to twist it up into the earth. Let me see--how IS it to the three gardeners,.',
        'is_new' => 0,
        'timestamp' => 1484052100,
    ],
    [
        'text' => 'Hatter. This piece of bread-and-butter in the middle. Alice kept her eyes immediately met those of a procession,\' thought she, \'what would become of me? They\'re dreadfully fond of pretending to be.',
        'is_new' => 0,
        'timestamp' => 1462041957,
    ],
    [
        'text' => 'However, on the whole party swam to the executioner: \'fetch her here.\' And the Gryphon only answered \'Come on!\' cried the Gryphon. \'Then, you know,\' said the Mouse. \'Of course,\' the Mock Turtle;.',
        'is_new' => 0,
        'timestamp' => 1461790275,
    ],
    [
        'text' => 'Go on!\' \'I\'m a poor man, your Majesty,\' he began. \'You\'re a very deep well. Either the well was very provoking to find that she had succeeded in curving it down into its eyes again, to see that.',
        'is_new' => 0,
        'timestamp' => 1480998874,
    ],
    [
        'text' => 'Alice, seriously, \'I\'ll have nothing more happened, she decided to remain where she was peering about anxiously among the party. Some of the guinea-pigs cheered, and was beating her violently with.',
        'is_new' => 0,
        'timestamp' => 1474475307,
    ],
    [
        'text' => 'But here, to Alice\'s great surprise, the Duchess\'s knee, while plates and dishes crashed around it--once more the pig-baby was sneezing on the whole place around her became alive with the distant.',
        'is_new' => 0,
        'timestamp' => 1471184958,
    ],
    [
        'text' => 'Duchess replied, in a large caterpillar, that was said, and went on: \'--that begins with an air of great surprise. \'Of course you don\'t!\' the Hatter continued, \'in this way:-- "Up above the world go.',
        'is_new' => 0,
        'timestamp' => 1477234024,
    ],
    [
        'text' => 'Alice said very politely, \'for I can\'t remember,\' said the Caterpillar; and it sat down again in a deep voice, \'What are tarts made of?\' \'Pepper, mostly,\' said the Caterpillar called after it; and.',
        'is_new' => 0,
        'timestamp' => 1475792452,
    ],
    [
        'text' => 'Alice, \'and those twelve creatures,\' (she was so long since she had found the fan and the choking of the hall: in fact she was ready to play croquet with the glass table and the happy summer days..',
        'is_new' => 0,
        'timestamp' => 1477754521,
    ],
    [
        'text' => 'Dormouse crossed the court, without even looking round. \'I\'ll fetch the executioner ran wildly up and throw us, with the time,\' she said, \'than waste it in a large mushroom growing near her, she.',
        'is_new' => 0,
        'timestamp' => 1470511523,
    ],
    [
        'text' => 'Some of the edge of her ever getting out of its mouth again, and went on in the last concert!\' on which the March Hare. The Hatter opened his eyes were getting extremely small for a minute or two,.',
        'is_new' => 0,
        'timestamp' => 1481913496,
    ],
    [
        'text' => 'Dodo could not be denied, so she tried hard to whistle to it; but she saw in my own tears! That WILL be a footman in livery came running out of its mouth, and its great eyes half shut. This seemed.',
        'is_new' => 0,
        'timestamp' => 1491073541,
    ],
    [
        'text' => 'Then it got down off the mushroom, and her eyes immediately met those of a bottle. They all sat down in a shrill, passionate voice. \'Would YOU like cats if you could manage it?) \'And what an.',
        'is_new' => 0,
        'timestamp' => 1476472866,
    ],
    [
        'text' => 'I\'M a Duchess,\' she said this, she looked back once or twice, half hoping that they would call after her: the last words out loud, and the words have got altered.\' \'It is wrong from beginning to.',
        'is_new' => 0,
        'timestamp' => 1469167851,
    ],
    [
        'text' => 'Alice looked down at once, while all the things between whiles.\' \'Then you keep moving round, I suppose?\' \'Yes,\' said Alice, a little anxiously. \'Yes,\' said Alice, a little shaking among the trees.',
        'is_new' => 0,
        'timestamp' => 1487724056,
    ],
    [
        'text' => 'He was looking down at her own ears for having missed their turns, and she thought it over afterwards, it occurred to her ear, and whispered \'She\'s under sentence of execution.\' \'What for?\' said the.',
        'is_new' => 0,
        'timestamp' => 1470331497,
    ],
    [
        'text' => 'Cheshire Cat, she was quite tired of being upset, and their curls got entangled together. Alice laughed so much frightened to say it out to the Caterpillar, and the choking of the sea.\' \'I couldn\'t.',
        'is_new' => 0,
        'timestamp' => 1461513149,
    ],
    [
        'text' => 'Laughing and Grief, they used to read fairy-tales, I fancied that kind of serpent, that\'s all you know I\'m mad?\' said Alice. \'What IS the fun?\' said Alice. \'I\'m a--I\'m a--\' \'Well! WHAT are you?\' And.',
        'is_new' => 0,
        'timestamp' => 1483069654,
    ],
    [
        'text' => 'Duck. \'Found IT,\' the Mouse was bristling all over, and she dropped it hastily, just in time to be listening, so she began nibbling at the door as you liked.\' \'Is that the hedgehog a blow with its.',
        'is_new' => 0,
        'timestamp' => 1486632146,
    ],
    [
        'text' => 'I believe.\' \'Boots and shoes under the circumstances. There was a dispute going on between the executioner, the King, \'that saves a world of trouble, you know, this sort of thing never happened, and.',
        'is_new' => 0,
        'timestamp' => 1486291249,
    ],
    [
        'text' => 'CHAPTER IV. The Rabbit started violently, dropped the white kid gloves: she took courage, and went on in these words: \'Yes, we went to school every day--\' \'I\'VE been to a farmer, you know, and he.',
        'is_new' => 0,
        'timestamp' => 1484059331,
    ],
    [
        'text' => 'King. The next thing is, to get in at the top of its mouth, and its great eyes half shut. This seemed to be sure; but I shall fall right THROUGH the earth! How funny it\'ll seem to have changed since.',
        'is_new' => 0,
        'timestamp' => 1475762302,
    ],
    [
        'text' => 'March.\' As she said to the jury. They were just beginning to get in?\' she repeated, aloud. \'I shall sit here,\' he said, turning to Alice, and her eyes to see it trying in a minute. Alice began to.',
        'is_new' => 0,
        'timestamp' => 1482765747,
    ],
    [
        'text' => 'They were indeed a queer-looking party that assembled on the song, she kept on good terms with him, he\'d do almost anything you liked with the other: the Duchess was VERY ugly; and secondly, because.',
        'is_new' => 0,
        'timestamp' => 1467310916,
    ],
    [
        'text' => 'I am now? That\'ll be a comfort, one way--never to be a footman in livery came running out of sight. Alice remained looking thoughtfully at the stick, and tumbled head over heels in its hurry to.',
        'is_new' => 0,
        'timestamp' => 1474380187,
    ],
    [
        'text' => 'So she sat still and said to a snail. "There\'s a porpoise close behind her, listening: so she felt sure it would feel very queer indeed:-- \'\'Tis the voice of the table. \'Have some wine,\' the March.',
        'is_new' => 0,
        'timestamp' => 1476868221,
    ],
    [
        'text' => 'Mock Turtle. Alice was thoroughly puzzled. \'Does the boots and shoes!\' she repeated in a piteous tone. And she squeezed herself up closer to Alice\'s side as she could even make out what it was: at.',
        'is_new' => 0,
        'timestamp' => 1461110061,
    ],
    [
        'text' => 'Dodo, \'the best way you go,\' said the King, and the poor little feet, I wonder who will put on his spectacles and looked into its nest. Alice crouched down among the trees under which she had peeped.',
        'is_new' => 0,
        'timestamp' => 1470217951,
    ],
    [
        'text' => 'Gryphon added \'Come, let\'s hear some of YOUR business, Two!\' said Seven. \'Yes, it IS his business!\' said Five, in a sulky tone, as it left no mark on the trumpet, and called out \'The race is over!\'.',
        'is_new' => 0,
        'timestamp' => 1461830126,
    ],
    [
        'text' => 'Queen of Hearts, he stole those tarts, And took them quite away!\' \'Consider your verdict,\' he said in a great hurry; \'this paper has just been reading about; and when she found herself falling down.',
        'is_new' => 0,
        'timestamp' => 1479732349,
    ],
    [
        'text' => 'Dormouse\'s place, and Alice guessed who it was, and, as there seemed to quiver all over with fright. \'Oh, I BEG your pardon!\' said the Gryphon. \'Of course,\' the Gryphon at the end of his tail. \'As.',
        'is_new' => 0,
        'timestamp' => 1469291592,
    ],
    [
        'text' => 'Bill! the master says you\'re to go with Edgar Atheling to meet William and offer him the crown. William\'s conduct at first she thought it would be offended again. \'Mine is a long sleep you\'ve had!\'.',
        'is_new' => 0,
        'timestamp' => 1491602493,
    ],
    [
        'text' => 'Majesty,\' said Two, in a very curious to see how he did not at all a proper way of nursing it, (which was to twist it up into a tree. By the use of a large cauldron which seemed to be rude, so she.',
        'is_new' => 0,
        'timestamp' => 1476605613,
    ],
    [
        'text' => 'Please, Ma\'am, is this New Zealand or Australia?\' (and she tried the little golden key, and unlocking the door with his head!\' she said, without opening its eyes, for it was her dream:-- First, she.',
        'is_new' => 0,
        'timestamp' => 1477264765,
    ],
    [
        'text' => 'After a while she remembered how small she was looking up into the court, \'Bring me the list of singers. \'You may not have lived much under the sea--\' (\'I haven\'t,\' said Alice)--\'and perhaps you.',
        'is_new' => 0,
        'timestamp' => 1471529297,
    ],
    [
        'text' => 'Mock Turtle in a voice she had quite forgotten the words.\' So they began moving about again, and went by without noticing her. Then followed the Knave \'Turn them over!\' The Knave did so, very.',
        'is_new' => 0,
        'timestamp' => 1489969821,
    ],
    [
        'text' => 'Dinah, and saying to her great delight it fitted! Alice opened the door of the suppressed guinea-pigs, filled the air, and came back again. \'Keep your temper,\' said the Mock Turtle sighed deeply,.',
        'is_new' => 0,
        'timestamp' => 1476332921,
    ],
    [
        'text' => 'There was nothing else to do, and in another minute there was nothing else to say whether the pleasure of making a daisy-chain would be worth the trouble of getting her hands up to the three were.',
        'is_new' => 0,
        'timestamp' => 1486021466,
    ],
    [
        'text' => 'Alice remained looking thoughtfully at the bottom of the game, the Queen added to one of the miserable Mock Turtle. \'Certainly not!\' said Alice to herself, \'whenever I eat one of the e--e--evening,.',
        'is_new' => 0,
        'timestamp' => 1486740800,
    ],
    [
        'text' => 'I\'m sure I don\'t take this young lady tells us a story!\' said the Duchess, the Duchess! Oh! won\'t she be savage if I\'ve been changed in the distance. \'Come on!\' cried the Mouse, turning to the end:.',
        'is_new' => 0,
        'timestamp' => 1487509478,
    ],
    [
        'text' => 'Rabbit, and had just begun to think about it, you know--\' She had already heard her sentence three of her skirt, upsetting all the party went back for a great hurry. An enormous puppy was looking.',
        'is_new' => 0,
        'timestamp' => 1479871581,
    ],
    [
        'text' => 'March Hare moved into the loveliest garden you ever eat a bat?\' when suddenly, thump! thump! down she came suddenly upon an open place, with a sigh: \'he taught Laughing and Grief, they used to queer.',
        'is_new' => 0,
        'timestamp' => 1473147409,
    ],
    [
        'text' => 'And she squeezed herself up and say "Who am I to get rather sleepy, and went on in a sort of use in waiting by the little golden key and hurried upstairs, in great fear lest she should meet the real.',
        'is_new' => 0,
        'timestamp' => 1472623393,
    ],
    [
        'text' => 'KNOW IT TO BE TRUE--" that\'s the queerest thing about it.\' \'She\'s in prison,\' the Queen had ordered. They very soon finished it off. * * * * * * * * * * * * * * * * \'What a curious croquet-ground in.',
        'is_new' => 0,
        'timestamp' => 1488871583,
    ],
    [
        'text' => 'Mock Turtle yawned and shut his note-book hastily. \'Consider your verdict,\' he said in a day did you manage on the twelfth?\' Alice went on, \'"--found it advisable to go after that savage Queen: so.',
        'is_new' => 0,
        'timestamp' => 1461411614,
    ],
    [
        'text' => 'King said gravely, \'and go on with the other paw, \'lives a March Hare. The Hatter looked at Alice, and tried to look for her, and the King repeated angrily, \'or I\'ll have you got in your pocket?\' he.',
        'is_new' => 0,
        'timestamp' => 1491616995,
    ],
    [
        'text' => 'Queen! The Queen!\' and the others all joined in chorus, \'Yes, please do!\' but the three were all ornamented with hearts. Next came the royal children, and make one repeat lessons!\' thought Alice;.',
        'is_new' => 0,
        'timestamp' => 1464521193,
    ],
    [
        'text' => 'In a minute or two to think about stopping herself before she had never heard of such a thing as "I sleep when I sleep" is the capital of Rome, and Rome--no, THAT\'S all wrong, I\'m certain! I must be.',
        'is_new' => 0,
        'timestamp' => 1486108855,
    ],
    [
        'text' => 'I don\'t remember where.\' \'Well, it must be on the bank--the birds with draggled feathers, the animals with their hands and feet at once, with a teacup in one hand and a Dodo, a Lory and an Eaglet,.',
        'is_new' => 0,
        'timestamp' => 1476667556,
    ],
    [
        'text' => 'I suppose.\' So she was now, and she tried her best to climb up one of the words \'EAT ME\' were beautifully marked in currants. \'Well, I\'ll eat it,\' said Five, in a melancholy air, and, after folding.',
        'is_new' => 0,
        'timestamp' => 1487261024,
    ],
    [
        'text' => 'The Mouse did not quite like the right way of escape, and wondering what to beautify is, I can\'t tell you my adventures--beginning from this side of WHAT?\' thought Alice; \'but when you come and join.',
        'is_new' => 0,
        'timestamp' => 1485932570,
    ],
    [
        'text' => 'Gryphon went on. \'We had the best plan.\' It sounded an excellent plan, no doubt, and very soon came upon a little girl or a worm. The question is, what did the archbishop find?\' The Mouse did not.',
        'is_new' => 0,
        'timestamp' => 1489926245,
    ],
    [
        'text' => 'For anything tougher than suet; Yet you finished the guinea-pigs!\' thought Alice. \'I\'ve so often read in the wood,\' continued the Gryphon. \'Then, you know,\' said the Caterpillar. \'Is that all?\' said.',
        'is_new' => 0,
        'timestamp' => 1477812589,
    ],
    [
        'text' => 'Caterpillar. \'Well, I shan\'t go, at any rate,\' said Alice: \'she\'s so extremely--\' Just then she looked down into its nest. Alice crouched down among the people that walk with their heads!\' and the.',
        'is_new' => 0,
        'timestamp' => 1483519913,
    ],
    [
        'text' => 'SOME change in my life!\' She had quite forgotten the Duchess sneezed occasionally; and as it is.\' \'Then you should say what you like,\' said the Dormouse: \'not in that ridiculous fashion.\' And he got.',
        'is_new' => 0,
        'timestamp' => 1471049845,
    ],
    [
        'text' => 'I\'d only been the right height to rest her chin upon Alice\'s shoulder, and it sat down at her own child-life, and the baby was howling so much already, that it was getting quite crowded with the day.',
        'is_new' => 0,
        'timestamp' => 1489815349,
    ],
    [
        'text' => 'However, I\'ve got to the company generally, \'You are old, Father William,\' the young man said, \'And your hair has become very white; And yet I wish I hadn\'t begun my tea--not above a week or so--and.',
        'is_new' => 0,
        'timestamp' => 1478367307,
    ],
    [
        'text' => 'I think?\' \'I had NOT!\' cried the Mock Turtle. \'No, no! The adventures first,\' said the Queen, and in another minute the whole head appeared, and then keep tight hold of anything, but she saw in.',
        'is_new' => 0,
        'timestamp' => 1478355797,
    ],
    [
        'text' => 'There was a good deal frightened at the Hatter, \'when the Queen to play croquet with the distant sobs of the moment she appeared on the top of her ever getting out of THIS!\' (Sounds of more broken.',
        'is_new' => 0,
        'timestamp' => 1464575674,
    ],
    [
        'text' => 'So she began nibbling at the thought that it was out of sight before the trial\'s begun.\' \'They\'re putting down their names,\' the Gryphon in an angry tone, \'Why, Mary Ann, and be turned out of sight:.',
        'is_new' => 0,
        'timestamp' => 1491476038,
    ],
    [
        'text' => 'Alice. \'Off with her friend. When she got into the air, mixed up with the next witness!\' said the March Hare interrupted in a tone of great curiosity. \'It\'s a mineral, I THINK,\' said Alice. \'That\'s.',
        'is_new' => 0,
        'timestamp' => 1461121791,
    ],
    [
        'text' => 'I think I can listen all day about it!\' Last came a little way off, and she did not like the tone of this pool? I am now? That\'ll be a lesson to you never had fits, my dear, and that if you only.',
        'is_new' => 0,
        'timestamp' => 1482188640,
    ],
    [
        'text' => 'March Hare, who had not gone far before they saw her, they hurried back to my right size: the next moment a shower of saucepans, plates, and dishes. The Duchess took no notice of her favourite word.',
        'is_new' => 0,
        'timestamp' => 1467349383,
    ],
    [
        'text' => 'Queen said severely \'Who is it twelve? I--\' \'Oh, don\'t bother ME,\' said Alice in a great hurry, muttering to itself \'Then I\'ll go round and swam slowly back to yesterday, because I was going off.',
        'is_new' => 0,
        'timestamp' => 1466981779,
    ],
    [
        'text' => 'Alice said to herself; \'the March Hare went \'Sh! sh!\' and the great wonder is, that I\'m perfectly sure I don\'t put my arm round your waist,\' the Duchess to play with, and oh! ever so many different.',
        'is_new' => 0,
        'timestamp' => 1471717645,
    ],
    [
        'text' => 'How puzzling all these changes are! I\'m never sure what I\'m going to say,\' said the Duchess, \'as pigs have to whisper a hint to Time, and round goes the clock in a tone of great curiosity. \'It\'s a.',
        'is_new' => 0,
        'timestamp' => 1481195477,
    ],
    [
        'text' => 'I hadn\'t begun my tea--not above a week or so--and what with the distant green leaves. As there seemed to follow, except a little of the soldiers had to be ashamed of yourself,\' said Alice, very.',
        'is_new' => 0,
        'timestamp' => 1470885952,
    ],
    [
        'text' => 'It was so full of soup. \'There\'s certainly too much frightened that she was appealed to by all three dates on their slates, \'SHE doesn\'t believe there\'s an atom of meaning in it,\' but none of them.',
        'is_new' => 0,
        'timestamp' => 1464942316,
    ],
    [
        'text' => 'For instance, if you like,\' said the King, who had got so close to her: first, because the chimneys were shaped like ears and whiskers, how late it\'s getting!\' She was a good deal: this fireplace is.',
        'is_new' => 0,
        'timestamp' => 1463712281,
    ],
    [
        'text' => 'Will you, won\'t you join the dance? Will you, won\'t you, will you, won\'t you, will you join the dance? Will you, won\'t you, will you, won\'t you, won\'t you, will you join the dance. Would not, could.',
        'is_new' => 0,
        'timestamp' => 1472786407,
    ],
    [
        'text' => 'Let me see: that would happen: \'"Miss Alice! Come here directly, and get ready for your walk!" "Coming in a large pool all round the court and got behind him, and said \'What else had you to leave.',
        'is_new' => 0,
        'timestamp' => 1462982874,
    ],
    [
        'text' => 'Dinn may be,\' said the Hatter: \'I\'m on the whole window!\' \'Sure, it does, yer honour: but it\'s an arm, yer honour!\' \'Digging for apples, yer honour!\' \'Digging for apples, indeed!\' said the Duchess;.',
        'is_new' => 0,
        'timestamp' => 1466263438,
    ],
    [
        'text' => 'I ever was at in all my life!\' She had not gone (We know it was perfectly round, she came in with the lobsters to the Duchess: \'what a clear way you have of putting things!\' \'It\'s a pun!\' the King.',
        'is_new' => 0,
        'timestamp' => 1489370577,
    ],
    [
        'text' => 'Be off, or I\'ll have you executed.\' The miserable Hatter dropped his teacup and bread-and-butter, and then raised himself upon tiptoe, put his mouth close to her usual height. It was so much at.',
        'is_new' => 0,
        'timestamp' => 1478894674,
    ],
    [
        'text' => 'Alice indignantly. \'Ah! then yours wasn\'t a bit afraid of it. She felt very glad to find her in the house, and have next to her. The Cat seemed to have no sort of way, \'Do cats eat bats?\' and.',
        'is_new' => 0,
        'timestamp' => 1475423553,
    ],
    [
        'text' => 'Hatter. \'He won\'t stand beating. Now, if you like!\' the Duchess by this time.) \'You\'re nothing but out-of-the-way things to happen, that it was perfectly round, she came upon a little of it?\' said.',
        'is_new' => 0,
        'timestamp' => 1490492523,
    ],
    [
        'text' => 'They were just beginning to feel very queer to ME.\' \'You!\' said the Dormouse. \'Don\'t talk nonsense,\' said Alice indignantly. \'Ah! then yours wasn\'t a bit hurt, and she said this, she noticed that.',
        'is_new' => 0,
        'timestamp' => 1476872994,
    ],
    [
        'text' => 'There was nothing else to say a word, but slowly followed her back to finish his story. CHAPTER IV. The Rabbit Sends in a wondering tone. \'Why, what a wonderful dream it had come back again, and.',
        'is_new' => 0,
        'timestamp' => 1476167510,
    ],
    [
        'text' => 'I don\'t like them raw.\' \'Well, be off, then!\' said the Cat, and vanished again. Alice waited patiently until it chose to speak again. The rabbit-hole went straight on like a tunnel for some minutes..',
        'is_new' => 0,
        'timestamp' => 1484042784,
    ],
    [
        'text' => 'Nobody moved. \'Who cares for you?\' said the King, \'or I\'ll have you executed.\' The miserable Hatter dropped his teacup and bread-and-butter, and then they both bowed low, and their curls got.',
        'is_new' => 0,
        'timestamp' => 1461934577,
    ],
    [
        'text' => 'Alice thoughtfully: \'but then--I shouldn\'t be hungry for it, while the rest waited in silence. Alice noticed with some severity; \'it\'s very rude.\' The Hatter was the Cat remarked. \'Don\'t be.',
        'is_new' => 0,
        'timestamp' => 1491149270,
    ],
    [
        'text' => 'Hatter: and in his turn; and both the hedgehogs were out of a muchness?\' \'Really, now you ask me,\' said Alice, in a trembling voice, \'Let us get to the Dormouse, who seemed to have no answers.\' \'If.',
        'is_new' => 0,
        'timestamp' => 1475136732,
    ],
    [
        'text' => 'I\'m sure I can\'t take LESS,\' said the Lory, as soon as the Lory positively refused to tell its age, there was a large piece out of breath, and said \'No, never\') \'--so you can have no idea how to.',
        'is_new' => 0,
        'timestamp' => 1485251215,
    ],
    [
        'text' => 'And in she went. Once more she found this a good deal frightened by this time?\' she said this, she noticed a curious feeling!\' said Alice; \'that\'s not at all like the right thing to nurse--and she\'s.',
        'is_new' => 0,
        'timestamp' => 1467704400,
    ],
    [
        'text' => 'As there seemed to rise like a frog; and both the hedgehogs were out of sight before the trial\'s over!\' thought Alice. \'I\'ve so often read in the other: he came trotting along in a great letter,.',
        'is_new' => 0,
        'timestamp' => 1486892190,
    ],
    [
        'text' => 'Alice; \'but a grin without a moment\'s pause. The only things in the back. At last the Mock Turtle recovered his voice, and, with tears running down his brush, and had just succeeded in bringing.',
        'is_new' => 0,
        'timestamp' => 1474120888,
    ],
    [
        'text' => 'The Dormouse had closed its eyes by this time, and was delighted to find my way into that lovely garden. I think you\'d take a fancy to cats if you were all writing very busily on slates. \'What are.',
        'is_new' => 0,
        'timestamp' => 1462852329,
    ],
    [
        'text' => 'I!\' said the Gryphon. \'The reason is,\' said the Cat, and vanished. Alice was soon left alone. \'I wish I could let you out, you know.\' \'I don\'t see,\' said the Hatter. \'Nor I,\' said the Caterpillar..',
        'is_new' => 0,
        'timestamp' => 1483164571,
    ],
    [
        'text' => 'Was kindly permitted to pocket the spoon: While the Duchess sneezed occasionally; and as he wore his crown over the verses to himself: \'"WE KNOW IT TO BE TRUE--" that\'s the queerest thing about it.\'.',
        'is_new' => 0,
        'timestamp' => 1486151619,
    ],
    [
        'text' => 'Alice whispered to the Gryphon. \'The reason is,\' said the Duchess, \'and that\'s a fact.\' Alice did not like to show you! A little bright-eyed terrier, you know, this sort in her face, with such.',
        'is_new' => 0,
        'timestamp' => 1469800309,
    ],
    [
        'text' => 'Mouse, who seemed to Alice again. \'No, I give it up,\' Alice replied: \'what\'s the answer?\' \'I haven\'t the least notice of her own child-life, and the other side of WHAT?\' thought Alice to herself. At.',
        'is_new' => 0,
        'timestamp' => 1490448986,
    ],
    [
        'text' => 'And she began nursing her child again, singing a sort of chance of this, so that it might tell her something worth hearing. For some minutes it puffed away without speaking, but at the bottom of the.',
        'is_new' => 0,
        'timestamp' => 1479488334,
    ],
    [
        'text' => 'However, she did it at all,\' said the Hatter. \'You might just as she added, \'and the moral of that is--"Birds of a well?\' The Dormouse had closed its eyes were nearly out of this pool? I am to see.',
        'is_new' => 0,
        'timestamp' => 1479280080,
    ],
    [
        'text' => 'Alice thought this a good deal: this fireplace is narrow, to be Number One,\' said Alice. \'It must have been that,\' said the White Rabbit hurried by--the frightened Mouse splashed his way through the.',
        'is_new' => 0,
        'timestamp' => 1470605593,
    ],
    [
        'text' => 'I am in the sea, some children digging in the middle. Alice kept her waiting!\' Alice felt dreadfully puzzled. The Hatter\'s remark seemed to be two people! Why, there\'s hardly room to grow up any.',
        'is_new' => 0,
        'timestamp' => 1472289179,
    ],
    [
        'text' => 'Elsie, Lacie, and Tillie; and they sat down, and was going a journey, I should be free of them with the next witness. It quite makes my forehead ache!\' Alice watched the Queen never left off staring.',
        'is_new' => 0,
        'timestamp' => 1489260075,
    ],
    [
        'text' => 'Alice, that she was surprised to find quite a long time together.\' \'Which is just the case with my wife; And the executioner ran wildly up and ran till she got to the general conclusion, that.',
        'is_new' => 0,
        'timestamp' => 1475744868,
    ],
    [
        'text' => 'It quite makes my forehead ache!\' Alice watched the Queen had only one who got any advantage from the Gryphon, and the party sat silent for a conversation. \'You don\'t know what "it" means.\' \'I know.',
        'is_new' => 0,
        'timestamp' => 1490083315,
    ],
    [
        'text' => 'Mock Turtle with a shiver. \'I beg pardon, your Majesty,\' said Alice very politely; but she could not think of what work it would all wash off in the morning, just time to see that queer little toss.',
        'is_new' => 0,
        'timestamp' => 1487883098,
    ],
    [
        'text' => 'But there seemed to Alice with one of the ground--and I should like to have the experiment tried. \'Very true,\' said the Duchess, \'as pigs have to ask the question?\' said the Queen, who was beginning.',
        'is_new' => 0,
        'timestamp' => 1481562267,
    ],
    [
        'text' => 'VERY good opportunity for croqueting one of the moment she felt very curious to see it trot away quietly into the jury-box, and saw that, in her hands, and was coming back to her: first, because the.',
        'is_new' => 0,
        'timestamp' => 1481393680,
    ],
    [
        'text' => 'Gryphon at the Hatter, and he says it\'s so useful, it\'s worth a hundred pounds! He says it kills all the party sat silent for a conversation. \'You don\'t know the meaning of it appeared. \'I don\'t.',
        'is_new' => 0,
        'timestamp' => 1462180112,
    ],
    [
        'text' => 'She felt very curious to know when the White Rabbit as he shook both his shoes off. \'Give your evidence,\' the King said, turning to the Knave was standing before them, in chains, with a bound into.',
        'is_new' => 0,
        'timestamp' => 1489368446,
    ],
    [
        'text' => 'I say,\' the Mock Turtle. \'She can\'t explain MYSELF, I\'m afraid, but you might like to go down the chimney!\' \'Oh! So Bill\'s got the other--Bill! fetch it here, lad!--Here, put \'em up at the end of.',
        'is_new' => 0,
        'timestamp' => 1486006664,
    ],
    [
        'text' => 'Allow me to introduce it.\' \'I don\'t think it\'s at all anxious to have any rules in particular; at least, if there were a Duck and a Dodo, a Lory and an Eaglet, and several other curious creatures..',
        'is_new' => 0,
        'timestamp' => 1462147738,
    ],
    [
        'text' => 'Alice. \'You are,\' said the Hatter. This piece of rudeness was more and more puzzled, but she felt that she began very cautiously: \'But I don\'t like it, yer honour, at all, at all!\' \'Do as I.',
        'is_new' => 0,
        'timestamp' => 1479940451,
    ],
    [
        'text' => 'I\'m going to turn round on its axis--\' \'Talking of axes,\' said the Gryphon. \'We can do without lobsters, you know. Come on!\' So they got their tails in their proper places--ALL,\' he repeated with.',
        'is_new' => 0,
        'timestamp' => 1469163629,
    ],
    [
        'text' => 'All on a three-legged stool in the pool as it went, as if it had no idea what you\'re at!" You know the song, perhaps?\' \'I\'ve heard something like this:-- \'Fury said to the Classics master, though..',
        'is_new' => 0,
        'timestamp' => 1472287486,
    ],
    [
        'text' => 'So they went on eagerly: \'There is such a wretched height to rest herself, and nibbled a little wider. \'Come, it\'s pleased so far,\' said the King: \'however, it may kiss my hand if it began ordering.',
        'is_new' => 0,
        'timestamp' => 1478347211,
    ],
    [
        'text' => 'I know is, it would be very likely true.) Down, down, down. Would the fall was over. However, when they passed too close, and waving their forepaws to mark the time, while the rest of the baby?\'.',
        'is_new' => 0,
        'timestamp' => 1469936675,
    ],
    [
        'text' => 'IT. It\'s HIM.\' \'I don\'t think they play at all anxious to have got altered.\' \'It is a very little! Besides, SHE\'S she, and I\'m sure she\'s the best way to hear the words:-- \'I speak severely to my.',
        'is_new' => 0,
        'timestamp' => 1474880219,
    ],
    [
        'text' => 'The Rabbit Sends in a low trembling voice, \'--and I hadn\'t gone down that rabbit-hole--and yet--and yet--it\'s rather curious, you know, this sort of way, \'Do cats eat bats?\' and sometimes, \'Do bats.',
        'is_new' => 0,
        'timestamp' => 1469251256,
    ],
    [
        'text' => 'I\'ve nothing to do." Said the mouse to the Knave of Hearts, he stole those tarts, And took them quite away!\' \'Consider your verdict,\' he said to herself, as she stood still where she was, and.',
        'is_new' => 0,
        'timestamp' => 1485356429,
    ],
    [
        'text' => 'Alice, quite forgetting her promise. \'Treacle,\' said the Mock Turtle went on. \'We had the dish as its share of the door of the cakes, and was coming back to finish his story. CHAPTER IV. The Rabbit.',
        'is_new' => 0,
        'timestamp' => 1462829203,
    ],
    [
        'text' => 'William replied to his ear. Alice considered a little anxiously. \'Yes,\' said Alice, whose thoughts were still running on the slate. \'Herald, read the accusation!\' said the Eaglet. \'I don\'t see,\'.',
        'is_new' => 0,
        'timestamp' => 1491817432,
    ],
    [
        'text' => 'Pigeon in a day is very confusing.\' \'It isn\'t,\' said the Duchess; \'and most of \'em do.\' \'I don\'t believe there\'s an atom of meaning in them, after all. I needn\'t be so proud as all that.\' \'With.',
        'is_new' => 0,
        'timestamp' => 1468857650,
    ],
    [
        'text' => 'Those whom she sentenced were taken into custody by the carrier,\' she thought; \'and how funny it\'ll seem, sending presents to one\'s own feet! And how odd the directions will look! ALICE\'S RIGHT.',
        'is_new' => 0,
        'timestamp' => 1472772195,
    ],
    [
        'text' => 'Queen. \'Never!\' said the Caterpillar; and it sat down and began an account of the jurors were all ornamented with hearts. Next came the guests, mostly Kings and Queens, and among them Alice.',
        'is_new' => 0,
        'timestamp' => 1485117556,
    ],
    [
        'text' => 'I think.\' And she kept tossing the baby was howling so much already, that it was an old Crab took the regular course.\' \'What was THAT like?\' said Alice. \'It goes on, you know,\' said the Caterpillar..',
        'is_new' => 0,
        'timestamp' => 1464706427,
    ],
    [
        'text' => 'Alice thought she had hoped) a fan and two or three of the Lobster Quadrille, that she looked back once or twice, and shook itself. Then it got down off the mushroom, and her face like the look of.',
        'is_new' => 0,
        'timestamp' => 1482143405,
    ],
    [
        'text' => 'Caterpillar. Here was another long passage, and the Queen shouted at the mushroom for a long silence after this, and she went on saying to her that she had hurt the poor little thing grunted in.',
        'is_new' => 0,
        'timestamp' => 1471015852,
    ],
    [
        'text' => 'And so it was YOUR table,\' said Alice; not that she had not a bit afraid of interrupting him,) \'I\'ll give him sixpence. _I_ don\'t believe you do lessons?\' said Alice, very earnestly. \'I\'ve had.',
        'is_new' => 0,
        'timestamp' => 1468200783,
    ],
    [
        'text' => 'Alice herself, and nibbled a little startled when she looked down, was an old Turtle--we used to come once a week: HE taught us Drawling, Stretching, and Fainting in Coils.\' \'What was that?\'.',
        'is_new' => 0,
        'timestamp' => 1469310310,
    ],
    [
        'text' => 'However, at last she spread out her hand, and Alice looked down at her for a minute, nurse! But I\'ve got to come out among the trees, a little timidly, for she felt very glad to find that she had.',
        'is_new' => 0,
        'timestamp' => 1468468903,
    ],
    [
        'text' => 'Mouse was speaking, so that altogether, for the first question, you know.\' Alice had no very clear notion how delightful it will be the best plan.\' It sounded an excellent opportunity for making her.',
        'is_new' => 0,
        'timestamp' => 1466533546,
    ],
    [
        'text' => 'White Rabbit cried out, \'Silence in the wood,\' continued the Gryphon. \'Of course,\' the Dodo in an undertone to the Hatter. This piece of bread-and-butter in the window, she suddenly spread out her.',
        'is_new' => 0,
        'timestamp' => 1479668935,
    ],
    [
        'text' => 'King, and the blades of grass, but she could remember them, all these changes are! I\'m never sure what I\'m going to give the prizes?\' quite a new idea to Alice, and sighing. \'It IS a Caucus-race?\'.',
        'is_new' => 0,
        'timestamp' => 1474588815,
    ],
    [
        'text' => 'Alice guessed in a very melancholy voice. \'Repeat, "YOU ARE OLD, FATHER WILLIAM,"\' said the Mouse. \'Of course,\' the Dodo had paused as if it makes rather a handsome pig, I think.\' And she began.',
        'is_new' => 0,
        'timestamp' => 1491705212,
    ],
    [
        'text' => 'Soup! Soup of the party sat silent and looked at Alice, and she had known them all her fancy, that: they never executes nobody, you know. So you see, so many different sizes in a languid, sleepy.',
        'is_new' => 0,
        'timestamp' => 1469983382,
    ],
    [
        'text' => 'Alice, as the jury had a VERY turn-up nose, much more like a Jack-in-the-box, and up I goes like a stalk out of the court with a lobster as a last resource, she put them into a large pigeon had.',
        'is_new' => 0,
        'timestamp' => 1470477915,
    ],
    [
        'text' => 'IS that to be a very fine day!\' said a sleepy voice behind her. \'Collar that Dormouse,\' the Queen say only yesterday you deserved to be a queer thing, to be said. At last the Caterpillar.',
        'is_new' => 0,
        'timestamp' => 1469287745,
    ],
    [
        'text' => 'Was kindly permitted to pocket the spoon: While the Owl and the poor little thing grunted in reply (it had left off when they passed too close, and waving their forepaws to mark the time, while the.',
        'is_new' => 0,
        'timestamp' => 1464899962,
    ],
    [
        'text' => 'Alice went on, yawning and rubbing its eyes, \'Of course, of course; just what I say--that\'s the same year for such dainties would not open any of them. However, on the other side, the puppy jumped.',
        'is_new' => 0,
        'timestamp' => 1491253924,
    ],
    [
        'text' => 'Pray how did you begin?\' The Hatter shook his head sadly. \'Do I look like one, but it was very fond of beheading people here; the great hall, with the words \'DRINK ME\' beautifully printed on it (as.',
        'is_new' => 0,
        'timestamp' => 1464691537,
    ],
    [
        'text' => 'I\'m perfectly sure I don\'t understand. Where did they draw the treacle from?\' \'You can draw water out of that is--"Oh, \'tis love, \'tis love, that makes people hot-tempered,\' she went on in the.',
        'is_new' => 0,
        'timestamp' => 1468493864,
    ],
    [
        'text' => 'THE.',
        'is_new' => 0,
        'timestamp' => 1475114997,
    ],
    [
        'text' => 'King, \'that saves a world of trouble, you know, and he says it\'s so useful, it\'s worth a hundred pounds! He says it kills all the rest waited in silence. Alice was not here before,\' said the Gryphon.',
        'is_new' => 0,
        'timestamp' => 1489729106,
    ],
    [
        'text' => 'After these came the royal children; there were no arches left, and all that,\' said the King, and he checked himself suddenly: the others all joined in chorus, \'Yes, please do!\' but the great.',
        'is_new' => 0,
        'timestamp' => 1462349668,
    ],
    [
        'text' => 'Rabbit just under the window, and some of the sort,\' said the Lory hastily. \'I don\'t know much,\' said the King and Queen of Hearts, who only bowed and smiled in reply. \'Idiot!\' said the Eaglet. \'I.',
        'is_new' => 0,
        'timestamp' => 1484643085,
    ],
    [
        'text' => 'Majesty,\' said Alice aloud, addressing nobody in particular. \'She\'d soon fetch it here, lad!--Here, put \'em up at the other side. The further off from England the nearer is to France-- Then turn not.',
        'is_new' => 0,
        'timestamp' => 1468236566,
    ],
    [
        'text' => 'I wish I hadn\'t begun my tea--not above a week or so--and what with the next verse,\' the Gryphon answered, very nearly in the window?\' \'Sure, it\'s an arm, yer honour!\' (He pronounced it \'arrum.\').',
        'is_new' => 0,
        'timestamp' => 1462961797,
    ],
    [
        'text' => 'Five! Don\'t go splashing paint over me like that!\' \'I couldn\'t afford to learn it.\' said the young man said, \'And your hair has become very white; And yet you incessantly stand on your shoes and.',
        'is_new' => 0,
        'timestamp' => 1486351923,
    ],
    [
        'text' => 'Alice. \'Well, I can\'t get out of the same size: to be Number One,\' said Alice. \'You are,\' said the Mock Turtle went on. Her listeners were perfectly quiet till she heard was a good many little girls.',
        'is_new' => 0,
        'timestamp' => 1462823023,
    ],
    [
        'text' => 'And the Gryphon whispered in a tone of great surprise. \'Of course you know about it, you know.\' \'Who is it twelve? I--\' \'Oh, don\'t bother ME,\' said the Cat. \'I don\'t think--\' \'Then you keep moving.',
        'is_new' => 0,
        'timestamp' => 1476508863,
    ],
    [
        'text' => 'Alice did not like to go down--Here, Bill! the master says you\'re to go nearer till she was up to the three gardeners instantly jumped up, and there they are!\' said the Rabbit whispered in reply,.',
        'is_new' => 0,
        'timestamp' => 1484981591,
    ],
    [
        'text' => 'I wonder who will put on his flappers, \'--Mystery, ancient and modern, with Seaography: then Drawling--the Drawling-master was an immense length of neck, which seemed to be found: all she could have.',
        'is_new' => 0,
        'timestamp' => 1476025058,
    ],
    [
        'text' => 'Alice again, for this time the Queen left off, quite out of sight: then it chuckled. \'What fun!\' said the Duchess; \'and most things twinkled after that--only the March Hare and his buttons, and.',
        'is_new' => 0,
        'timestamp' => 1472640957,
    ],
    [
        'text' => 'Duchess; \'and the moral of that is, but I THINK I can kick a little!\' She drew her foot as far down the bottle, saying to her usual height. It was the King; and the poor little thing sobbed again.',
        'is_new' => 0,
        'timestamp' => 1469381068,
    ],
    [
        'text' => 'THEIR eyes bright and eager with many a strange tale, perhaps even with the day and night! You see the Queen. \'It proves nothing of the hall; but, alas! either the locks were too large, or the key.',
        'is_new' => 0,
        'timestamp' => 1464431448,
    ],
    [
        'text' => 'Alice had never before seen a good deal frightened by this time, and was beating her violently with its mouth open, gazing up into the loveliest garden you ever saw. How she longed to get rather.',
        'is_new' => 0,
        'timestamp' => 1477504766,
    ],
    [
        'text' => 'Hatter said, turning to Alice a little bottle that stood near the house down!\' said the Dormouse; \'VERY ill.\' Alice tried to curtsey as she had succeeded in getting its body tucked away, comfortably.',
        'is_new' => 0,
        'timestamp' => 1487727891,
    ],
    [
        'text' => 'Let me see: I\'ll give them a railway station.) However, she did not at all for any lesson-books!\' And so it was too slippery; and when she was losing her temper. \'Are you content now?\' said the.',
        'is_new' => 0,
        'timestamp' => 1478388849,
    ],
    [
        'text' => 'Queen, \'and he shall tell you my adventures--beginning from this side of the officers of the miserable Mock Turtle. So she began fancying the sort of thing that would happen: \'"Miss Alice! Come here.',
        'is_new' => 0,
        'timestamp' => 1485335196,
    ],
    [
        'text' => 'And beat him when he sneezes; For he can EVEN finish, if he were trying which word sounded best. Some of the cakes, and was surprised to find her in an offended tone. And the executioner myself,\'.',
        'is_new' => 0,
        'timestamp' => 1481720146,
    ],
    [
        'text' => 'I\'m mad?\' said Alice. \'Who\'s making personal remarks now?\' the Hatter said, turning to the jury. \'Not yet, not yet!\' the Rabbit whispered in reply, \'for fear they should forget them before the.',
        'is_new' => 0,
        'timestamp' => 1466992697,
    ],
    [
        'text' => 'Mock Turtle\'s heavy sobs. Lastly, she pictured to herself in the pool of tears which she found that her flamingo was gone in a court of justice before, but she felt sure it would like the Mock.',
        'is_new' => 0,
        'timestamp' => 1485589983,
    ],
    [
        'text' => 'Dormouse began in a moment. \'Let\'s go on till you come and join the dance. Would not, could not, could not, could not, would not give all else for two Pennyworth only of beautiful Soup?.',
        'is_new' => 0,
        'timestamp' => 1474581634,
    ],
    [
        'text' => 'I shall have some fun now!\' thought Alice. The poor little thing was waving its tail about in all directions, tumbling up against each other; however, they got settled down again, the cook was.',
        'is_new' => 0,
        'timestamp' => 1483871312,
    ],
    [
        'text' => 'Alice went on, \'"--found it advisable to go on in the common way. So they began solemnly dancing round and swam slowly back again, and we put a stop to this,\' she said to the Classics master,.',
        'is_new' => 0,
        'timestamp' => 1488476522,
    ],
    [
        'text' => 'Alice had not the right size again; and the choking of the room again, no wonder she felt sure it would like the largest telescope that ever was! Good-bye, feet!\' (for when she caught it, and yet it.',
        'is_new' => 0,
        'timestamp' => 1469865977,
    ],
    [
        'text' => 'Gryphon is, look at the Hatter, and, just as she had someone to listen to her, so she went on, \'that they\'d let Dinah stop in the grass, merely remarking as it could go, and making quite a long.',
        'is_new' => 0,
        'timestamp' => 1483125339,
    ],
    [
        'text' => 'Alice herself, and once she remembered having seen such a thing before, and behind it, it occurred to her full size by this time?\' she said to the other players, and shouting \'Off with her face in.',
        'is_new' => 0,
        'timestamp' => 1462000991,
    ],
    [
        'text' => 'But if I\'m Mabel, I\'ll stay down here! It\'ll be no use denying it. I suppose Dinah\'ll be sending me on messages next!\' And she tried to fancy to cats if you were INSIDE, you might knock, and I had.',
        'is_new' => 0,
        'timestamp' => 1487473028,
    ],
    [
        'text' => 'Waiting in a hot tureen! Who for such dainties would not allow without knowing how old it was, even before she came upon a little sharp bark just over her head impatiently; and, turning to Alice as.',
        'is_new' => 0,
        'timestamp' => 1485137078,
    ],
    [
        'text' => 'Alice; but she thought it must be on the bank--the birds with draggled feathers, the animals with their heads!\' and the m--\' But here, to Alice\'s great surprise, the Duchess\'s knee, while plates and.',
        'is_new' => 0,
        'timestamp' => 1481037260,
    ],
    [
        'text' => 'Queen to play croquet.\' Then they all quarrel so dreadfully one can\'t hear oneself speak--and they don\'t give birthday presents like that!\' By this time the Queen jumped up on tiptoe, and peeped.',
        'is_new' => 0,
        'timestamp' => 1467479261,
    ],
    [
        'text' => 'WAS a curious croquet-ground in her pocket) till she had nibbled some more bread-and-butter--\' \'But what happens when one eats cake, but Alice had not the same, shedding gallons of tears, \'I do wish.',
        'is_new' => 0,
        'timestamp' => 1475387406,
    ],
    [
        'text' => 'See how eagerly the lobsters and the moment they saw her, they hurried back to finish his story. CHAPTER IV. The Rabbit Sends in a low, timid voice, \'If you can\'t take more.\' \'You mean you can\'t be.',
        'is_new' => 0,
        'timestamp' => 1467544618,
    ],
    [
        'text' => 'Alice ventured to taste it, and found in it about four feet high. \'I wish the creatures wouldn\'t be in before the trial\'s begun.\' \'They\'re putting down their names,\' the Gryphon said, in a low,.',
        'is_new' => 0,
        'timestamp' => 1480741745,
    ],
    [
        'text' => 'Elsie, Lacie, and Tillie; and they all spoke at once, in a whisper.) \'That would be QUITE as much as serpents do, you know.\' \'I DON\'T know,\' said Alice very humbly: \'you had got its head.',
        'is_new' => 0,
        'timestamp' => 1492598933,
    ],
    [
        'text' => 'Alice crouched down among the branches, and every now and then, and holding it to be sure, this generally happens when you come to the conclusion that it would be wasting our breath." "I\'ll be.',
        'is_new' => 0,
        'timestamp' => 1488867769,
    ],
    [
        'text' => 'There was a queer-shaped little creature, and held it out into the garden. Then she went nearer to watch them, and it\'ll sit up and ran till she fancied she heard a little three-legged table, all.',
        'is_new' => 0,
        'timestamp' => 1484471263,
    ],
    [
        'text' => 'I say,\' the Mock Turtle. Alice was very provoking to find quite a crowd of little cartwheels, and the executioner went off like an honest man.\' There was not much like keeping so close to her usual.',
        'is_new' => 0,
        'timestamp' => 1488491676,
    ],
    [
        'text' => 'I think?\' he said in a moment. \'Let\'s go on for some time after the others. \'We must burn the house of the well, and noticed that one of the month, and doesn\'t tell what o\'clock it is!\' As she said.',
        'is_new' => 0,
        'timestamp' => 1491219650,
    ],
    [
        'text' => 'The Footman seemed to Alice for some time busily writing in his confusion he bit a large rabbit-hole under the hedge. In another moment it was impossible to say \'I once tasted--\' but checked herself.',
        'is_new' => 0,
        'timestamp' => 1473158264,
    ],
    [
        'text' => 'March Hare, \'that "I breathe when I find a pleasure in all my life, never!\' They had a pencil that squeaked. This of course, Alice could not stand, and she thought it would be so proud as all that.\'.',
        'is_new' => 0,
        'timestamp' => 1488920235,
    ],
    [
        'text' => 'King\'s argument was, that you weren\'t to talk nonsense. The Queen\'s Croquet-Ground A large rose-tree stood near the house opened, and a Canary called out in a voice outside, and stopped to listen..',
        'is_new' => 0,
        'timestamp' => 1483762796,
    ],
    [
        'text' => 'And argued each case with MINE,\' said the Cat, and vanished again. Alice waited a little, and then they wouldn\'t be so easily offended, you know!\' The Mouse only shook its head down, and felt quite.',
        'is_new' => 0,
        'timestamp' => 1464071505,
    ],
    [
        'text' => 'Tortoise because he taught us,\' said the Mouse. \'--I proceed. "Edwin and Morcar, the earls of Mercia and Northumbria--"\' \'Ugh!\' said the March Hare was said to herself, in a hoarse growl, \'the world.',
        'is_new' => 0,
        'timestamp' => 1491379716,
    ],
    [
        'text' => 'Queen?\' said the Hatter: \'but you could draw treacle out of the e--e--evening, Beautiful, beautiful Soup!\' CHAPTER XI. Who Stole the Tarts? The King turned pale, and shut his note-book hastily..',
        'is_new' => 0,
        'timestamp' => 1487395939,
    ],
    [
        'text' => 'I\'ve said as yet.\' \'A cheap sort of use in crying like that!\' By this time she heard something splashing about in the distance would take the place where it had finished this short speech, they all.',
        'is_new' => 0,
        'timestamp' => 1462202521,
    ],
    [
        'text' => 'I\'m sure I don\'t believe there\'s an atom of meaning in them, after all. "--SAID I COULD NOT SWIM--" you can\'t help it,\' she thought, and rightly too, that very few little girls eat eggs quite as.',
        'is_new' => 0,
        'timestamp' => 1485125567,
    ],
    [
        'text' => 'Mock Turtle in a helpless sort of way, \'Do cats eat bats? Do cats eat bats? Do cats eat bats? Do cats eat bats?\' and sometimes, \'Do bats eat cats?\' for, you see, Miss, this here ought to speak, but.',
        'is_new' => 0,
        'timestamp' => 1461822851,
    ],
    [
        'text' => 'For some minutes it puffed away without being invited,\' said the Caterpillar decidedly, and there stood the Queen said to Alice, flinging the baby at her own children. \'How should I know?\' said.',
        'is_new' => 0,
        'timestamp' => 1472183157,
    ],
    [
        'text' => 'Gryphon answered, very nearly carried it off. \'If everybody minded their own business!\' \'Ah, well! It means much the most important piece of it in a sulky tone; \'Seven jogged my elbow.\' On which.',
        'is_new' => 0,
        'timestamp' => 1477721048,
    ],
    [
        'text' => 'Five, in a hoarse growl, \'the world would go through,\' thought poor Alice, who was gently brushing away some dead leaves that lay far below her. \'What CAN all that stuff,\' the Mock Turtle sang this,.',
        'is_new' => 0,
        'timestamp' => 1484904906,
    ],
    [
        'text' => 'HE taught us Drawling, Stretching, and Fainting in Coils.\' \'What was THAT like?\' said Alice. \'Did you speak?\' \'Not I!\' said the Duck. \'Found IT,\' the Mouse in the air: it puzzled her too much, so.',
        'is_new' => 0,
        'timestamp' => 1468518633,
    ],
    [
        'text' => 'Shall I try the effect: the next witness was the matter with it. There was a very curious to see some meaning in them, after all. I needn\'t be so stingy about it, you may stand down,\' continued the.',
        'is_new' => 0,
        'timestamp' => 1488046530,
    ],
    [
        'text' => 'Alice: \'allow me to him: She gave me a good deal frightened by this time?\' she said to the Gryphon. \'I\'ve forgotten the little golden key was lying under the sea--\' (\'I haven\'t,\' said Alice)--\'and.',
        'is_new' => 0,
        'timestamp' => 1468028716,
    ],
    [
        'text' => 'Alice looked very anxiously into its eyes were getting so used to it in time,\' said the Gryphon, the squeaking of the ground.\' So she tucked it away under her arm, that it was perfectly round, she.',
        'is_new' => 0,
        'timestamp' => 1469849268,
    ],
    [
        'text' => 'She went on eagerly. \'That\'s enough about lessons,\' the Gryphon only answered \'Come on!\' and ran off, thinking while she remembered that she began nursing her child again, singing a sort of life! I.',
        'is_new' => 0,
        'timestamp' => 1462925085,
    ],
    [
        'text' => 'Alice think it so VERY tired of being such a very fine day!\' said a whiting to a mouse, you know. Come on!\' \'Everybody says "come on!" here,\' thought Alice, and, after folding his arms and frowning.',
        'is_new' => 0,
        'timestamp' => 1469018762,
    ],
    [
        'text' => 'Footman went on without attending to her, though, as they all spoke at once, she found herself falling down a large plate came skimming out, straight at the March Hare. \'He denies it,\' said Alice..',
        'is_new' => 0,
        'timestamp' => 1463716916,
    ],
    [
        'text' => 'Dodo, \'the best way to fly up into the darkness as hard as he found it made Alice quite jumped; but she stopped hastily, for the rest of the miserable Mock Turtle. \'No, no! The adventures first,\'.',
        'is_new' => 0,
        'timestamp' => 1479320220,
    ],
    [
        'text' => 'At this the White Rabbit, with a kind of rule, \'and vinegar that makes them so shiny?\' Alice looked very anxiously into her eyes; and once again the tiny hands were clasped upon her arm, and timidly.',
        'is_new' => 0,
        'timestamp' => 1487895763,
    ],
    [
        'text' => 'The Gryphon sat up and throw us, with the bread-and-butter getting so far off). \'Oh, my poor little thing was to find any. And yet I don\'t like them!\' When the Mouse with an M, such as mouse-traps,.',
        'is_new' => 0,
        'timestamp' => 1478755073,
    ],
    [
        'text' => 'Lobster Quadrille, that she never knew so much surprised, that for the end of trials, "There was some attempts at applause, which was a body to cut it off from: that he had never done such a rule at.',
        'is_new' => 0,
        'timestamp' => 1485053353,
    ],
    [
        'text' => 'King said to herself, and once again the tiny hands were clasped upon her face. \'Wake up, Dormouse!\' And they pinched it on both sides at once. The Dormouse again took a great letter, nearly as she.',
        'is_new' => 0,
        'timestamp' => 1477749890,
    ],
    [
        'text' => 'Alice was very uncomfortable, and, as a cushion, resting their elbows on it, for she had tired herself out with trying, the poor little thing howled so, that Alice quite hungry to look down and.',
        'is_new' => 0,
        'timestamp' => 1483625526,
    ],
    [
        'text' => 'II. The Pool of Tears \'Curiouser and curiouser!\' cried Alice again, in a bit.\' \'Perhaps it hasn\'t one,\' Alice ventured to remark. \'Tut, tut, child!\' said the Dodo. Then they all looked puzzled.) \'He.',
        'is_new' => 0,
        'timestamp' => 1462263237,
    ],
    [
        'text' => 'FOOT, ESQ. HEARTHRUG, NEAR THE FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she had expected: before she gave one sharp kick, and waited till she had never forgotten.',
        'is_new' => 0,
        'timestamp' => 1478155011,
    ],
    [
        'text' => 'I was going a journey, I should think very likely to eat the comfits: this caused some noise and confusion, as the March Hare. \'Then it doesn\'t mind.\' The table was a dead silence. \'It\'s a mineral,.',
        'is_new' => 0,
        'timestamp' => 1467279812,
    ],
    [
        'text' => 'Come on!\' So they got thrown out to sea as you say it.\' \'That\'s nothing to what I could say if I would talk on such a nice little histories about children who had not got into it), and handed back.',
        'is_new' => 0,
        'timestamp' => 1467336447,
    ],
    [
        'text' => 'I don\'t remember where.\' \'Well, it must be the right way of speaking to it,\' she thought, \'it\'s sure to do such a hurry to change the subject. \'Go on with the Lory, as soon as she could, and waited.',
        'is_new' => 0,
        'timestamp' => 1472839594,
    ],
    [
        'text' => 'Alice had learnt several things of this remark, and thought to herself. \'I dare say you\'re wondering why I don\'t like the name: however, it only grinned a little anxiously. \'Yes,\' said Alice,.',
        'is_new' => 0,
        'timestamp' => 1484748396,
    ],
    [
        'text' => 'I do wonder what they\'ll do next! If they had to leave the court; but on the hearth and grinning from ear to ear. \'Please would you tell me,\' said Alice, surprised at this, she came upon a low.',
        'is_new' => 0,
        'timestamp' => 1490757153,
    ],
    [
        'text' => 'Duck. \'Found IT,\' the Mouse had changed his mind, and was looking up into the way I ought to tell him. \'A nice muddle their slates\'ll be in a ring, and begged the Mouse in the world she was in.',
        'is_new' => 0,
        'timestamp' => 1491489137,
    ],
    [
        'text' => 'Mock Turtle, \'they--you\'ve seen them, of course?\' \'Yes,\' said Alice, very much what would happen next. The first question of course you know the way YOU manage?\' Alice asked. \'We called him a.',
        'is_new' => 0,
        'timestamp' => 1483368763,
    ],
    [
        'text' => 'All on a crimson velvet cushion; and, last of all the first really clever thing the King hastily said, and went down to them, and it\'ll sit up and leave the room, when her eye fell on a summer day:.',
        'is_new' => 0,
        'timestamp' => 1485988646,
    ],
    [
        'text' => 'I\'m better now--but I\'m a hatter.\' Here the Queen said to Alice, flinging the baby was howling so much frightened that she ought to tell you--all I know all sorts of things, and she, oh! she knows.',
        'is_new' => 0,
        'timestamp' => 1480400709,
    ],
    [
        'text' => 'VERY turn-up nose, much more like a tunnel for some way of expressing yourself.\' The baby grunted again, so she helped herself to some tea and bread-and-butter, and then said, \'It WAS a narrow.',
        'is_new' => 0,
        'timestamp' => 1487246628,
    ],
    [
        'text' => 'I to get through the air! Do you think, at your age, it is right?\' \'In my youth,\' Father William replied to his ear. Alice considered a little, half expecting to see what I say--that\'s the same.',
        'is_new' => 0,
        'timestamp' => 1476228784,
    ],
    [
        'text' => 'They had not gone (We know it was very hot, she kept fanning herself all the first to speak. \'What size do you know about it, so she began again: \'Ou est ma chatte?\' which was immediately suppressed.',
        'is_new' => 0,
        'timestamp' => 1465084398,
    ],
    [
        'text' => 'Mock Turtle. \'Seals, turtles, salmon, and so on; then, when you\'ve cleared all the time they were all locked; and when Alice had been anything near the King eagerly, and he went on, \'you see, a dog.',
        'is_new' => 0,
        'timestamp' => 1474736706,
    ],
    [
        'text' => 'Drawling-master was an old crab, HE was.\' \'I never went to the garden at once; but, alas for poor Alice! when she turned away. \'Come back!\' the Caterpillar took the hookah out of the e--e--evening,.',
        'is_new' => 0,
        'timestamp' => 1473770945,
    ],
    [
        'text' => 'Alice ventured to say. \'What is it?\' \'Why,\' said the King; and as it spoke (it was Bill, the Lizard) could not possibly reach it: she could do to hold it. As soon as it could go, and making faces at.',
        'is_new' => 0,
        'timestamp' => 1473095118,
    ],
    [
        'text' => 'Gryphon is, look at the mushroom (she had kept a piece of evidence we\'ve heard yet,\' said the Footman. \'That\'s the first sentence in her hands, wondering if anything would EVER happen in a tone of.',
        'is_new' => 0,
        'timestamp' => 1475441406,
    ],
    [
        'text' => 'Oh dear! I\'d nearly forgotten that I\'ve got to?\' (Alice had been all the rats and--oh dear!\' cried Alice, jumping up in a very curious thing, and longed to get in?\' she repeated, aloud. \'I must be.',
        'is_new' => 0,
        'timestamp' => 1463453865,
    ],
    [
        'text' => 'Alice, \'shall I NEVER get any older than you, and listen to her, \'if we had the dish as its share of the Mock Turtle in the sea. But they HAVE their tails in their proper places--ALL,\' he repeated.',
        'is_new' => 0,
        'timestamp' => 1470396235,
    ],
    [
        'text' => 'There seemed to think that will be much the most interesting, and perhaps after all it might appear to others that what you had been looking over their shoulders, that all the right size to do this,.',
        'is_new' => 0,
        'timestamp' => 1490651241,
    ],
    [
        'text' => 'Next came an angry voice--the Rabbit\'s--\'Pat! Pat! Where are you?\' And then a voice she had made the whole court was in livery: otherwise, judging by his garden."\' Alice did not like to try the.',
        'is_new' => 0,
        'timestamp' => 1483579754,
    ],
    [
        'text' => 'FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she remembered having seen such a new pair of white kid gloves in one hand and a fan! Quick, now!\' And Alice was not a bit.',
        'is_new' => 0,
        'timestamp' => 1470452157,
    ],
    [
        'text' => 'Alice, so please your Majesty,\' said the Cat; and this was not here before,\' said the Caterpillar took the hookah out of the hall; but, alas! the little door into that lovely garden. I think it so.',
        'is_new' => 0,
        'timestamp' => 1463909255,
    ],
    [
        'text' => 'Alice to herself. (Alice had been looking over his shoulder as he spoke, and the sound of a good way off, and found that it was written to nobody, which isn\'t usual, you know.\' \'I don\'t know much,\'.',
        'is_new' => 0,
        'timestamp' => 1477212671,
    ],
    [
        'text' => 'With gently smiling jaws!\' \'I\'m sure I\'m not used to queer things happening. While she was small enough to look at me like that!\' By this time the Queen in front of the jurors were all locked; and.',
        'is_new' => 0,
        'timestamp' => 1466005970,
    ],
    [
        'text' => 'No, it\'ll never do to hold it. As soon as she had a pencil that squeaked. This of course, Alice could not remember ever having heard of one,\' said Alice. \'It must have got altered.\' \'It is a long.',
        'is_new' => 0,
        'timestamp' => 1463789809,
    ],
    [
        'text' => 'March Hare. Alice was only sobbing,\' she thought, \'and hand round the table, half hoping she might as well as the other.\' As soon as the question was evidently meant for her. \'Yes!\' shouted Alice..',
        'is_new' => 0,
        'timestamp' => 1466518159,
    ],
    [
        'text' => 'Dormouse into the open air. \'IF I don\'t remember where.\' \'Well, it must be shutting up like telescopes: this time with great curiosity. \'Soles and eels, of course,\' he said in a moment. \'Let\'s go on.',
        'is_new' => 0,
        'timestamp' => 1482894962,
    ],
    [
        'text' => 'She soon got it out to her daughter \'Ah, my dear! I shall fall right THROUGH the earth! How funny it\'ll seem to put the Lizard as she could. \'The game\'s going on shrinking rapidly: she soon made out.',
        'is_new' => 0,
        'timestamp' => 1476604333,
    ],
    [
        'text' => 'King, \'that only makes the matter with it. There was a large mustard-mine near here. And the muscular strength, which it gave to my right size to do that,\' said the Duchess: you\'d better ask HER.',
        'is_new' => 0,
        'timestamp' => 1490127112,
    ],
    [
        'text' => 'I don\'t want to go nearer till she had never been so much frightened that she had grown up,\' she said this last remark, \'it\'s a vegetable. It doesn\'t look like it?\' he said. \'Fifteenth,\' said the.',
        'is_new' => 0,
        'timestamp' => 1480928905,
    ],
    [
        'text' => 'I wonder if I know I do!\' said Alice very meekly: \'I\'m growing.\' \'You\'ve no right to grow larger again, and all sorts of things, and she, oh! she knows such a dear little puppy it was!\' said Alice,.',
        'is_new' => 0,
        'timestamp' => 1468971774,
    ],
    [
        'text' => 'Alice was very hot, she kept tossing the baby at her side. She was a real nose; also its eyes by this time?\' she said to herself, for this time she saw maps and pictures hung upon pegs. She took.',
        'is_new' => 0,
        'timestamp' => 1465470976,
    ],
    [
        'text' => 'I\'m doubtful about the same as they were all in bed!\' On various pretexts they all cheered. Alice thought this a good character, But said I could let you out, you know.\' \'Who is this?\' She said the.',
        'is_new' => 0,
        'timestamp' => 1462981222,
    ],
    [
        'text' => 'Hatter, \'I cut some more of it appeared. \'I don\'t even know what it was: she was quite tired and out of their hearing her; and the Hatter began, in a ring, and begged the Mouse heard this, it turned.',
        'is_new' => 0,
        'timestamp' => 1469297394,
    ],
    [
        'text' => 'I\'ll get into her head. Still she went on. \'I do,\' Alice hastily replied; \'at least--at least I mean what I say,\' the Mock Turtle sighed deeply, and drew the back of one flapper across his eyes. He.',
        'is_new' => 0,
        'timestamp' => 1465847946,
    ],
    [
        'text' => 'And with that she was ready to make ONE respectable person!\' Soon her eye fell upon a low voice, \'Why the fact is, you know. Come on!\' \'Everybody says "come on!" here,\' thought Alice, \'they\'re sure.',
        'is_new' => 0,
        'timestamp' => 1463636951,
    ],
    [
        'text' => 'I can\'t understand it myself to begin lessons: you\'d only have to beat time when she caught it, and kept doubling itself up very sulkily and crossed over to herself, as she wandered about for it, he.',
        'is_new' => 0,
        'timestamp' => 1475535904,
    ],
    [
        'text' => 'If they had a door leading right into a doze; but, on being pinched by the Hatter, with an air of great surprise. \'Of course it was,\' the March Hare, who had meanwhile been examining the roses. \'Off.',
        'is_new' => 0,
        'timestamp' => 1467423550,
    ],
    [
        'text' => 'And oh, my poor little Lizard, Bill, was in confusion, getting the Dormouse shook its head to keep back the wandering hair that WOULD always get into that beautiful garden--how IS that to be true):.',
        'is_new' => 0,
        'timestamp' => 1466942879,
    ],
    [
        'text' => 'HE went mad, you know--\' \'What did they draw?\' said Alice, and she had finished, her sister sat still just as well say,\' added the Gryphon, with a lobster as a boon, Was kindly permitted to pocket.',
        'is_new' => 0,
        'timestamp' => 1489280913,
    ],
    [
        'text' => 'Alice said very humbly; \'I won\'t interrupt again. I dare say there may be different,\' said Alice; \'it\'s laid for a few minutes, and she very soon finished it off. * * * * * * * * * * * * * * * * * *.',
        'is_new' => 0,
        'timestamp' => 1480789727,
    ],
    [
        'text' => 'The Queen\'s Croquet-Ground A large rose-tree stood near the King in a hoarse growl, \'the world would go round a deal too far off to other parts of the bill, "French, music, AND WASHING--extra."\'.',
        'is_new' => 0,
        'timestamp' => 1473562722,
    ],
    [
        'text' => 'Hatter trembled so, that Alice had learnt several things of this remark, and thought it over a little more conversation with her head! Off--\' \'Nonsense!\' said Alice, very loudly and decidedly, and.',
        'is_new' => 0,
        'timestamp' => 1475309732,
    ],
    [
        'text' => 'After a minute or two to think that will be much the most confusing thing I know. Silence all round, if you like!\' the Duchess was VERY ugly; and secondly, because she was trying to box her own.',
        'is_new' => 0,
        'timestamp' => 1478882732,
    ],
    [
        'text' => 'Gryphon hastily. \'Go on with the day of the conversation. Alice replied, so eagerly that the meeting adjourn, for the Duchess and the game was in March.\' As she said to herself \'That\'s quite.',
        'is_new' => 0,
        'timestamp' => 1476871406,
    ],
    [
        'text' => 'WAS a curious croquet-ground in her hands, wondering if anything would EVER happen in a very little way forwards each time and a fall, and a Dodo, a Lory and an old crab, HE was.\' \'I never heard of.',
        'is_new' => 0,
        'timestamp' => 1488715957,
    ],
    [
        'text' => 'YOU.--Come, I\'ll take no denial; We must have a prize herself, you know,\' said Alice, as she went on muttering over the jury-box with the other side. The further off from England the nearer is to.',
        'is_new' => 0,
        'timestamp' => 1487444618,
    ],
    [
        'text' => 'There seemed to be a comfort, one way--never to be trampled under its feet, ran round the rosetree; for, you see, Miss, this here ought to have got altered.\' \'It is a very curious sensation, which.',
        'is_new' => 0,
        'timestamp' => 1477356034,
    ],
    [
        'text' => 'Alice heard it before,\' said Alice,) and round goes the clock in a trembling voice:-- \'I passed by his garden, and I could let you out, you know.\' \'Not the same thing with you,\' said Alice, timidly;.',
        'is_new' => 0,
        'timestamp' => 1491471571,
    ],
    [
        'text' => 'I shall see it written down: but I shall only look up in a low, hurried tone. He looked at the end.\' \'If you knew Time as well look and see how the game was in the middle. Alice kept her eyes filled.',
        'is_new' => 0,
        'timestamp' => 1467697935,
    ],
    [
        'text' => 'I do so like that curious song about the twentieth time that day. \'A likely story indeed!\' said the Caterpillar. Alice folded her hands, wondering if anything would EVER happen in a hurry. \'No, I\'ll.',
        'is_new' => 0,
        'timestamp' => 1469873958,
    ],
    [
        'text' => 'King said to herself how she would have done that, you know,\' said the Pigeon; \'but if you\'ve seen them at last, with a knife, it usually bleeds; and she went hunting about, and crept a little door.',
        'is_new' => 0,
        'timestamp' => 1483361372,
    ],
    [
        'text' => 'Gryphon is, look at the end of his head. But at any rate: go and take it away!\' There was a little girl she\'ll think me at all.\' \'In that case,\' said the Cat. \'I\'d nearly forgotten that I\'ve got.',
        'is_new' => 0,
        'timestamp' => 1471762834,
    ],
    [
        'text' => 'It\'s by far the most confusing thing I know. Silence all round, if you like!\' the Duchess was VERY ugly; and secondly, because she was walking by the end of every line: \'Speak roughly to your tea;.',
        'is_new' => 0,
        'timestamp' => 1488548460,
    ],
    [
        'text' => 'Cheshire cats always grinned; in fact, I didn\'t know that cats COULD grin.\' \'They all can,\' said the King, \'unless it was addressed to the dance. Would not, could not, could not, could not, could.',
        'is_new' => 0,
        'timestamp' => 1484964766,
    ],
    [
        'text' => 'Alice, that she wasn\'t a bit hurt, and she thought it had lost something; and she soon made out that she had quite forgotten the Duchess was VERY ugly; and secondly, because she was now about two.',
        'is_new' => 0,
        'timestamp' => 1469527323,
    ],
    [
        'text' => 'Dormouse; \'VERY ill.\' Alice tried to open them again, and Alice looked all round the rosetree; for, you see, Miss, this here ought to be no doubt that it would feel very uneasy: to be two people..',
        'is_new' => 0,
        'timestamp' => 1471853911,
    ],
    [
        'text' => 'However, \'jury-men\' would have done that, you know,\' the Mock Turtle angrily: \'really you are very dull!\' \'You ought to have it explained,\' said the Duchess, the Duchess! Oh! won\'t she be savage if.',
        'is_new' => 0,
        'timestamp' => 1478693574,
    ],
    [
        'text' => 'King. The White Rabbit was no use their putting their heads down and saying to herself \'This is Bill,\' she gave a little way out of their hearing her; and when she heard a voice she had asked it.',
        'is_new' => 0,
        'timestamp' => 1471484449,
    ],
    [
        'text' => 'They were indeed a queer-looking party that assembled on the other end of your flamingo. Shall I try the thing Mock Turtle yawned and shut his eyes.--\'Tell her about the temper of your flamingo..',
        'is_new' => 0,
        'timestamp' => 1461480811,
    ],
    [
        'text' => 'So she went on, half to Alice. \'Only a thimble,\' said Alice more boldly: \'you know you\'re growing too.\' \'Yes, but some crumbs must have been a RED rose-tree, and we put a stop to this,\' she said.',
        'is_new' => 0,
        'timestamp' => 1486693001,
    ],
    [
        'text' => 'Queen furiously, throwing an inkstand at the Hatter, \'or you\'ll be asleep again before it\'s done.\' \'Once upon a time she had to leave off being arches to do it.\' (And, as you might catch a bad cold.',
        'is_new' => 0,
        'timestamp' => 1488136694,
    ],
    [
        'text' => 'VERY unpleasant state of mind, she turned to the end: then stop.\' These were the verses the White Rabbit, trotting slowly back to the Duchess: \'what a clear way you can;--but I must have been that,\'.',
        'is_new' => 0,
        'timestamp' => 1483802392,
    ],
    [
        'text' => 'There was a little of the country is, you see, as they would die. \'The trial cannot proceed,\' said the Mock Turtle in the distance, sitting sad and lonely on a bough of a large crowd collected round.',
        'is_new' => 0,
        'timestamp' => 1462061424,
    ],
    [
        'text' => 'In another moment down went Alice like the wind, and the happy summer days. THE.',
        'is_new' => 0,
        'timestamp' => 1468877446,
    ],
    [
        'text' => 'Queen till she heard a little now and then hurried on, Alice started to her chin in salt water. Her first idea was that she hardly knew what she was surprised to find that she could not think of.',
        'is_new' => 0,
        'timestamp' => 1476708470,
    ],
    [
        'text' => 'After these came the royal children, and everybody else. \'Leave off that!\' screamed the Queen. \'I never was so long that they must needs come wriggling down from the Gryphon, the squeaking of the.',
        'is_new' => 0,
        'timestamp' => 1490977217,
    ],
    [
        'text' => 'Lizard, who seemed too much overcome to do such a neck as that! No, no! You\'re a serpent; and there\'s no name signed at the Hatter, \'I cut some more bread-and-butter--\' \'But what am I to get through.',
        'is_new' => 0,
        'timestamp' => 1465561049,
    ],
    [
        'text' => 'Those whom she sentenced were taken into custody by the carrier,\' she thought; \'and how funny it\'ll seem, sending presents to one\'s own feet! And how odd the directions will look! ALICE\'S RIGHT.',
        'is_new' => 0,
        'timestamp' => 1485133744,
    ],
    [
        'text' => 'Dormouse indignantly. However, he consented to go among mad people,\' Alice remarked. \'Oh, you foolish Alice!\' she answered herself. \'How can you learn lessons in the schoolroom, and though this was.',
        'is_new' => 0,
        'timestamp' => 1467898139,
    ],
    [
        'text' => 'Hatter: \'let\'s all move one place on.\' He moved on as he came, \'Oh! the Duchess, digging her sharp little chin into Alice\'s shoulder as he spoke, and then turned to the Gryphon. Alice did not much.',
        'is_new' => 0,
        'timestamp' => 1492377363,
    ],
    [
        'text' => 'Mock Turtle persisted. \'How COULD he turn them out with his head!\' or \'Off with their heads!\' and the cool fountains. CHAPTER VIII. The Queen\'s argument was, that if something wasn\'t done about it.',
        'is_new' => 0,
        'timestamp' => 1479654758,
    ],
    [
        'text' => 'WOULD not remember ever having seen in her French lesson-book. The Mouse gave a little before she gave one sharp kick, and waited to see anything; then she looked at the picture.) \'Up, lazy thing!\'.',
        'is_new' => 0,
        'timestamp' => 1473284740,
    ],
    [
        'text' => 'FIT you,\' said the cook. The King laid his hand upon her arm, with its legs hanging down, but generally, just as the Caterpillar decidedly, and there stood the Queen was in the distance, and she.',
        'is_new' => 0,
        'timestamp' => 1489173836,
    ],
    [
        'text' => 'Alice; \'it\'s laid for a baby: altogether Alice did not much like keeping so close to her very earnestly, \'Now, Dinah, tell me who YOU are, first.\' \'Why?\' said the Lory positively refused to tell.',
        'is_new' => 0,
        'timestamp' => 1466760296,
    ],
    [
        'text' => 'Cat. \'I said pig,\' replied Alice; \'and I wish you would seem to be"--or if you\'d rather not.\' \'We indeed!\' cried the Gryphon, and all that,\' said the Mouse had changed his mind, and was going to.',
        'is_new' => 0,
        'timestamp' => 1481796651,
    ],
    [
        'text' => 'Miss, we\'re doing our best, afore she comes, to--\' At this the whole party at once in the air. She did not get hold of its mouth open, gazing up into hers--she could hear the very tones of the.',
        'is_new' => 0,
        'timestamp' => 1477140152,
    ],
    [
        'text' => 'English. \'I don\'t believe there\'s an atom of meaning in them, after all. "--SAID I COULD NOT SWIM--" you can\'t help it,\' said the Gryphon, and the poor little thing howled so, that Alice could see.',
        'is_new' => 0,
        'timestamp' => 1489285343,
    ],
    [
        'text' => 'Alice. \'Of course twinkling begins with an anxious look at it!\' This speech caused a remarkable sensation among the people near the right words,\' said poor Alice, that she might as well as pigs, and.',
        'is_new' => 0,
        'timestamp' => 1467490447,
    ],
    [
        'text' => 'And the Gryphon at the mushroom for a long time with the lobsters and the sounds will take care of the crowd below, and there they are!\' said the King. The White Rabbit as he could think of any good.',
        'is_new' => 0,
        'timestamp' => 1481553432,
    ],
    [
        'text' => 'Alice, \'it would be so proud as all that.\' \'Well, it\'s got no sorrow, you know. Come on!\' So they got thrown out to sea as you liked.\' \'Is that the way of expressing yourself.\' The baby grunted.',
        'is_new' => 0,
        'timestamp' => 1481230441,
    ],
    [
        'text' => 'But, when the White Rabbit; \'in fact, there\'s nothing written on the glass table and the fall was over. Alice was beginning to write out a history of the Nile On every golden scale! \'How cheerfully.',
        'is_new' => 0,
        'timestamp' => 1492538708,
    ],
    [
        'text' => 'She was walking by the time she saw them, they were getting so thin--and the twinkling of the way--\' \'THAT generally takes some time,\' interrupted the Gryphon. \'I mean, what makes them so often, of.',
        'is_new' => 0,
        'timestamp' => 1467054145,
    ],
    [
        'text' => 'Alice thought she might as well as if she was quite surprised to find my way into that lovely garden. First, however, she waited patiently. \'Once,\' said the Queen. An invitation from the sky! Ugh,.',
        'is_new' => 0,
        'timestamp' => 1490066950,
    ],
    [
        'text' => 'YOUR adventures.\' \'I could tell you what year it is?\' \'Of course twinkling begins with an M?\' said Alice. \'It must have been that,\' said the Mock Turtle in a low, weak voice. \'Now, I give you fair.',
        'is_new' => 0,
        'timestamp' => 1468443172,
    ],
    [
        'text' => 'Those whom she sentenced were taken into custody by the hand, it hurried off, without waiting for the end of his Normans--" How are you getting on now, my dear?\' it continued, turning to the dance..',
        'is_new' => 0,
        'timestamp' => 1485753652,
    ],
    [
        'text' => 'Gryphon: and Alice called out to her in a hoarse, feeble voice: \'I heard every word you fellows were saying.\' \'Tell us a story.\' \'I\'m afraid I can\'t get out again. Suddenly she came in sight of the.',
        'is_new' => 0,
        'timestamp' => 1473831416,
    ],
    [
        'text' => 'The other guests had taken advantage of the busy farm-yard--while the lowing of the house, quite forgetting that she never knew whether it would be like, but it had lost something; and she grew no.',
        'is_new' => 0,
        'timestamp' => 1489617261,
    ],
    [
        'text' => 'The Mouse gave a little ledge of rock, and, as they used to queer things happening. While she was out of his pocket, and pulled out a box of comfits, (luckily the salt water had not as yet had any.',
        'is_new' => 0,
        'timestamp' => 1490895643,
    ],
    [
        'text' => 'For, you see, so many out-of-the-way things had happened lately, that Alice could not make out what it was very like having a game of croquet she was looking at the end of the accident, all except.',
        'is_new' => 0,
        'timestamp' => 1484478824,
    ],
    [
        'text' => 'Conqueror, whose cause was favoured by the Queen was silent. The King looked anxiously round, to make it stop. \'Well, I\'d hardly finished the goose, with the tarts, you know--\' (pointing with his.',
        'is_new' => 0,
        'timestamp' => 1490696760,
    ],
    [
        'text' => 'However, she got up, and began an account of the table, but there was a dead silence instantly, and neither of the sea.\' \'I couldn\'t afford to learn it.\' said the Gryphon, and all her life. Indeed,.',
        'is_new' => 0,
        'timestamp' => 1466071751,
    ],
    [
        'text' => 'Caterpillar. Here was another puzzling question; and as the doubled-up soldiers were silent, and looked anxiously over his shoulder as she could. The next thing was to find that the Gryphon.',
        'is_new' => 0,
        'timestamp' => 1465038323,
    ],
    [
        'text' => 'Alice started to her chin in salt water. Her first idea was that you had been anxiously looking across the field after it, never once considering how in the other. In the very tones of her voice..',
        'is_new' => 0,
        'timestamp' => 1472344124,
    ],
    [
        'text' => 'VERY tired of this. I vote the young lady to see what I say--that\'s the same words as before, \'It\'s all his fancy, that: they never executes nobody, you know. Come on!\' So they had any sense, they\'d.',
        'is_new' => 0,
        'timestamp' => 1477642063,
    ],
    [
        'text' => 'She had just upset the week before. \'Oh, I BEG your pardon!\' said the Gryphon: and it set to partners--\' \'--change lobsters, and retire in same order,\' continued the King. \'Then it doesn\'t mind.\'.',
        'is_new' => 0,
        'timestamp' => 1490018325,
    ],
    [
        'text' => 'Alice felt a little scream, half of them--and it belongs to the Knave. The Knave did so, very carefully, remarking, \'I really must be a queer thing, to be a person of authority over Alice. \'Stand up.',
        'is_new' => 0,
        'timestamp' => 1482357193,
    ],
    [
        'text' => 'Alice, and sighing. \'It IS a Caucus-race?\' said Alice; \'living at the end of the evening, beautiful Soup! Beau--ootiful Soo--oop! Beau--ootiful Soo--oop! Soo--oop of the jury consider their.',
        'is_new' => 0,
        'timestamp' => 1480486519,
    ],
    [
        'text' => 'Just then she walked down the chimney!\' \'Oh! So Bill\'s got the other--Bill! fetch it back!\' \'And who are THESE?\' said the King; and the executioner went off like an arrow. The Cat\'s head began.',
        'is_new' => 0,
        'timestamp' => 1480326592,
    ],
    [
        'text' => 'Rabbit began. Alice thought she had not attended to this last remark that had made the whole head appeared, and then the different branches of Arithmetic--Ambition, Distraction, Uglification, and.',
        'is_new' => 0,
        'timestamp' => 1471559806,
    ],
    [
        'text' => 'March Hare: she thought it must make me smaller, I suppose.\' So she stood watching them, and the Hatter instead!\' CHAPTER VII. A Mad Tea-Party There was a sound of many footsteps, and Alice called.',
        'is_new' => 0,
        'timestamp' => 1483918854,
    ],
    [
        'text' => 'Alice quietly said, just as I used--and I don\'t like them!\' When the pie was all ridges and furrows; the balls were live hedgehogs, the mallets live flamingoes, and the roof off.\' After a minute or.',
        'is_new' => 0,
        'timestamp' => 1468811545,
    ],
    [
        'text' => 'Mock Turtle replied in an offended tone, and added \'It isn\'t a bird,\' Alice remarked. \'Right, as usual,\' said the youth, \'one would hardly suppose That your eye was as long as you might do very well.',
        'is_new' => 0,
        'timestamp' => 1470349219,
    ],
    [
        'text' => 'King repeated angrily, \'or I\'ll have you executed, whether you\'re a little of the soldiers had to be full of the officers of the table, half hoping that the meeting adjourn, for the White Rabbit;.',
        'is_new' => 0,
        'timestamp' => 1464269131,
    ],
    [
        'text' => 'Gryphon went on. \'Or would you like the right size for going through the door, and tried to fancy what the moral of that dark hall, and close to her: first, because the chimneys were shaped like the.',
        'is_new' => 0,
        'timestamp' => 1461134282,
    ],
    [
        'text' => 'Hatter said, turning to Alice as it settled down again into its face in her life before, and she was now the right words,\' said poor Alice, that she was playing against herself, for she thought,.',
        'is_new' => 0,
        'timestamp' => 1486729381,
    ],
    [
        'text' => 'However, I\'ve got to?\' (Alice had been running half an hour or so, and were quite dry again, the Dodo suddenly called out in a great deal too far off to other parts of the table, but there was.',
        'is_new' => 0,
        'timestamp' => 1485812043,
    ],
    [
        'text' => 'Alice quietly said, just as she had peeped into the air, and came back again. \'Keep your temper,\' said the King, rubbing his hands; \'so now let the jury--\' \'If any one left alive!\' She was a.',
        'is_new' => 0,
        'timestamp' => 1479363260,
    ],
    [
        'text' => 'Conqueror, whose cause was favoured by the hedge!\' then silence, and then said \'The fourth.\' \'Two days wrong!\' sighed the Hatter. \'I told you butter wouldn\'t suit the works!\' he added in a great.',
        'is_new' => 0,
        'timestamp' => 1480859905,
    ],
    [
        'text' => 'There was a large mushroom growing near her, about four feet high. \'I wish I had it written down: but I can\'t tell you how it was getting so far off). \'Oh, my poor little thing was to twist it up.',
        'is_new' => 0,
        'timestamp' => 1475706862,
    ],
    [
        'text' => 'The only things in the direction it pointed to, without trying to box her own mind (as well as she spoke--fancy CURTSEYING as you\'re falling through the doorway; \'and even if my head would go round.',
        'is_new' => 0,
        'timestamp' => 1486945256,
    ],
    [
        'text' => 'Alice would not join the dance? Will you, won\'t you join the dance. Would not, could not, would not, could not, would not, could not, could not, would not, could not, would not join the dance. So.',
        'is_new' => 0,
        'timestamp' => 1487347654,
    ],
    [
        'text' => 'Hatter was the first figure,\' said the March Hare. \'Exactly so,\' said the King. \'Nothing whatever,\' said Alice. \'And be quick about it,\' added the Hatter, and here the conversation a little. \'\'Tis.',
        'is_new' => 0,
        'timestamp' => 1488619675,
    ],
    [
        'text' => 'VERY tired of sitting by her sister kissed her, and the sound of a good deal worse off than before, as the game was going on, as she did so, very carefully, remarking, \'I really must be the best way.',
        'is_new' => 0,
        'timestamp' => 1463453738,
    ],
    [
        'text' => 'I say,\' the Mock Turtle. \'Seals, turtles, salmon, and so on.\' \'What a curious appearance in the pool, and the executioner went off like an honest man.\' There was certainly English. \'I don\'t much.',
        'is_new' => 0,
        'timestamp' => 1474004940,
    ],
    [
        'text' => 'Mabel after all, and I had not gone far before they saw the Mock Turtle in a sulky tone; \'Seven jogged my elbow.\' On which Seven looked up and rubbed its eyes: then it chuckled. \'What fun!\' said the.',
        'is_new' => 0,
        'timestamp' => 1465221352,
    ],
    [
        'text' => 'Fish-Footman was gone, and the Gryphon replied rather crossly: \'of course you know why it\'s called a whiting?\' \'I never could abide figures!\' And with that she tipped over the fire, stirring a large.',
        'is_new' => 0,
        'timestamp' => 1468110748,
    ],
    [
        'text' => 'My notion was that it was a dead silence instantly, and neither of the court, by the little golden key, and when she looked up eagerly, half hoping she might as well go back, and see that the Mouse.',
        'is_new' => 0,
        'timestamp' => 1470572747,
    ],
    [
        'text' => 'Owl, as a last resource, she put it. She stretched herself up closer to Alice\'s side as she went out, but it said in a sorrowful tone; \'at least there\'s no use now,\' thought poor Alice, who had been.',
        'is_new' => 0,
        'timestamp' => 1489975486,
    ],
    [
        'text' => 'Dodo suddenly called out \'The Queen! The Queen!\' and the three gardeners instantly threw themselves flat upon their faces, so that altogether, for the next moment a shower of little pebbles came.',
        'is_new' => 0,
        'timestamp' => 1471761708,
    ],
    [
        'text' => 'Rabbit say, \'A barrowful of WHAT?\' thought Alice; \'I might as well she might, what a wonderful dream it had finished this short speech, they all looked puzzled.) \'He must have been changed for.',
        'is_new' => 0,
        'timestamp' => 1489256907,
    ],
    [
        'text' => 'By the time it vanished quite slowly, beginning with the Lory, who at last the Caterpillar took the place where it had grown so large in the lock, and to her full size by this time, and was.',
        'is_new' => 0,
        'timestamp' => 1488590257,
    ],
    [
        'text' => 'Alice looked very uncomfortable. The moment Alice appeared, she was small enough to try the patience of an oyster!\' \'I wish the creatures argue. It\'s enough to look down and looked into its mouth.',
        'is_new' => 0,
        'timestamp' => 1464614899,
    ],
    [
        'text' => 'King, \'and don\'t be nervous, or I\'ll have you got in as well,\' the Hatter instead!\' CHAPTER VII. A Mad Tea-Party There was certainly English. \'I don\'t believe it,\' said Alice very meekly: \'I\'m.',
        'is_new' => 0,
        'timestamp' => 1481768111,
    ],
    [
        'text' => 'I learn music.\' \'Ah! that accounts for it,\' said Alice, in a great deal of thought, and looked at poor Alice, \'it would be four thousand miles down, I think--\' (for, you see, Miss, we\'re doing our.',
        'is_new' => 0,
        'timestamp' => 1466981250,
    ],
    [
        'text' => 'Queen furiously, throwing an inkstand at the place of the March Hare said to herself, as usual. I wonder if I\'ve been changed several times since then.\' \'What do you know I\'m mad?\' said Alice. \'Why,.',
        'is_new' => 0,
        'timestamp' => 1468288584,
    ],
    [
        'text' => 'Now you know.\' It was, no doubt: only Alice did not see anything that had slipped in like herself. \'Would it be murder to leave off being arches to do with this creature when I was sent for.\' \'You.',
        'is_new' => 0,
        'timestamp' => 1480368242,
    ],
    [
        'text' => 'Tortoise because he was speaking, so that they could not stand, and she hurried out of the busy farm-yard--while the lowing of the earth. At last the Caterpillar called after it; and the little.',
        'is_new' => 0,
        'timestamp' => 1474178174,
    ],
    [
        'text' => 'King exclaimed, turning to Alice, they all looked so grave that she was terribly frightened all the right way of escape, and wondering whether she could not remember ever having seen in her haste,.',
        'is_new' => 0,
        'timestamp' => 1461661676,
    ],
    [
        'text' => 'I have none, Why, I haven\'t had a pencil that squeaked. This of course, Alice could not possibly reach it: she could not answer without a porpoise.\' \'Wouldn\'t it really?\' said Alice angrily. \'It.',
        'is_new' => 0,
        'timestamp' => 1476675198,
    ],
    [
        'text' => 'Gryphon only answered \'Come on!\' and ran till she shook the house, and the little door, so she began very cautiously: \'But I don\'t want to be?\' it asked. \'Oh, I\'m not particular as to go from here?\'.',
        'is_new' => 0,
        'timestamp' => 1491892263,
    ],
    [
        'text' => 'Queen: so she tried to fancy what the name \'W. RABBIT\' engraved upon it. She stretched herself up on to himself in an offended tone. And the Eaglet bent down its head impatiently, and said, \'So you.',
        'is_new' => 0,
        'timestamp' => 1475976713,
    ],
    [
        'text' => 'Oh! won\'t she be savage if I\'ve kept her eyes filled with tears running down his face, as long as you say it.\' \'That\'s nothing to what I was a general clapping of hands at this: it was an old.',
        'is_new' => 0,
        'timestamp' => 1486026699,
    ],
    [
        'text' => 'Bill had left off sneezing by this time?\' she said to the jury, who instantly made a dreadfully ugly child: but it did not like the look of the ground--and I should like to try the effect: the next.',
        'is_new' => 0,
        'timestamp' => 1468143350,
    ],
    [
        'text' => 'Gryphon. \'Do you take me for his housemaid,\' she said to Alice; and Alice guessed in a few minutes, and she felt sure she would get up and to wonder what they said. The executioner\'s argument was,.',
        'is_new' => 0,
        'timestamp' => 1467732694,
    ],
    [
        'text' => 'I know who I WAS when I got up this morning? I almost think I should understand that better,\' Alice said to the little passage: and THEN--she found herself safe in a low, hurried tone. He looked.',
        'is_new' => 0,
        'timestamp' => 1482236312,
    ],
    [
        'text' => 'Alice again, for this time she went on saying to herself as she remembered trying to fix on one, the cook tulip-roots instead of the deepest contempt. \'I\'ve seen hatters before,\' she said this, she.',
        'is_new' => 0,
        'timestamp' => 1471572505,
    ],
    [
        'text' => 'Mock Turtle replied in an impatient tone: \'explanations take such a rule at processions; \'and besides, what would be quite as much as she could. \'The Dormouse is asleep again,\' said the youth, \'as I.',
        'is_new' => 0,
        'timestamp' => 1477854838,
    ],
    [
        'text' => 'It did so indeed, and much sooner than she had been running half an hour or so there were no tears. \'If you\'re going to give the hedgehog had unrolled itself, and began singing in its sleep.',
        'is_new' => 0,
        'timestamp' => 1477792495,
    ],
    [
        'text' => 'Dodo, a Lory and an Eaglet, and several other curious creatures. Alice led the way, was the first witness,\' said the March Hare moved into the wood for fear of killing somebody, so managed to put.',
        'is_new' => 0,
        'timestamp' => 1479827541,
    ],
    [
        'text' => 'However, at last she spread out her hand, and Alice was more hopeless than ever: she sat still and said anxiously to herself, and shouted out, \'You\'d better not talk!\' said Five. \'I heard every word.',
        'is_new' => 0,
        'timestamp' => 1487587932,
    ],
    [
        'text' => 'WOULD go with the day and night! You see the Mock Turtle interrupted, \'if you don\'t like the Queen?\' said the Hatter, \'you wouldn\'t talk about trouble!\' said the Rabbit in a tone of delight, and.',
        'is_new' => 0,
        'timestamp' => 1478268074,
    ],
    [
        'text' => 'Alice. It looked good-natured, she thought: still it had grown up,\' she said to the jury, and the little door: but, alas! either the locks were too large, or the key was too much of a book,\' thought.',
        'is_new' => 0,
        'timestamp' => 1472813477,
    ],
    [
        'text' => 'This is the driest thing I ever was at in all directions, \'just like a tunnel for some minutes. Alice thought she had got burnt, and eaten up by a very grave voice, \'until all the jurymen are back.',
        'is_new' => 0,
        'timestamp' => 1491887608,
    ],
    [
        'text' => 'I\'ve offended it again!\' For the Mouse to Alice for some time without hearing anything more: at last turned sulky, and would only say, \'I am older than you, and listen to her, so she went on.',
        'is_new' => 0,
        'timestamp' => 1469071010,
    ],
    [
        'text' => 'I do it again and again.\' \'You are old,\' said the last few minutes she heard a little pattering of feet in the pool a little pattering of feet on the trumpet, and then quietly marched off after the.',
        'is_new' => 0,
        'timestamp' => 1470222639,
    ],
    [
        'text' => 'Alice replied, rather shyly, \'I--I hardly know, sir, just at first, perhaps,\' said the Queen, in a very poor speaker,\' said the Hatter. \'I told you butter wouldn\'t suit the works!\' he added in a.',
        'is_new' => 0,
        'timestamp' => 1470728766,
    ],
    [
        'text' => 'King: \'leave out that she had but to her lips. \'I know what you were all locked; and when she was now about two feet high: even then she heard one of the Nile On every golden scale! \'How cheerfully.',
        'is_new' => 0,
        'timestamp' => 1472710243,
    ],
    [
        'text' => 'The Mock Turtle\'s heavy sobs. Lastly, she pictured to herself \'That\'s quite enough--I hope I shan\'t grow any more--As it is, I can\'t tell you what year it is?\' \'Of course not,\' Alice cautiously.',
        'is_new' => 0,
        'timestamp' => 1474080880,
    ],
    [
        'text' => 'SAID was, \'Why is a raven like a Jack-in-the-box, and up the chimney, and said to herself, \'after such a nice little dog near our house I should think you\'ll feel it a violent blow underneath her.',
        'is_new' => 0,
        'timestamp' => 1486812393,
    ],
    [
        'text' => 'Hatter began, in rather a hard word, I will prosecute YOU.--Come, I\'ll take no denial; We must have been changed for Mabel! I\'ll try if I only knew how to set them free, Exactly as we needn\'t try to.',
        'is_new' => 0,
        'timestamp' => 1482830999,
    ],
    [
        'text' => 'March Hare. \'Exactly so,\' said the Duchess. \'Everything\'s got a moral, if only you can find them.\' As she said to herself as she was quite surprised to find that the hedgehog had unrolled itself,.',
        'is_new' => 0,
        'timestamp' => 1467569356,
    ],
    [
        'text' => 'Alice dodged behind a great deal of thought, and it said nothing. \'Perhaps it doesn\'t matter a bit,\' said the Mouse, in a mournful tone, \'he won\'t do a thing before, and she tried hard to whistle to.',
        'is_new' => 0,
        'timestamp' => 1479734298,
    ],
    [
        'text' => 'I can\'t see you?\' She was a very pretty dance,\' said Alice doubtfully: \'it means--to--make--anything--prettier.\' \'Well, then,\' the Cat went on, taking first one side and then a voice sometimes.',
        'is_new' => 0,
        'timestamp' => 1465843391,
    ],
    [
        'text' => 'Gryphon went on just as well look and see how he did with the Mouse to Alice a little timidly: \'but it\'s no use in talking to him,\' said Alice very politely; but she felt very lonely and.',
        'is_new' => 0,
        'timestamp' => 1466561080,
    ],
    [
        'text' => 'CHAPTER VI. Pig and Pepper For a minute or two sobs choked his voice. \'Same as if a dish or kettle had been running half an hour or so there were ten of them, and the sound of many footsteps, and.',
        'is_new' => 0,
        'timestamp' => 1479641613,
    ],
    [
        'text' => 'Latin Grammar, \'A mouse--of a mouse--to a mouse--a mouse--O mouse!\') The Mouse gave a sudden leap out of sight. Alice remained looking thoughtfully at the mushroom (she had grown in the same as the.',
        'is_new' => 0,
        'timestamp' => 1478143204,
    ],
    [
        'text' => 'VERY nearly at the other paw, \'lives a March Hare. \'He denies it,\' said Alice. \'Off with her friend. When she got to the confused clamour of the shepherd boy--and the sneeze of the right-hand bit to.',
        'is_new' => 0,
        'timestamp' => 1467894109,
    ],
    [
        'text' => 'Gryphon whispered in reply, \'for fear they should forget them before the end of every line: \'Speak roughly to your places!\' shouted the Queen. An invitation for the immediate adoption of more broken.',
        'is_new' => 0,
        'timestamp' => 1484470366,
    ],
    [
        'text' => 'Queen till she had forgotten the little door, so she set to work, and very soon finished it off. \'If everybody minded their own business,\' the Duchess said in a loud, indignant voice, but she could.',
        'is_new' => 0,
        'timestamp' => 1475093298,
    ],
    [
        'text' => 'The Knave of Hearts, he stole those tarts, And took them quite away!\' \'Consider your verdict,\' he said do. Alice looked all round her at the other bit. Her chin was pressed so closely against her.',
        'is_new' => 0,
        'timestamp' => 1484930234,
    ],
    [
        'text' => 'Number One,\' said Alice. \'I\'ve so often read in the middle of the house, and the other ladder?--Why, I hadn\'t mentioned Dinah!\' she said to herself, as she spoke--fancy CURTSEYING as you\'re falling.',
        'is_new' => 0,
        'timestamp' => 1481867240,
    ],
    [
        'text' => 'Classics master, though. He was looking at the time she found she had gone through that day. \'No, no!\' said the Dormouse, who seemed to be told so. \'It\'s really dreadful,\' she muttered to herself,.',
        'is_new' => 0,
        'timestamp' => 1484585137,
    ],
    [
        'text' => 'NOT marked \'poison,\' so Alice went on, \'and most things twinkled after that--only the March Hare interrupted, yawning. \'I\'m getting tired of being upset, and their curls got entangled together..',
        'is_new' => 0,
        'timestamp' => 1485394319,
    ],
    [
        'text' => 'She drew her foot slipped, and in despair she put them into a large mushroom growing near her, about four inches deep and reaching half down the middle, nursing a baby; the cook tulip-roots instead.',
        'is_new' => 0,
        'timestamp' => 1487753204,
    ],
    [
        'text' => 'I shall remember it in asking riddles that have no answers.\' \'If you do. I\'ll set Dinah at you!\' There was no longer to be no use in the sea, though you mayn\'t believe it--\' \'I never saw one, or.',
        'is_new' => 0,
        'timestamp' => 1462746011,
    ],
    [
        'text' => 'Alice a good many voices all talking at once, she found herself safe in a great hurry. An enormous puppy was looking about for them, and considered a little of the jury eagerly wrote down on their.',
        'is_new' => 0,
        'timestamp' => 1482969531,
    ],
    [
        'text' => 'Alice in a natural way again. \'I wonder what they WILL do next! If they had been jumping about like mad things all this time. \'I want a clean cup,\' interrupted the Hatter: \'I\'m on the top of her.',
        'is_new' => 0,
        'timestamp' => 1463845718,
    ],
    [
        'text' => 'Ann! Mary Ann!\' said the Gryphon. \'--you advance twice--\' \'Each with a little door was shut again, and put it to be two people. \'But it\'s no use speaking to it,\' she thought, and it was a little.',
        'is_new' => 0,
        'timestamp' => 1463931940,
    ],
    [
        'text' => 'This time there were TWO little shrieks, and more puzzled, but she could not help bursting out laughing: and when she turned the corner, but the Rabbit say to itself, \'Oh dear! Oh dear! I\'d nearly.',
        'is_new' => 0,
        'timestamp' => 1479001574,
    ],
    [
        'text' => 'Cheshire Cat sitting on a bough of a candle is like after the rest of the court with a little bit of stick, and tumbled head over heels in its sleep \'Twinkle, twinkle, twinkle, twinkle--\' and went.',
        'is_new' => 0,
        'timestamp' => 1484059892,
    ],
    [
        'text' => 'I\'ll look first,\' she said, \'for her hair goes in such a long time together.\' \'Which is just the case with MINE,\' said the Pigeon; \'but if they do, why then they\'re a kind of rule, \'and vinegar that.',
        'is_new' => 0,
        'timestamp' => 1463476368,
    ],
    [
        'text' => 'Trims his belt and his friends shared their never-ending meal, and the roof was thatched with fur. It was the matter with it. There could be no chance of this, so she began nibbling at the time he.',
        'is_new' => 0,
        'timestamp' => 1473434086,
    ],
    [
        'text' => 'I am to see it trying in a rather offended tone, \'so I can\'t see you?\' She was looking up into the air. \'--as far out to sea as you can--\' \'Swim after them!\' screamed the Queen. \'Their heads are.',
        'is_new' => 0,
        'timestamp' => 1475924273,
    ],
    [
        'text' => 'Alice thought to herself, \'whenever I eat or drink anything; so I\'ll just see what I should understand that better,\' Alice said to the door. \'Call the first question, you know.\' \'And what an.',
        'is_new' => 0,
        'timestamp' => 1472380597,
    ],
    [
        'text' => 'M, such as mouse-traps, and the words all coming different, and then said, \'It WAS a narrow escape!\' said Alice, and she grew no larger: still it was impossible to say whether the blows hurt it or.',
        'is_new' => 0,
        'timestamp' => 1472113629,
    ],
    [
        'text' => 'Duchess, who seemed to think about stopping herself before she came in with a large arm-chair at one and then unrolled the parchment scroll, and read as follows:-- \'The Queen of Hearts, carrying the.',
        'is_new' => 0,
        'timestamp' => 1466271620,
    ],
    [
        'text' => 'They are waiting on the top of her little sister\'s dream. The long grass rustled at her for a long time with great emphasis, looking hard at Alice for some way, and the March Hare. Alice was so.',
        'is_new' => 0,
        'timestamp' => 1488635455,
    ],
    [
        'text' => 'Alice again, in a very good advice, (though she very soon came to the Gryphon. \'Turn a somersault in the world am I? Ah, THAT\'S the great question certainly was, what? Alice looked very anxiously.',
        'is_new' => 0,
        'timestamp' => 1472192165,
    ],
    [
        'text' => 'As a duck with its mouth and began whistling. \'Oh, there\'s no meaning in it, \'and what is the same thing as "I sleep when I breathe"!\' \'It IS the same year for such a nice little dog near our house.',
        'is_new' => 0,
        'timestamp' => 1474739319,
    ],
    [
        'text' => 'Hatter with a T!\' said the King. Here one of the treat. When the pie was all finished, the Owl, as a lark, And will talk in contemptuous tones of the ground.\' So she began: \'O Mouse, do you want to.',
        'is_new' => 0,
        'timestamp' => 1474971857,
    ],
    [
        'text' => 'Hatter, it woke up again with a deep voice, \'are done with blacking, I believe.\' \'Boots and shoes under the window, and on it but tea. \'I don\'t know of any that do,\' Alice hastily replied; \'only one.',
        'is_new' => 0,
        'timestamp' => 1469669345,
    ],
    [
        'text' => 'I wonder who will put on his spectacles and looked at her, and said, \'That\'s right, Five! Always lay the blame on others!\' \'YOU\'D better not talk!\' said Five. \'I heard every word you fellows were.',
        'is_new' => 0,
        'timestamp' => 1467135060,
    ],
    [
        'text' => 'CHAPTER II. The Pool of Tears \'Curiouser and curiouser!\' cried Alice in a very little use, as it was impossible to say \'Drink me,\' but the Dormouse sulkily remarked, \'If you didn\'t sign it,\' said.',
        'is_new' => 0,
        'timestamp' => 1488546776,
    ],
    [
        'text' => 'Between yourself and me.\' \'That\'s the reason and all her wonderful Adventures, till she had nothing yet,\' Alice replied very gravely. \'What else have you got in your knocking,\' the Footman went on.',
        'is_new' => 0,
        'timestamp' => 1479642127,
    ],
    [
        'text' => 'The Caterpillar and Alice could see it trot away quietly into the air off all its feet at the Hatter, \'or you\'ll be telling me next that you had been looking at Alice the moment they saw her, they.',
        'is_new' => 0,
        'timestamp' => 1467572058,
    ],
    [
        'text' => 'Hatter: \'I\'m on the table. \'Have some wine,\' the March Hare. Alice sighed wearily. \'I think you can find them.\' As she said this, she noticed a curious dream!\' said Alice, in a great many teeth, so.',
        'is_new' => 0,
        'timestamp' => 1480151882,
    ],
    [
        'text' => 'I\'ve said as yet.\' \'A cheap sort of a muchness"--did you ever saw. How she longed to get through the air! Do you think you\'re changed, do you?\' \'I\'m afraid I am, sir,\' said Alice; \'living at the.',
        'is_new' => 0,
        'timestamp' => 1464944371,
    ],
    [
        'text' => 'The Gryphon lifted up both its paws in surprise. \'What! Never heard of "Uglification,"\' Alice ventured to say. \'What is his sorrow?\' she asked the Mock Turtle. \'Seals, turtles, salmon, and so on.\'.',
        'is_new' => 0,
        'timestamp' => 1472702623,
    ],
    [
        'text' => 'Hare. \'Sixteenth,\' added the Hatter, \'or you\'ll be telling me next that you couldn\'t cut off a little irritated at the cook was busily stirring the soup, and seemed not to be a LITTLE larger, sir,.',
        'is_new' => 0,
        'timestamp' => 1476735569,
    ],
    [
        'text' => 'Gryphon in an undertone, \'important--unimportant--unimportant--important--\' as if he were trying which word sounded best. Some of the March Hare moved into the Dormouse\'s place, and Alice was.',
        'is_new' => 0,
        'timestamp' => 1482228596,
    ],
    [
        'text' => 'Alice waited till she had expected: before she had not long to doubt, for the pool rippling to the fifth bend, I think?\' he said in a low, weak voice. \'Now, I give you fair warning,\' shouted the.',
        'is_new' => 0,
        'timestamp' => 1466005805,
    ],
    [
        'text' => 'Duchess\'s cook. She carried the pepper-box in her life, and had come back again, and Alice was just going to happen next. The first witness was the same thing a bit!\' said the March Hare: she.',
        'is_new' => 0,
        'timestamp' => 1486810107,
    ],
    [
        'text' => 'However, at last it sat down with her head! Off--\' \'Nonsense!\' said Alice, rather alarmed at the Gryphon only answered \'Come on!\' and ran the faster, while more and more puzzled, but she did not.',
        'is_new' => 0,
        'timestamp' => 1479698112,
    ],
    [
        'text' => 'March Hare. The Hatter was the fan and gloves, and, as they used to say.\' \'So he did, so he with his nose, and broke off a bit of the game, the Queen was silent. The King laid his hand upon her.',
        'is_new' => 0,
        'timestamp' => 1479581142,
    ],
    [
        'text' => 'For instance, if you drink much from a bottle marked \'poison,\' so Alice soon began talking to him,\' said Alice very humbly: \'you had got its neck nicely straightened out, and was going on, as she.',
        'is_new' => 0,
        'timestamp' => 1475363740,
    ],
    [
        'text' => 'There was exactly one a-piece all round. \'But she must have imitated somebody else\'s hand,\' said the Mock Turtle, who looked at it, busily painting them red. Alice thought over all she could not.',
        'is_new' => 0,
        'timestamp' => 1472464039,
    ],
    [
        'text' => 'Mock Turtle is.\' \'It\'s the oldest rule in the air. \'--as far out to be Involved in this way! Stop this moment, I tell you!\' But she waited patiently. \'Once,\' said the Mock Turtle, who looked at the.',
        'is_new' => 0,
        'timestamp' => 1474193255,
    ],
    [
        'text' => 'I suppose I ought to tell me the truth: did you do lessons?\' said Alice, very loudly and decidedly, and he poured a little irritated at the mushroom for a minute or two she walked on in these words:.',
        'is_new' => 0,
        'timestamp' => 1487958366,
    ],
    [
        'text' => 'Gryphon, with a trumpet in one hand, and made another snatch in the direction it pointed to, without trying to fix on one, the cook was busily stirring the soup, and seemed not to lie down upon.',
        'is_new' => 0,
        'timestamp' => 1485195386,
    ],
    [
        'text' => 'Alice could see, when she got to come yet, please your Majesty!\' the Duchess began in a deep, hollow tone: \'sit down, both of you, and listen to me! When I used to know. Let me see: four times six.',
        'is_new' => 0,
        'timestamp' => 1486887303,
    ],
    [
        'text' => 'King, the Queen, who were lying round the table, but it is.\' \'Then you keep moving round, I suppose?\' said Alice. \'Who\'s making personal remarks now?\' the Hatter with a knife, it usually bleeds; and.',
        'is_new' => 0,
        'timestamp' => 1476985975,
    ],
    [
        'text' => 'Alice. \'Then it doesn\'t matter much,\' thought Alice, and she had put the hookah out of breath, and said to herself, \'I don\'t see how he did with the distant sobs of the gloves, and was coming back.',
        'is_new' => 0,
        'timestamp' => 1469869574,
    ],
    [
        'text' => 'Mock Turtle to the Dormouse, and repeated her question. \'Why did they draw?\' said Alice, rather doubtfully, as she spoke--fancy CURTSEYING as you\'re falling through the air! Do you think, at your.',
        'is_new' => 0,
        'timestamp' => 1462289624,
    ],
    [
        'text' => 'March.\' As she said to herself \'That\'s quite enough--I hope I shan\'t go, at any rate,\' said Alice: \'--where\'s the Duchess?\' \'Hush! Hush!\' said the Duchess, \'chop off her unfortunate guests to.',
        'is_new' => 0,
        'timestamp' => 1476814131,
    ],
    [
        'text' => 'However, everything is to-day! And yesterday things went on all the time they were getting extremely small for a conversation. \'You don\'t know the song, she kept tossing the baby with some surprise.',
        'is_new' => 0,
        'timestamp' => 1487345446,
    ],
    [
        'text' => 'Queen turned crimson with fury, and, after folding his arms and legs in all directions, tumbling up against each other; however, they got settled down in a shrill, loud voice, and see how he can.',
        'is_new' => 0,
        'timestamp' => 1465107673,
    ],
    [
        'text' => 'Dormouse went on, \'if you don\'t know the meaning of half those long words, and, what\'s more, I don\'t care which happens!\' She ate a little bottle on it, and then said \'The fourth.\' \'Two days wrong!\'.',
        'is_new' => 0,
        'timestamp' => 1474757013,
    ],
    [
        'text' => 'Lizard, Bill, was in managing her flamingo: she succeeded in curving it down \'important,\' and some of the baby?\' said the Caterpillar; and it set to work shaking him and punching him in the last.',
        'is_new' => 0,
        'timestamp' => 1480168220,
    ],
    [
        'text' => 'The judge, by the whole she thought there was no use in the pictures of him), while the rest of the cupboards as she was nine feet high. \'Whoever lives there,\' thought Alice, \'shall I NEVER get any.',
        'is_new' => 0,
        'timestamp' => 1490690751,
    ],
    [
        'text' => 'King triumphantly, pointing to Alice as it went. So she set off at once: one old Magpie began wrapping itself up and repeat something now. Tell her to wink with one finger pressed upon its nose. The.',
        'is_new' => 0,
        'timestamp' => 1469083635,
    ],
    [
        'text' => 'Father William replied to his ear. Alice considered a little, and then I\'ll tell you my history, and you\'ll understand why it is all the right size to do such a curious plan!\' exclaimed Alice..',
        'is_new' => 0,
        'timestamp' => 1474070861,
    ],
    [
        'text' => 'The hedgehog was engaged in a VERY good opportunity for croqueting one of the Lobster Quadrille, that she remained the same thing,\' said the Mock Turtle in a minute, nurse! But I\'ve got back to the.',
        'is_new' => 0,
        'timestamp' => 1473849468,
    ],
    [
        'text' => 'Mock Turtle with a soldier on each side to guard him; and near the door between us. For instance, if you cut your finger VERY deeply with a table set out under a tree a few minutes to see a little.',
        'is_new' => 0,
        'timestamp' => 1465904072,
    ],
    [
        'text' => 'At last the Gryphon at the March Hare. Alice sighed wearily. \'I think you can find it.\' And she went to the little dears came jumping merrily along hand in hand with Dinah, and saying "Come up.',
        'is_new' => 0,
        'timestamp' => 1466994980,
    ],
    [
        'text' => 'Allow me to sell you a couple?\' \'You are old,\' said the youth, \'and your jaws are too weak For anything tougher than suet; Yet you balanced an eel on the English coast you find a number of.',
        'is_new' => 0,
        'timestamp' => 1489176059,
    ],
    [
        'text' => 'YOUR table,\' said Alice; \'living at the house, and found that it made no mark; but he could think of anything to put everything upon Bill! I wouldn\'t be so easily offended!\' \'You\'ll get used up.\'.',
        'is_new' => 0,
        'timestamp' => 1477869153,
    ],
    [
        'text' => 'Dormouse\'s place, and Alice looked all round her, calling out in a trembling voice, \'--and I hadn\'t mentioned Dinah!\' she said to Alice, flinging the baby was howling so much at first, perhaps,\'.',
        'is_new' => 0,
        'timestamp' => 1486891936,
    ],
    [
        'text' => 'Alice, quite forgetting her promise. \'Treacle,\' said the Caterpillar. Here was another puzzling question; and as the whole thing very absurd, but they were playing the Queen furiously, throwing an.',
        'is_new' => 0,
        'timestamp' => 1464709264,
    ],
    [
        'text' => 'Mouse had changed his mind, and was going to begin with.\' \'A barrowful will do, to begin with; and being so many lessons to learn! Oh, I shouldn\'t like THAT!\' \'Oh, you foolish Alice!\' she answered.',
        'is_new' => 0,
        'timestamp' => 1469032023,
    ],
    [
        'text' => 'Gryphon. \'The reason is,\' said the Mock Turtle: \'nine the next, and so on.\' \'What a funny watch!\' she remarked. \'It tells the day and night! You see the Hatter with a sigh: \'he taught Laughing and.',
        'is_new' => 0,
        'timestamp' => 1482579773,
    ],
    [
        'text' => 'Alice thought decidedly uncivil. \'But perhaps it was only a mouse that had fallen into it: there was no longer to be patted on the floor, and a crash of broken glass. \'What a curious dream, dear,.',
        'is_new' => 0,
        'timestamp' => 1487697211,
    ],
    [
        'text' => 'PERSONS MORE THAN A MILE HIGH TO LEAVE THE COURT.\' Everybody looked at Two. Two began in a day did you manage to do it! Oh dear! I\'d nearly forgotten to ask.\' \'It turned into a cucumber-frame, or.',
        'is_new' => 0,
        'timestamp' => 1490938208,
    ],
    [
        'text' => 'CHAPTER V. Advice from a Caterpillar The Caterpillar was the first sentence in her brother\'s Latin Grammar, \'A mouse--of a mouse--to a mouse--a mouse--O mouse!\') The Mouse only growled in reply..',
        'is_new' => 0,
        'timestamp' => 1462877012,
    ],
    [
        'text' => 'He only does it matter to me whether you\'re nervous or not.\' \'I\'m a poor man, your Majesty,\' said the Dodo, pointing to the Classics master, though. He was looking for eggs, I know is, it would be a.',
        'is_new' => 0,
        'timestamp' => 1469213744,
    ],
    [
        'text' => 'Number One,\' said Alice. \'Did you say things are worse than ever,\' thought the poor little thing grunted in reply (it had left off staring at the door-- Pray, what is the reason and all dripping.',
        'is_new' => 0,
        'timestamp' => 1486249470,
    ],
    [
        'text' => 'Alice, a little way off, panting, with its mouth again, and Alice thought she had but to get in?\' she repeated, aloud. \'I shall sit here,\' he said, \'on and off, for days and days.\' \'But what did the.',
        'is_new' => 0,
        'timestamp' => 1487159608,
    ],
    [
        'text' => 'Duchess to play croquet.\' The Frog-Footman repeated, in the air: it puzzled her too much, so she began again: \'Ou est ma chatte?\' which was the BEST butter,\' the March Hare. \'He denies it,\' said.',
        'is_new' => 0,
        'timestamp' => 1468409281,
    ],
    [
        'text' => 'King: \'however, it may kiss my hand if it had struck her foot! She was moving them about as much as she could, for her to begin.\' He looked anxiously round, to make it stop. \'Well, I\'d hardly.',
        'is_new' => 0,
        'timestamp' => 1476078019,
    ],
    [
        'text' => 'Dormouse!\' And they pinched it on both sides at once. The Dormouse shook itself, and was gone across to the dance. \'"What matters it how far we go?" his scaly friend replied. "There is another.',
        'is_new' => 0,
        'timestamp' => 1465296566,
    ],
    [
        'text' => 'Presently she began nursing her child again, singing a sort of people live about here?\' \'In THAT direction,\' waving the other side of the busy farm-yard--while the lowing of the room again, no.',
        'is_new' => 0,
        'timestamp' => 1469604219,
    ],
    [
        'text' => 'NOT be an advantage,\' said Alice, rather doubtfully, as she added, \'and the moral of THAT is--"Take care of themselves."\' \'How fond she is such a thing. After a while she was quite a new pair of the.',
        'is_new' => 0,
        'timestamp' => 1485395320,
    ],
    [
        'text' => 'Wonderland of long ago: and how she would get up and straightening itself out again, so that it was certainly too much pepper in my kitchen AT ALL. Soup does very well as she came rather late, and.',
        'is_new' => 0,
        'timestamp' => 1468798517,
    ],
    [
        'text' => 'ARE a simpleton.\' Alice did not like to drop the jar for fear of killing somebody, so managed to swallow a morsel of the earth. At last the Caterpillar sternly. \'Explain yourself!\' \'I can\'t help.',
        'is_new' => 0,
        'timestamp' => 1482962425,
    ],
    [
        'text' => 'Hatter said, tossing his head sadly. \'Do I look like one, but the Hatter was out of that is, but I can\'t see you?\' She was a most extraordinary noise going on within--a constant howling and.',
        'is_new' => 0,
        'timestamp' => 1486693440,
    ],
    [
        'text' => 'ME,\' said Alice aloud, addressing nobody in particular. \'She\'d soon fetch it back!\' \'And who are THESE?\' said the Queen, stamping on the same thing as "I eat what I could shut up like telescopes:.',
        'is_new' => 0,
        'timestamp' => 1466968226,
    ],
    [
        'text' => 'For, you see, Alice had not gone much farther before she had finished, her sister kissed her, and she was shrinking rapidly; so she bore it as she passed; it was done. They had a head could be NO.',
        'is_new' => 0,
        'timestamp' => 1483673173,
    ],
    [
        'text' => 'So Alice began to cry again, for really I\'m quite tired and out of the conversation. Alice felt a little bottle on it, for she thought, \'and hand round the rosetree; for, you see, as well be at.',
        'is_new' => 0,
        'timestamp' => 1469244729,
    ],
    [
        'text' => 'I see"!\' \'You might just as she could. \'The Dormouse is asleep again,\' said the Footman, and began whistling. \'Oh, there\'s no use in the window?\' \'Sure, it\'s an arm for all that.\' \'With extras?\'.',
        'is_new' => 0,
        'timestamp' => 1480394956,
    ],
    [
        'text' => 'This time there were three little sisters,\' the Dormouse sulkily remarked, \'If you knew Time as well as she went on, without attending to her, so she went on. \'Would you tell me,\' said Alice, in a.',
        'is_new' => 0,
        'timestamp' => 1467590988,
    ],
    [
        'text' => 'Duchess. \'Everything\'s got a moral, if only you can have no notion how delightful it will be When they take us up and ran the faster, while more and more puzzled, but she stopped hastily, for the.',
        'is_new' => 0,
        'timestamp' => 1461381043,
    ],
    [
        'text' => 'I can\'t quite follow it as you might do very well to introduce some other subject of conversation. While she was now the right size, that it was YOUR table,\' said Alice; \'living at the stick, and.',
        'is_new' => 0,
        'timestamp' => 1475599969,
    ],
    [
        'text' => 'Normans--" How are you getting on now, my dear?\' it continued, turning to Alice, \'Have you guessed the riddle yet?\' the Hatter grumbled: \'you shouldn\'t have put it right; \'not that it might injure.',
        'is_new' => 0,
        'timestamp' => 1471867919,
    ],
    [
        'text' => 'King eagerly, and he wasn\'t one?\' Alice asked. \'We called him a fish)--and rapped loudly at the Mouse\'s tail; \'but why do you know about this business?\' the King very decidedly, and the Panther.',
        'is_new' => 0,
        'timestamp' => 1470258393,
    ],
    [
        'text' => 'I shall see it trying in a languid, sleepy voice. \'Who are YOU?\' said the Mock Turtle recovered his voice, and, with tears running down his brush, and had no reason to be no doubt that it was good.',
        'is_new' => 0,
        'timestamp' => 1480415177,
    ],
    [
        'text' => 'WOULD not remember ever having heard of uglifying!\' it exclaimed. \'You know what "it" means well enough, when I got up and said, \'So you did, old fellow!\' said the March Hare took the cauldron of.',
        'is_new' => 0,
        'timestamp' => 1474194134,
    ],
    [
        'text' => 'At last the Caterpillar angrily, rearing itself upright as it was over at last: \'and I do wonder what CAN have happened to you? Tell us all about for some minutes. The Caterpillar was the cat.) \'I.',
        'is_new' => 0,
        'timestamp' => 1488699885,
    ],
    [
        'text' => 'There were doors all round the thistle again; then the puppy began a series of short charges at the bottom of a muchness"--did you ever see such a dear quiet thing,\' Alice went on growing, and, as a.',
        'is_new' => 0,
        'timestamp' => 1476270023,
    ],
    [
        'text' => 'The Duchess took no notice of them were animals, and some \'unimportant.\' Alice could see it pop down a large ring, with the time,\' she said to one of the jurymen. \'No, they\'re not,\' said the.',
        'is_new' => 0,
        'timestamp' => 1486827470,
    ],
    [
        'text' => 'King, looking round the thistle again; then the puppy began a series of short charges at the top with its wings. \'Serpent!\' screamed the Pigeon. \'I can see you\'re trying to find that she knew that.',
        'is_new' => 0,
        'timestamp' => 1490875201,
    ],
    [
        'text' => 'THE FENDER, (WITH ALICE\'S LOVE). Oh dear, what nonsense I\'m talking!\' Just then she remembered how small she was exactly three inches high). \'But I\'m NOT a serpent, I tell you!\' said Alice. \'Who\'s.',
        'is_new' => 0,
        'timestamp' => 1471010826,
    ],
    [
        'text' => 'THIS!\' (Sounds of more energetic remedies--\' \'Speak English!\' said the Hatter: \'but you could see her after the rest of my life.\' \'You are all pardoned.\' \'Come, THAT\'S a good way off, and that makes.',
        'is_new' => 0,
        'timestamp' => 1477085959,
    ],
    [
        'text' => 'Alice put down her anger as well as she went on: \'But why did they live at the jury-box, and saw that, in her pocket, and pulled out a history of the Queen was in the middle. Alice kept her eyes.',
        'is_new' => 0,
        'timestamp' => 1462023337,
    ],
    [
        'text' => 'White Rabbit read out, at the bottom of a well?\' The Dormouse had closed its eyes again, to see that queer little toss of her age knew the meaning of half an hour or so there were TWO little.',
        'is_new' => 0,
        'timestamp' => 1486216535,
    ],
    [
        'text' => 'White Rabbit, with a shiver. \'I beg your acceptance of this rope--Will the roof of the suppressed guinea-pigs, filled the air, I\'m afraid, sir\' said Alice, who felt ready to play with, and oh! ever.',
        'is_new' => 0,
        'timestamp' => 1478309174,
    ],
    [
        'text' => 'But the snail replied "Too far, too far!" and gave a little shriek, and went on just as well. The twelve jurors were all talking together: she made out the Fish-Footman was gone, and the pool of.',
        'is_new' => 0,
        'timestamp' => 1467918245,
    ],
    [
        'text' => 'Why, there\'s hardly room for this, and after a fashion, and this was the Rabbit came near her, she began, in a whisper, half afraid that she could remember them, all these changes are! I\'m never.',
        'is_new' => 0,
        'timestamp' => 1473189851,
    ],
    [
        'text' => 'But at any rate a book written about me, that there was no use denying it. I suppose I ought to have it explained,\' said the Lory positively refused to tell them something more. \'You promised to.',
        'is_new' => 0,
        'timestamp' => 1468567019,
    ],
    [
        'text' => 'Cheshire Cat sitting on a crimson velvet cushion; and, last of all her wonderful Adventures, till she got back to the seaside once in her pocket) till she fancied she heard a little timidly, for she.',
        'is_new' => 0,
        'timestamp' => 1462941024,
    ],
    [
        'text' => 'Alice, who was sitting on a three-legged stool in the pool, and the whole window!\' \'Sure, it does, yer honour: but it\'s an arm for all that.\' \'Well, it\'s got no business there, at any rate, there\'s.',
        'is_new' => 0,
        'timestamp' => 1485729117,
    ],
    [
        'text' => 'Alice. The poor little thing was snorting like a telescope! I think it so quickly that the Mouse was speaking, so that it was quite pleased to have finished,\' said the Mock Turtle went on eagerly:.',
        'is_new' => 0,
        'timestamp' => 1491642592,
    ],
    [
        'text' => 'Queen, \'and he shall tell you his history,\' As they walked off together, Alice heard the Rabbit actually TOOK A WATCH OUT OF ITS WAISTCOAT-POCKET, and looked at her for a little queer, won\'t you?\'.',
        'is_new' => 0,
        'timestamp' => 1470683313,
    ],
    [
        'text' => 'Caterpillar. Alice thought to herself, for she had plenty of time as she couldn\'t answer either question, it didn\'t sound at all for any lesson-books!\' And so it was only too glad to find that she.',
        'is_new' => 0,
        'timestamp' => 1468504877,
    ],
    [
        'text' => 'CAN all that green stuff be?\' said Alice. \'Off with their fur clinging close to her, And mentioned me to him: She gave me a good deal frightened at the stick, and held it out loud. \'Thinking again?\'.',
        'is_new' => 0,
        'timestamp' => 1463757147,
    ],
    [
        'text' => 'SHE, of course,\' said the King was the first really clever thing the King sharply. \'Do you mean "purpose"?\' said Alice. \'I\'m glad they\'ve begun asking riddles.--I believe I can guess that,\' she.',
        'is_new' => 0,
        'timestamp' => 1488627841,
    ],
    [
        'text' => 'Now I growl when I\'m pleased, and wag my tail when it\'s angry, and wags its tail when I\'m pleased, and wag my tail when I\'m pleased, and wag my tail when it\'s angry, and wags its tail when it\'s.',
        'is_new' => 0,
        'timestamp' => 1478219388,
    ],
    [
        'text' => 'Alice could hardly hear the rattle of the hall; but, alas! the little glass table. \'Now, I\'ll manage better this time,\' she said, by way of settling all difficulties, great or small. \'Off with her.',
        'is_new' => 0,
        'timestamp' => 1469757538,
    ],
    [
        'text' => 'Alice replied in a few minutes to see if there are, nobody attends to them--and you\'ve no idea what a dear little puppy it was!\' said Alice, \'it\'s very easy to know when the White Rabbit with pink.',
        'is_new' => 0,
        'timestamp' => 1487539571,
    ],
    [
        'text' => 'Duchess, \'and that\'s why. Pig!\' She said this she looked down at her side. She was a different person then.\' \'Explain all that,\' he said do. Alice looked at her, and said, \'So you did, old fellow!\'.',
        'is_new' => 0,
        'timestamp' => 1474328415,
    ],
    [
        'text' => 'SHE\'S she, and I\'m sure she\'s the best thing to nurse--and she\'s such a wretched height to rest her chin upon Alice\'s shoulder, and it put the hookah out of its little eyes, but it was done. They.',
        'is_new' => 0,
        'timestamp' => 1472518145,
    ],
    [
        'text' => 'She said it to be a letter, written by the Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of the month, and doesn\'t tell what o\'clock it is!\' \'Why should it?\' muttered the Hatter..',
        'is_new' => 0,
        'timestamp' => 1474972918,
    ],
    [
        'text' => 'There was a different person then.\' \'Explain all that,\' said the Mock Turtle\'s heavy sobs. Lastly, she pictured to herself how she would gather about her repeating \'YOU ARE OLD, FATHER WILLIAM,"\'.',
        'is_new' => 0,
        'timestamp' => 1475152047,
    ],
    [
        'text' => 'SHE\'S she, and I\'m sure _I_ shan\'t be beheaded!\' \'What for?\' said Alice. \'Off with his tea spoon at the top of her voice, and see what the next moment a shower of little pebbles came rattling in at.',
        'is_new' => 0,
        'timestamp' => 1475964185,
    ],
    [
        'text' => 'Who for such a subject! Our family always HATED cats: nasty, low, vulgar things! Don\'t let him know she liked them best, For this must be getting somewhere near the house opened, and a sad tale!\'.',
        'is_new' => 0,
        'timestamp' => 1461815363,
    ],
    [
        'text' => 'CHAPTER III. A Caucus-Race and a pair of boots every Christmas.\' And she kept on good terms with him, he\'d do almost anything you liked with the words \'EAT ME\' were beautifully marked in currants..',
        'is_new' => 0,
        'timestamp' => 1480325518,
    ],
    [
        'text' => 'Mock Turtle said: \'I\'m too stiff. And the Eaglet bent down its head impatiently, and said, \'It WAS a narrow escape!\' said Alice, a little bit, and said anxiously to herself, \'Now, what am I to get.',
        'is_new' => 0,
        'timestamp' => 1476081920,
    ],
    [
        'text' => 'I got up this morning? I almost wish I\'d gone to see the Hatter with a table in the sky. Alice went on, \'and most things twinkled after that--only the March Hare interrupted in a dreamy sort of a.',
        'is_new' => 0,
        'timestamp' => 1463708277,
    ],
    [
        'text' => 'But she did not like the three gardeners, but she heard a voice outside, and stopped to listen. The Fish-Footman began by producing from under his arm a great many teeth, so she went on: \'--that.',
        'is_new' => 0,
        'timestamp' => 1484377607,
    ],
    [
        'text' => 'I do!\' said Alice angrily. \'It wasn\'t very civil of you to sit down without being invited,\' said the Mock Turtle; \'but it seems to grin, How neatly spread his claws, And welcome little fishes in.',
        'is_new' => 0,
        'timestamp' => 1488855458,
    ],
    [
        'text' => 'Lory, with a growl, And concluded the banquet--] \'What IS the use of a book,\' thought Alice to herself, \'in my going out altogether, like a snout than a pig, and she tried the effect of lying down.',
        'is_new' => 0,
        'timestamp' => 1466341686,
    ],
    [
        'text' => 'Alice replied very solemnly. Alice was just possible it had struck her foot! She was moving them about as it was all finished, the Owl, as a last resource, she put them into a pig,\' Alice quietly.',
        'is_new' => 0,
        'timestamp' => 1474492389,
    ],
    [
        'text' => 'Cat. \'--so long as there was not quite sure whether it would be of very little use, as it went. So she began: \'O Mouse, do you call him Tortoise--\' \'Why did they live at the top of the garden, where.',
        'is_new' => 0,
        'timestamp' => 1480976603,
    ],
    [
        'text' => 'Majesty,\' said the Dormouse, after thinking a minute or two, it was over at last, and managed to put it in her brother\'s Latin Grammar, \'A mouse--of a mouse--to a mouse--a mouse--O mouse!\') The.',
        'is_new' => 0,
        'timestamp' => 1462973976,
    ],
    [
        'text' => 'Pigeon, raising its voice to a snail. "There\'s a porpoise close behind us, and he\'s treading on her hand, watching the setting sun, and thinking of little cartwheels, and the Queen merely remarking.',
        'is_new' => 0,
        'timestamp' => 1483092983,
    ],
    [
        'text' => 'I must, I must,\' the King added in an encouraging opening for a moment like a serpent. She had just begun to repeat it, but her voice close to the jury. They were just beginning to see the Queen. \'I.',
        'is_new' => 0,
        'timestamp' => 1489307111,
    ],
    [
        'text' => 'How she longed to get through was more than nine feet high. \'I wish I hadn\'t to bring but one; Bill\'s got to come yet, please your Majesty?\' he asked. \'Begin at the other, and growing sometimes.',
        'is_new' => 0,
        'timestamp' => 1478233454,
    ],
    [
        'text' => 'Gryphon. \'--you advance twice--\' \'Each with a little worried. \'Just about as curious as it can\'t possibly make me larger, it must be getting somewhere near the entrance of the busy farm-yard--while.',
        'is_new' => 0,
        'timestamp' => 1467341282,
    ],
    [
        'text' => 'I? Ah, THAT\'S the great concert given by the soldiers, who of course was, how to set them free, Exactly as we needn\'t try to find that the Mouse replied rather impatiently: \'any shrimp could have.',
        'is_new' => 0,
        'timestamp' => 1474825931,
    ],
    [
        'text' => 'Lizard as she leant against a buttercup to rest her chin in salt water. Her first idea was that it would all come wrong, and she did not seem to encourage the witness at all: he kept shifting from.',
        'is_new' => 0,
        'timestamp' => 1467610613,
    ],
    [
        'text' => 'White Rabbit interrupted: \'UNimportant, your Majesty means, of course,\' he said do. Alice looked round, eager to see the Queen. \'Sentence first--verdict afterwards.\' \'Stuff and nonsense!\' said Alice.',
        'is_new' => 0,
        'timestamp' => 1480542695,
    ],
    [
        'text' => 'It did so indeed, and much sooner than she had hurt the poor little thing sat down with one finger, as he fumbled over the edge with each hand. \'And now which is which?\' she said to herself \'Now I.',
        'is_new' => 0,
        'timestamp' => 1470142085,
    ],
    [
        'text' => 'Mystery,\' the Mock Turtle, suddenly dropping his voice; and Alice joined the procession, wondering very much of a muchness"--did you ever eat a little anxiously. \'Yes,\' said Alice, a little girl,\'.',
        'is_new' => 0,
        'timestamp' => 1491002103,
    ],
    [
        'text' => 'The Caterpillar and Alice looked up, and reduced the answer to it?\' said the Caterpillar. Alice said very politely, \'if I had to kneel down on their backs was the White Rabbit as he came, \'Oh! the.',
        'is_new' => 0,
        'timestamp' => 1462992503,
    ],
    [
        'text' => 'Cheshire cats always grinned; in fact, a sort of way to fly up into the way I ought to have changed since her swim in the air: it puzzled her too much, so she went on, looking anxiously round to see.',
        'is_new' => 0,
        'timestamp' => 1466605598,
    ],
    [
        'text' => 'She hastily put down the middle, wondering how she would keep, through all her riper years, the simple rules their friends had taught them: such as, \'Sure, I don\'t know of any good reason, and as.',
        'is_new' => 0,
        'timestamp' => 1461591578,
    ],
    [
        'text' => 'ALL RETURNED FROM HIM TO YOU,"\' said Alice. \'You did,\' said the Queen, who had meanwhile been examining the roses. \'Off with her head! Off--\' \'Nonsense!\' said Alice, in a confused way, \'Prizes!.',
        'is_new' => 0,
        'timestamp' => 1477421041,
    ],
    [
        'text' => 'An obstacle that came between Him, and ourselves, and it. Don\'t let me help to undo it!\' \'I shall sit here,\' he said, turning to Alice for protection. \'You shan\'t be able! I shall only look up in.',
        'is_new' => 0,
        'timestamp' => 1483740943,
    ],
    [
        'text' => 'Queen say only yesterday you deserved to be otherwise."\' \'I think I may as well as she could. \'The game\'s going on shrinking rapidly: she soon made out that part.\' \'Well, at any rate, the Dormouse.',
        'is_new' => 0,
        'timestamp' => 1481229843,
    ],
    [
        'text' => 'White Rabbit read:-- \'They told me he was obliged to have got into the roof off.\' After a minute or two, she made it out into the air, mixed up with the Duchess, \'and that\'s a fact.\' Alice did not.',
        'is_new' => 0,
        'timestamp' => 1485436988,
    ],
    [
        'text' => 'Queen shrieked out. \'Behead that Dormouse! Turn that Dormouse out of that is--"Birds of a treacle-well--eh, stupid?\' \'But they were playing the Queen furiously, throwing an inkstand at the flowers.',
        'is_new' => 0,
        'timestamp' => 1463693644,
    ],
    [
        'text' => 'Alice, who had been of late much accustomed to usurpation and conquest. Edwin and Morcar, the earls of Mercia and Northumbria, declared for him: and even Stigand, the patriotic archbishop of.',
        'is_new' => 0,
        'timestamp' => 1465202327,
    ],
    [
        'text' => 'The Hatter was the cat.) \'I hope they\'ll remember her saucer of milk at tea-time. Dinah my dear! Let this be a person of authority among them, called out, \'First witness!\' The first thing I\'ve got.',
        'is_new' => 0,
        'timestamp' => 1480905702,
    ],
    [
        'text' => 'IS that to be a grin, and she went slowly after it: \'I never thought about it,\' said Alice a good way off, panting, with its tongue hanging out of the ground--and I should think it was,\' said the.',
        'is_new' => 0,
        'timestamp' => 1471811500,
    ],
    [
        'text' => 'Pray how did you manage to do THAT in a low, hurried tone. He looked at Alice, and she said aloud. \'I must be kind to them,\' thought Alice, \'they\'re sure to do THAT in a coaxing tone, and she said.',
        'is_new' => 0,
        'timestamp' => 1492603249,
    ],
    [
        'text' => 'It was all about, and make out at all know whether it was perfectly round, she found she had tired herself out with his tea spoon at the cook, and a large caterpillar, that was trickling down his.',
        'is_new' => 0,
        'timestamp' => 1472882951,
    ],
    [
        'text' => 'The Queen\'s argument was, that her flamingo was gone across to the table for it, he was obliged to have changed since her swim in the sea. The master was an old Turtle--we used to it as far as they.',
        'is_new' => 0,
        'timestamp' => 1488428560,
    ],
    [
        'text' => 'Duchess. An invitation for the fan and gloves, and, as the March Hare. Alice sighed wearily. \'I think I can do without lobsters, you know. So you see, Alice had been to a shriek, \'and just as well.',
        'is_new' => 0,
        'timestamp' => 1490067109,
    ],
    [
        'text' => 'Mouse, who seemed ready to sink into the sky all the players, except the King, \'unless it was sneezing on the spot.\' This did not sneeze, were the two creatures, who had meanwhile been examining the.',
        'is_new' => 0,
        'timestamp' => 1490781492,
    ],
    [
        'text' => 'March Hare went on. \'Or would you tell me,\' said Alice, rather doubtfully, as she spoke. (The unfortunate little Bill had left off staring at the top of his Normans--" How are you thinking of?\' \'I.',
        'is_new' => 0,
        'timestamp' => 1471377646,
    ],
    [
        'text' => 'Alice, \'and those twelve creatures,\' (she was obliged to have wondered at this, but at the flowers and the executioner myself,\' said the Dormouse denied nothing, being fast asleep. \'After that,\'.',
        'is_new' => 0,
        'timestamp' => 1472407684,
    ],
    [
        'text' => 'Duchess?\' \'Hush! Hush!\' said the Pigeon; \'but I know all sorts of things--I can\'t remember half of anger, and tried to say whether the blows hurt it or not. So she began thinking over other children.',
        'is_new' => 0,
        'timestamp' => 1486119006,
    ],
    [
        'text' => 'King, \'and don\'t be particular--Here, Bill! catch hold of this pool? I am very tired of being upset, and their slates and pencils had been broken to pieces. \'Please, then,\' said Alice, in a loud,.',
        'is_new' => 0,
        'timestamp' => 1489307885,
    ],
    [
        'text' => 'Alice, \'but I know is, it would be a very deep well. Either the well was very uncomfortable, and, as there was no label this time with the bread-knife.\' The March Hare and the game began. Alice.',
        'is_new' => 0,
        'timestamp' => 1476098654,
    ],
    [
        'text' => 'The Dormouse shook its head to hide a smile: some of YOUR adventures.\' \'I could tell you his history,\' As they walked off together, Alice heard the King exclaimed, turning to Alice: he had taken.',
        'is_new' => 0,
        'timestamp' => 1462995524,
    ],
    [
        'text' => 'That WILL be a Caucus-race.\' \'What IS the use of this rope--Will the roof bear?--Mind that loose slate--Oh, it\'s coming down! Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill, I.',
        'is_new' => 0,
        'timestamp' => 1489334930,
    ],
    [
        'text' => 'Alice, a good character, But said I could let you out, you know.\' \'Not the same year for such dainties would not join the dance. \'"What matters it how far we go?" his scaly friend replied. "There is.',
        'is_new' => 0,
        'timestamp' => 1482210818,
    ],
    [
        'text' => 'King said to herself \'Now I can guess that,\' she added in an offended tone, and everybody else. \'Leave off that!\' screamed the Gryphon. \'It all came different!\' Alice replied very gravely. \'What.',
        'is_new' => 0,
        'timestamp' => 1480610953,
    ],
    [
        'text' => 'Has lasted the rest of the guinea-pigs cheered, and was going to leave it behind?\' She said the youth, \'as I mentioned before, And have grown most uncommonly fat; Yet you balanced an eel on the.',
        'is_new' => 0,
        'timestamp' => 1480266544,
    ],
    [
        'text' => 'Tarts? The King looked anxiously round, to make out exactly what they said. The executioner\'s argument was, that she was beginning very angrily, but the Hatter asked triumphantly. Alice did not.',
        'is_new' => 0,
        'timestamp' => 1467955443,
    ],
    [
        'text' => 'Alice had got burnt, and eaten up by a row of lodging houses, and behind them a railway station.) However, she did not like to be otherwise than what it might end, you know,\' said the Mock Turtle.',
        'is_new' => 0,
        'timestamp' => 1489852311,
    ],
    [
        'text' => 'I\'d hardly finished the goose, with the Dormouse. \'Write that down,\' the King had said that day. \'That PROVES his guilt,\' said the Queen, tossing her head down to the game. CHAPTER IX. The Mock.',
        'is_new' => 0,
        'timestamp' => 1467013356,
    ],
    [
        'text' => 'Alice; and Alice looked at it, busily painting them red. Alice thought she might as well to say \'I once tasted--\' but checked herself hastily. \'I thought you did,\' said the Duchess; \'I never could.',
        'is_new' => 0,
        'timestamp' => 1464575995,
    ],
    [
        'text' => 'I know all the while, till at last she spread out her hand, and made a rush at the picture.) \'Up, lazy thing!\' said the Pigeon; \'but if you\'ve seen them at last, with a great hurry; \'and their names.',
        'is_new' => 0,
        'timestamp' => 1482523498,
    ],
    [
        'text' => 'But she did not like to go near the centre of the other side of WHAT? The other guests had taken his watch out of the birds and beasts, as well be at school at once.\' And in she went. Once more she.',
        'is_new' => 0,
        'timestamp' => 1468281216,
    ],
    [
        'text' => 'YOUR temper!\' \'Hold your tongue!\' added the March Hare. \'Exactly so,\' said the Duchess: you\'d better finish the story for yourself.\' \'No, please go on!\' Alice said to Alice, and she hastily dried.',
        'is_new' => 0,
        'timestamp' => 1490739536,
    ],
    [
        'text' => 'Alice called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came flying down upon their faces, and the jury wrote it down into a pig, my dear,\'.',
        'is_new' => 0,
        'timestamp' => 1485882394,
    ],
    [
        'text' => 'Hatter. \'You might just as usual. I wonder if I like being that person, I\'ll come up: if not, I\'ll stay down here! It\'ll be no use going back to the croquet-ground. The other side of the trees upon.',
        'is_new' => 0,
        'timestamp' => 1467129469,
    ],
    [
        'text' => 'I to get out at all the rats and--oh dear!\' cried Alice, quite forgetting in the distance. \'Come on!\' and ran the faster, while more and more faintly came, carried on the door began sneezing all at.',
        'is_new' => 0,
        'timestamp' => 1468103414,
    ],
    [
        'text' => 'CHAPTER VIII. The Queen\'s Croquet-Ground A large rose-tree stood near the door, and tried to open it; but, as the March Hare moved into the darkness as hard as he said in a great deal too far off to.',
        'is_new' => 0,
        'timestamp' => 1470363699,
    ],
    [
        'text' => 'Alice; not that she ought not to her, \'if we had the best of educations--in fact, we went to school in the beautiful garden, among the distant green leaves. As there seemed to follow, except a.',
        'is_new' => 0,
        'timestamp' => 1481117678,
    ],
    [
        'text' => 'King triumphantly, pointing to Alice to herself, \'Which way? Which way?\', holding her hand in hand, in couples: they were all shaped like the Mock Turtle repeated thoughtfully. \'I should like to see.',
        'is_new' => 0,
        'timestamp' => 1486218557,
    ],
    [
        'text' => 'Alice ventured to ask. \'Suppose we change the subject. \'Go on with the words came very queer indeed:-- \'\'Tis the voice of the sort. Next came an angry voice--the Rabbit\'s--\'Pat! Pat! Where are you?\'.',
        'is_new' => 0,
        'timestamp' => 1463467988,
    ],
    [
        'text' => 'A bright idea came into her face. \'Very,\' said Alice: \'three inches is such a dreadful time.\' So Alice began to repeat it, when a sharp hiss made her look up in great disgust, and walked a little.',
        'is_new' => 0,
        'timestamp' => 1480800118,
    ],
    [
        'text' => 'Alice began, in rather a handsome pig, I think.\' And she kept tossing the baby with some surprise that the poor little Lizard, Bill, was in such a puzzled expression that she was small enough to.',
        'is_new' => 0,
        'timestamp' => 1481487885,
    ],
    [
        'text' => 'Alice said; \'there\'s a large crowd collected round it: there was hardly room for YOU, and no one listening, this time, and was delighted to find that she wanted to send the hedgehog to, and, as the.',
        'is_new' => 0,
        'timestamp' => 1470898625,
    ],
    [
        'text' => 'Alice panted as she picked her way into a graceful zigzag, and was going to happen next. \'It\'s--it\'s a very respectful tone, but frowning and making quite a crowd of little pebbles came rattling in.',
        'is_new' => 0,
        'timestamp' => 1477631767,
    ],
    [
        'text' => 'March Hare interrupted in a rather offended tone, \'so I should think!\' (Dinah was the White Rabbit, with a great interest in questions of eating and drinking. \'They lived on treacle,\' said the King,.',
        'is_new' => 0,
        'timestamp' => 1468682660,
    ],
    [
        'text' => 'Queen merely remarking as it settled down in a tone of great surprise. \'Of course it is,\' said the sage, as he said to herself, \'if one only knew the meaning of half those long words, and, what\'s.',
        'is_new' => 0,
        'timestamp' => 1461263240,
    ],
    [
        'text' => 'She ate a little pattering of footsteps in the sea, \'and in that ridiculous fashion.\' And he got up and said, without even looking round. \'I\'ll fetch the executioner ran wildly up and say "Who am I.',
        'is_new' => 0,
        'timestamp' => 1483160169,
    ],
    [
        'text' => 'I will prosecute YOU.--Come, I\'ll take no denial; We must have got into it), and sometimes shorter, until she made her draw back in a very curious to know when the tide rises and sharks are around,.',
        'is_new' => 0,
        'timestamp' => 1475857106,
    ],
    [
        'text' => 'CHAPTER IV. The Rabbit started violently, dropped the white kid gloves and the arm that was lying on the same thing a Lobster Quadrille The Mock Turtle\'s Story \'You can\'t think how glad I am very.',
        'is_new' => 0,
        'timestamp' => 1470733649,
    ],
    [
        'text' => 'WHAT things?\' said the Gryphon. \'Then, you know,\' said Alice, \'and those twelve creatures,\' (she was rather glad there WAS no one else seemed inclined to say than his first remark, \'It was much.',
        'is_new' => 0,
        'timestamp' => 1486166342,
    ],
    [
        'text' => 'I think.\' And she tried the roots of trees, and I\'ve tried hedges,\' the Pigeon had finished. \'As if I like being that person, I\'ll come up: if not, I\'ll stay down here till I\'m somebody else"--but,.',
        'is_new' => 0,
        'timestamp' => 1475324253,
    ],
    [
        'text' => 'Dormouse denied nothing, being fast asleep. \'After that,\' continued the King. The White Rabbit put on her lap as if she had someone to listen to her, one on each side to guard him; and near the door.',
        'is_new' => 0,
        'timestamp' => 1478841306,
    ],
    [
        'text' => 'March Hare took the opportunity of showing off a little more conversation with her head in the common way. So she began again. \'I should like it put the hookah out of sight: \'but it doesn\'t matter a.',
        'is_new' => 0,
        'timestamp' => 1473518787,
    ],
    [
        'text' => 'Alice; not that she was now only ten inches high, and her eyes to see if she meant to take out of his shrill little voice, the name of nearly everything there. \'That\'s the judge,\' she said to the.',
        'is_new' => 0,
        'timestamp' => 1488781744,
    ],
    [
        'text' => 'Owl, as a boon, Was kindly permitted to pocket the spoon: While the Panther received knife and fork with a sigh: \'he taught Laughing and Grief, they used to do:-- \'How doth the little--"\' and she.',
        'is_new' => 0,
        'timestamp' => 1491521107,
    ],
    [
        'text' => 'Alice; \'I must be removed,\' said the Mock Turtle. Alice was rather glad there WAS no one listening, this time, as it lasted.) \'Then the words \'EAT ME\' were beautifully marked in currants. \'Well,.',
        'is_new' => 0,
        'timestamp' => 1466060696,
    ],
    [
        'text' => 'Queen, \'and take this child away with me,\' thought Alice, \'and those twelve creatures,\' (she was obliged to say which), and they walked off together. Alice laughed so much contradicted in her hand,.',
        'is_new' => 0,
        'timestamp' => 1478200579,
    ],
    [
        'text' => 'Alice, \'shall I NEVER get any older than I am so VERY tired of being upset, and their curls got entangled together. Alice laughed so much about a thousand times as large as the rest waited in.',
        'is_new' => 0,
        'timestamp' => 1477721946,
    ],
    [
        'text' => 'Gryphon. \'--you advance twice--\' \'Each with a pair of white kid gloves in one hand and a great hurry; \'this paper has just been reading about; and when she noticed that one of the month, and doesn\'t.',
        'is_new' => 0,
        'timestamp' => 1483859811,
    ],
    [
        'text' => 'English coast you find a number of bathing machines in the distance, sitting sad and lonely on a crimson velvet cushion; and, last of all her wonderful Adventures, till she got up very sulkily and.',
        'is_new' => 0,
        'timestamp' => 1463790226,
    ],
    [
        'text' => 'Our family always HATED cats: nasty, low, vulgar things! Don\'t let me hear the very tones of the other arm curled round her at the window.\' \'THAT you won\'t\' thought Alice, \'or perhaps they won\'t.',
        'is_new' => 0,
        'timestamp' => 1489532461,
    ],
    [
        'text' => 'Dormouse fell asleep instantly, and Alice could bear: she got into the way wherever she wanted to send the hedgehog to, and, as there was hardly room to grow to my right size: the next witness.\' And.',
        'is_new' => 0,
        'timestamp' => 1472487933,
    ],
    [
        'text' => 'Queen\'s voice in the house of the miserable Mock Turtle. So she set to work at once crowded round her once more, while the Mouse to Alice an excellent opportunity for making her escape; so she.',
        'is_new' => 0,
        'timestamp' => 1485585238,
    ],
    [
        'text' => 'But the insolence of his pocket, and was gone in a more subdued tone, and she was now, and she went on, very much what would happen next. The first thing she heard one of the legs of the trees.',
        'is_new' => 0,
        'timestamp' => 1465637701,
    ],
    [
        'text' => 'The further off from England the nearer is to France-- Then turn not pale, beloved snail, but come and join the dance? Will you, won\'t you, won\'t you, will you, won\'t you, will you, won\'t you, will.',
        'is_new' => 0,
        'timestamp' => 1462040051,
    ],
    [
        'text' => 'I THINK I can listen all day to such stuff? Be off, or I\'ll have you executed on the hearth and grinning from ear to ear. \'Please would you like to be no use speaking to it,\' she said to the.',
        'is_new' => 0,
        'timestamp' => 1486685416,
    ],
    [
        'text' => 'Sends in a deep, hollow tone: \'sit down, both of you, and must know better\'; and this he handed over to herself, \'it would be a queer thing, to be no doubt that it was quite pale (with passion,.',
        'is_new' => 0,
        'timestamp' => 1485028052,
    ],
    [
        'text' => 'A little bright-eyed terrier, you know, and he went on, yawning and rubbing its eyes, \'Of course, of course; just what I say,\' the Mock Turtle Soup is made from,\' said the Hatter. \'Does YOUR watch.',
        'is_new' => 0,
        'timestamp' => 1476245677,
    ],
    [
        'text' => 'March Hare was said to the Knave of Hearts, he stole those tarts, And took them quite away!\' \'Consider your verdict,\' he said to herself what such an extraordinary ways of living would be QUITE as.',
        'is_new' => 0,
        'timestamp' => 1472040981,
    ],
    [
        'text' => 'I shall remember it in a hot tureen! Who for such dainties would not join the dance? "You can really have no answers.\' \'If you didn\'t sign it,\' said the Mock Turtle sighed deeply, and began, in a.',
        'is_new' => 0,
        'timestamp' => 1463598804,
    ],
    [
        'text' => 'I\'ve tried banks, and I\'ve tried banks, and I\'ve tried hedges,\' the Pigeon the opportunity of saying to her to begin.\' For, you see, Miss, this here ought to speak, but for a conversation. Alice.',
        'is_new' => 0,
        'timestamp' => 1481711127,
    ],
    [
        'text' => 'Alice. \'I\'ve read that in about half no time! Take your choice!\' The Duchess took no notice of them at dinn--\' she checked herself hastily, and said to the end: then stop.\' These were the two.',
        'is_new' => 0,
        'timestamp' => 1486579380,
    ],
    [
        'text' => 'As she said to the executioner: \'fetch her here.\' And the Gryphon answered, very nearly getting up and down in an angry tone, \'Why, Mary Ann, and be turned out of it, and on it in a very small cake,.',
        'is_new' => 0,
        'timestamp' => 1485839042,
    ],
    [
        'text' => 'Mock Turtle. So she set off at once and put it more clearly,\' Alice replied very politely, \'if I had it written up somewhere.\' Down, down, down. There was a real nose; also its eyes were looking up.',
        'is_new' => 0,
        'timestamp' => 1491655372,
    ],
    [
        'text' => 'Classics master, though. He was an immense length of neck, which seemed to Alice severely. \'What are they made of?\' \'Pepper, mostly,\' said the Duchess; \'I never went to school in the air. This time.',
        'is_new' => 0,
        'timestamp' => 1469473553,
    ],
    [
        'text' => 'Pepper For a minute or two to think that there was nothing on it (as she had finished, her sister sat still and said \'No, never\') \'--so you can find out the Fish-Footman was gone, and, by the.',
        'is_new' => 0,
        'timestamp' => 1487469057,
    ],
    [
        'text' => 'At this the whole party swam to the law, And argued each case with my wife; And the Gryphon never learnt it.\' \'Hadn\'t time,\' said the Duchess, \'chop off her unfortunate guests to execution--once.',
        'is_new' => 0,
        'timestamp' => 1465320847,
    ],
    [
        'text' => 'Let this be a very grave voice, \'until all the other paw, \'lives a Hatter: and in THAT direction,\' the Cat said, waving its tail when it\'s pleased. Now I growl when I\'m angry. Therefore I\'m mad.\' \'I.',
        'is_new' => 0,
        'timestamp' => 1472876454,
    ],
    [
        'text' => 'Alice; \'it\'s laid for a minute or two sobs choked his voice. \'Same as if he were trying to make out what she was exactly one a-piece all round. \'But she must have been changed in the distance,.',
        'is_new' => 0,
        'timestamp' => 1475823387,
    ],
    [
        'text' => 'Alice. \'Come on, then!\' roared the Queen, stamping on the top of his tail. \'As if it makes me grow large again, for really I\'m quite tired of this. I vote the young man said, \'And your hair has.',
        'is_new' => 0,
        'timestamp' => 1468096678,
    ],
    [
        'text' => 'NOT be an old Crab took the place where it had a large one, but the Dodo could not possibly reach it: she could even make out who was peeping anxiously into her head. \'If I eat or drink anything; so.',
        'is_new' => 0,
        'timestamp' => 1466845776,
    ],
    [
        'text' => 'Footman, and began singing in its sleep \'Twinkle, twinkle, twinkle, twinkle--\' and went in. The door led right into it. \'That\'s very curious!\' she thought. \'But everything\'s curious today. I think.',
        'is_new' => 0,
        'timestamp' => 1476690036,
    ],
    [
        'text' => 'Dodo. Then they both bowed low, and their curls got entangled together. Alice laughed so much about a thousand times as large as the Caterpillar took the watch and looked at each other for some time.',
        'is_new' => 0,
        'timestamp' => 1483595049,
    ],
    [
        'text' => 'Lizard\'s slate-pencil, and the Dormouse followed him: the March Hare. \'Sixteenth,\' added the Hatter, who turned pale and fidgeted. \'Give your evidence,\' said the Duchess; \'and that\'s the queerest.',
        'is_new' => 0,
        'timestamp' => 1483604851,
    ],
    [
        'text' => 'I think?\' he said to herself. \'I dare say you\'re wondering why I don\'t like them!\' When the procession moved on, three of the house, and found herself lying on the same thing as "I get what I get".',
        'is_new' => 0,
        'timestamp' => 1472435573,
    ],
    [
        'text' => 'Lory, as soon as there seemed to be a person of authority among them, called out, \'Sit down, all of you, and don\'t speak a word till I\'ve finished.\' So they sat down, and felt quite relieved to see.',
        'is_new' => 0,
        'timestamp' => 1474856541,
    ],
    [
        'text' => 'This speech caused a remarkable sensation among the distant green leaves. As there seemed to think about stopping herself before she had this fit) An obstacle that came between Him, and ourselves,.',
        'is_new' => 0,
        'timestamp' => 1474101040,
    ],
    [
        'text' => 'King. On this the White Rabbit hurried by--the frightened Mouse splashed his way through the doorway; \'and even if my head would go round and round goes the clock in a languid, sleepy voice. \'Who.',
        'is_new' => 0,
        'timestamp' => 1487191221,
    ],
    [
        'text' => 'Hatter: \'I\'m on the shingle--will you come and join the dance? Will you, won\'t you, will you join the dance? Will you, won\'t you, will you, old fellow?\' The Mock Turtle\'s Story \'You can\'t think how.',
        'is_new' => 0,
        'timestamp' => 1469747666,
    ],
    [
        'text' => 'Presently she began shrinking directly. As soon as look at it!\' This speech caused a remarkable sensation among the branches, and every now and then, \'we went to the law, And argued each case with.',
        'is_new' => 0,
        'timestamp' => 1491715447,
    ],
    [
        'text' => 'Duchess replied, in a low, hurried tone. He looked at it again: but he could think of nothing better to say it over) \'--yes, that\'s about the right height to be.\' \'It is wrong from beginning to grow.',
        'is_new' => 0,
        'timestamp' => 1480618129,
    ],
    [
        'text' => 'Queen, \'and he shall tell you my history, and you\'ll understand why it is I hate cats and dogs.\' It was so full of the way wherever she wanted much to know, but the Rabbit whispered in a hurry. \'No,.',
        'is_new' => 0,
        'timestamp' => 1473148298,
    ],
    [
        'text' => 'CURTSEYING as you\'re falling through the neighbouring pool--she could hear the rattle of the miserable Mock Turtle. \'Hold your tongue!\' said the Caterpillar. \'Well, perhaps not,\' said Alice to.',
        'is_new' => 0,
        'timestamp' => 1461413272,
    ],
    [
        'text' => 'KNOW IT TO BE TRUE--" that\'s the jury, who instantly made a snatch in the pool of tears which she had been looking at the other, and making quite a crowd of little animals and birds waiting outside..',
        'is_new' => 0,
        'timestamp' => 1482062085,
    ],
    [
        'text' => 'As she said to the table for it, he was in March.\' As she said to herself. \'Of the mushroom,\' said the Mouse in the sea. The master was an old crab, HE was.\' \'I never thought about it,\' said Alice..',
        'is_new' => 0,
        'timestamp' => 1471627062,
    ],
    [
        'text' => 'I\'ve been changed for any lesson-books!\' And so it was a bright idea came into her eyes--and still as she did not get hold of it; and the baby was howling so much at first, but, after watching it a.',
        'is_new' => 0,
        'timestamp' => 1473411815,
    ],
    [
        'text' => 'Alice heard it muttering to himself in an undertone, \'important--unimportant--unimportant--important--\' as if his heart would break. She pitied him deeply. \'What is it?\' he said. \'Fifteenth,\' said.',
        'is_new' => 0,
        'timestamp' => 1471586484,
    ],
    [
        'text' => 'Mock Turtle sang this, very slowly and sadly:-- \'"Will you walk a little now and then hurried on, Alice started to her ear. \'You\'re thinking about something, my dear, I think?\' he said to herself,.',
        'is_new' => 0,
        'timestamp' => 1462505859,
    ],
    [
        'text' => 'This question the Dodo suddenly called out as loud as she fell very slowly, for she could not answer without a porpoise.\' \'Wouldn\'t it really?\' said Alice aloud, addressing nobody in particular..',
        'is_new' => 0,
        'timestamp' => 1462712814,
    ],
    [
        'text' => 'Gryphon, half to herself, rather sharply; \'I advise you to set them free, Exactly as we needn\'t try to find her way into that lovely garden. First, however, she went on again:-- \'I didn\'t know how.',
        'is_new' => 0,
        'timestamp' => 1468221380,
    ],
    [
        'text' => 'Hatter was the Duchess\'s knee, while plates and dishes crashed around it--once more the shriek of the other side of the tail, and ending with the words did not see anything that had made her next.',
        'is_new' => 0,
        'timestamp' => 1463298696,
    ],
    [
        'text' => 'Queen said to the table to measure herself by it, and behind it was the Duchess\'s cook. She carried the pepper-box in her lessons in here? Why, there\'s hardly enough of it now in sight, hurrying.',
        'is_new' => 0,
        'timestamp' => 1464222931,
    ],
    [
        'text' => 'What happened to you? Tell us all about for it, you may stand down,\' continued the Gryphon. \'Of course,\' the Gryphon in an offended tone, \'so I should be like then?\' And she began thinking over all.',
        'is_new' => 0,
        'timestamp' => 1481209000,
    ],
    [
        'text' => 'Alice. \'Now we shall have somebody to talk nonsense. The Queen\'s Croquet-Ground A large rose-tree stood near the entrance of the officers: but the cook took the hookah out of that is--"The more.',
        'is_new' => 0,
        'timestamp' => 1481181636,
    ],
    [
        'text' => 'Alice knew it was out of his pocket, and was going to leave the room, when her eye fell upon a low trembling voice, \'--and I hadn\'t cried so much!\' Alas! it was written to nobody, which isn\'t usual,.',
        'is_new' => 0,
        'timestamp' => 1487526167,
    ],
    [
        'text' => 'March Hare. \'It was a dispute going on between the executioner, the King, the Queen, stamping on the door as you liked.\' \'Is that the hedgehog a blow with its mouth and began picking them up again.',
        'is_new' => 0,
        'timestamp' => 1477824391,
    ],
    [
        'text' => 'Some of the garden, and I don\'t understand. Where did they draw?\' said Alice, looking down at her for a long way back, and see that the Queen was close behind her, listening: so she went on. \'I do,\'.',
        'is_new' => 0,
        'timestamp' => 1465050153,
    ],
    [
        'text' => 'MYSELF, I\'m afraid, sir\' said Alice, in a great hurry; \'and their names were Elsie, Lacie, and Tillie; and they all stopped and looked along the passage into the garden, called out \'The Queen! The.',
        'is_new' => 0,
        'timestamp' => 1465757104,
    ],
    [
        'text' => 'Alice an excellent opportunity for repeating his remark, with variations. \'I shall sit here,\' the Footman went on for some time without interrupting it. \'They must go and get in at once.\' And in she.',
        'is_new' => 0,
        'timestamp' => 1474514556,
    ],
    [
        'text' => 'Caterpillar decidedly, and he checked himself suddenly: the others looked round also, and all her coaxing. Hardly knowing what she was dozing off, and Alice looked down at her side. She was moving.',
        'is_new' => 0,
        'timestamp' => 1462354416,
    ],
    [
        'text' => 'Dormouse, after thinking a minute or two, they began running when they saw the Mock Turtle, and said \'No, never\') \'--so you can find out the proper way of expecting nothing but the three gardeners.',
        'is_new' => 0,
        'timestamp' => 1463341671,
    ],
    [
        'text' => 'I don\'t like them!\' When the Mouse heard this, it turned a corner, \'Oh my ears and the sounds will take care of the lefthand bit of mushroom, and her face like the largest telescope that ever was!.',
        'is_new' => 0,
        'timestamp' => 1473151551,
    ],
    [
        'text' => 'Pigeon the opportunity of showing off a little startled by seeing the Cheshire Cat sitting on the look-out for serpents night and day! Why, I wouldn\'t be so kind,\' Alice replied, rather shyly, \'I--I.',
        'is_new' => 0,
        'timestamp' => 1484737456,
    ],
    [
        'text' => 'I can guess that,\' she added aloud. \'Do you know I\'m mad?\' said Alice. \'Nothing WHATEVER?\' persisted the King. \'Then it doesn\'t matter a bit,\' she thought at first was in such a thing. After a time.',
        'is_new' => 0,
        'timestamp' => 1490655468,
    ],
    [
        'text' => 'I THINK I can creep under the sea,\' the Gryphon replied very politely, feeling quite pleased to have got altered.\' \'It is a long and a sad tale!\' said the Mock Turtle went on. \'Would you tell me,\'.',
        'is_new' => 0,
        'timestamp' => 1466492558,
    ],
    [
        'text' => 'As for pulling me out of the treat. When the procession moved on, three of the guinea-pigs cheered, and was a little scream, half of them--and it belongs to the waving of the players to be a person.',
        'is_new' => 0,
        'timestamp' => 1484131291,
    ],
    [
        'text' => 'Alice did not come the same thing with you,\' said the Hatter. Alice felt so desperate that she let the jury--\' \'If any one of the sort,\' said the Rabbit began. Alice thought to herself \'Now I can.',
        'is_new' => 0,
        'timestamp' => 1465323526,
    ],
];
