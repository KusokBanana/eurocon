<?php

/* main.twig */
class __TwigTemplate_aeb87e70dbb9ec5763a7d3bef341ff5a43414d78184a486435a58c55d68c57eb extends yii\twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->env->getExtension('yii\twig\Extension')->addUses("yii/bootstrap/Nav");
        echo "
";
        // line 2
        $this->env->getExtension('yii\twig\Extension')->addUses("yii/bootstrap/NavBar");
        echo "

";
        // line 4
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('void')->getCallable(), array($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "beginPage", array(), "method"))), "html", null, true);
        echo "
<!DOCTYPE html>
<html lang=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["app"]) ? $context["app"] : null), "language", array()), "html", null, true);
        echo "\">
<head>
    <meta charset=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["app"]) ? $context["app"] : null), "charset", array()), "html", null, true);
        echo "\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["html"]) ? $context["html"] : null), "encode", array(0 => $this->getAttribute((isset($context["this"]) ? $context["this"] : null), "title", array())), "method"), "html", null, true);
        echo "</title>
    ";
        // line 11
        echo $this->getAttribute((isset($context["html"]) ? $context["html"] : null), "csrfMetaTags", array());
        echo "
    ";
        // line 12
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('void')->getCallable(), array($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "head", array()))), "html", null, true);
        echo "
</head>
<body>
";
        // line 15
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('void')->getCallable(), array($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "beginBody", array(), "method"))), "html", null, true);
        echo "
<div class=\"wrap\">
    ";
        // line 17
        $this->env->getExtension('yii\twig\Extension')->beginWidget("nav_bar", array("brandLabel" => "Yii2-SimpleChat", "brandUrl" => "", "options" => array("class" => "navbar-inverse navbar-fixed-top")));
        // line 23
        echo "
    ";
        // line 24
        $context["menuItems"] = array();
        // line 25
        echo "    ";
        $context["menuItems"] = twig_array_merge((isset($context["menuItems"]) ? $context["menuItems"] : null), array(0 => array("label" => ("Hi, " . $this->getAttribute($this->getAttribute($this->getAttribute(        // line 27
(isset($context["this"]) ? $context["this"] : null), "params", array()), "user", array()), "name", array())), "items" => twig_array_merge(array(0 => array("label" => "Log in as")), $this->getAttribute($this->getAttribute(        // line 28
(isset($context["this"]) ? $context["this"] : null), "params", array()), "users", array())))));
        // line 31
        echo "    ";
        echo $this->env->getExtension('yii\twig\Extension')->widget("nav", array("options" => array("class" => "navbar-nav navbar-right"), "items" =>         // line 35
(isset($context["menuItems"]) ? $context["menuItems"] : null)));
        // line 36
        echo "
    ";
        // line 37
        $this->env->getExtension('yii\twig\Extension')->endWidget("nav_bar");
        echo "
    <div class=\"container\">
        ";
        // line 39
        echo (isset($context["content"]) ? $context["content"] : null);
        echo "
    </div>
</div>
<footer class=\"footer\">
    <div class=\"container\">
        <p class=\"pull-left\">&copy; bubasuma 2015-2016</p>
        <p class=\"pull-right\"><a href=\"https://github.com/bubasuma/yii2-simplechat\">yii2-simplechat</a></p>
    </div>
</footer>
";
        // line 48
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('void')->getCallable(), array($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "endBody", array(), "method"))), "html", null, true);
        echo "
</body>
</html>
";
        // line 51
        echo twig_escape_filter($this->env, call_user_func_array($this->env->getFunction('void')->getCallable(), array($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "endPage", array(), "method"))), "html", null, true);
    }

    public function getTemplateName()
    {
        return "main.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  104 => 51,  98 => 48,  86 => 39,  81 => 37,  78 => 36,  76 => 35,  74 => 31,  72 => 28,  71 => 27,  69 => 25,  67 => 24,  64 => 23,  62 => 17,  57 => 15,  51 => 12,  47 => 11,  43 => 10,  38 => 8,  33 => 6,  28 => 4,  23 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "main.twig", "B:\\xampp\\htdocs\\eurocon\\vendor\\bubasuma\\yii2-simplechat\\views\\layouts\\main.twig");
    }
}
