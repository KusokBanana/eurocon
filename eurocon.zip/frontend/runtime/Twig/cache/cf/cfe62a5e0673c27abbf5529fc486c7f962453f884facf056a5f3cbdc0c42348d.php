<?php

/* message.twig */
class __TwigTemplate_4749d7145be87475f93f951c5b71cebd4bbcc011164ac2f6b66245f05a830197 extends yii\twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"media ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "itemCssClass", array()), "html", null, true);
        echo "\" data-key=\"";
        echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
        echo "\">
    <a class=\"pull-left\" href=\"#\">
        <img class=\"media-object\"  alt=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sender"]) ? $context["sender"] : null), "name", array()), "html", null, true);
        echo "\" style=\"width: 32px; height: 32px;\" src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "baseUrl", array()), "html", null, true);
        echo "/img/avatars/";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sender"]) ? $context["sender"] : null), "avatar", array()), "html", null, true);
        echo "\"/>
    </a>
    <div class=\"media-body\">
        <small class=\"pull-right time\"><i class=\"fa fa-clock-o\"></i> ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "date", array()), "html", null, true);
        echo "</small>
        <h5 class=\"media-heading\">";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["sender"]) ? $context["sender"] : null), "name", array()), "html", null, true);
        echo "</h5>
        <small class=\"col-lg-10\">";
        // line 8
        echo $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "text", array());
        echo "</small>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "message.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  41 => 7,  37 => 6,  27 => 3,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "message.twig", "B:\\xampp\\htdocs\\eurocon\\vendor\\bubasuma\\yii2-simplechat\\assets\\tmpl\\message.twig");
    }
}
