<?php

/* form.twig */
class __TwigTemplate_8956990f97ab0c4ac41d2df6a3b81d771cdb2670d1520cc5142d29d612502299 extends yii\twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo $this->getAttribute((isset($context["html"]) ? $context["html"] : null), "beginForm", array(0 => "", 1 => "post", 2 => array("id" => "msg-form")), "method");
        echo "
<textarea class=\"form-control send-message\" name=\"text\" rows=\"3\" placeholder=\"Write a reply...\"></textarea>
";
        // line 3
        echo $this->getAttribute((isset($context["html"]) ? $context["html"] : null), "endForm", array(), "method");
    }

    public function getTemplateName()
    {
        return "form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  24 => 3,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "form.twig", "B:\\xampp\\htdocs\\eurocon\\vendor\\bubasuma\\yii2-simplechat\\views\\default\\form.twig");
    }
}
