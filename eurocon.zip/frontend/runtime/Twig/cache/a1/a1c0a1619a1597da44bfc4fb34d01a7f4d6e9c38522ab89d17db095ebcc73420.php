<?php

/* index.twig */
class __TwigTemplate_d7944ec7da29183f6ea57b39efc0122e872c48c8fc71266df07d31af58a4cc72 extends yii\twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->env->getExtension('yii\twig\Extension')->addUses("bubasuma/simplechat/ConversationWidget");
        echo "
";
        // line 2
        $this->env->getExtension('yii\twig\Extension')->addUses("bubasuma/simplechat/MessageWidget");
        echo "

";
        // line 4
        $context["asset"] = $this->env->getExtension('yii\twig\Extension')->registerAssetBundle($context, "bubasuma/simplechat/ChatAsset", true);
        // line 5
        echo "
";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('yii\twig\Extension')->setProperty((isset($context["this"]) ? $context["this"] : null), "params", twig_array_merge($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "params", array()), array("user" => (isset($context["user"]) ? $context["user"] : null)))), "html", null, true);
        echo "
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('yii\twig\Extension')->setProperty((isset($context["this"]) ? $context["this"] : null), "params", twig_array_merge($this->getAttribute((isset($context["this"]) ? $context["this"] : null), "params", array()), array("users" => (isset($context["users"]) ? $context["users"] : null)))), "html", null, true);
        echo "

<div class=\"row\">
    <div class=\"loading\" style=\"display: none\">Loading&#8230;</div>
    ";
        // line 11
        $context["conversation"] = $this->env->getExtension('yii\twig\Extension')->beginWidget("conversation_widget", array("dataProvider" =>         // line 12
(isset($context["conversationDataProvider"]) ? $context["conversationDataProvider"] : null), "itemView" => ($this->getAttribute(        // line 13
(isset($context["asset"]) ? $context["asset"] : null), "sourcePath", array()) . "/tmpl/conversation.twig"), "options" => array("class" => "conversation-wrap col-lg-3", "id" => "conversations"), "user" =>         // line 18
(isset($context["user"]) ? $context["user"] : null), "current" =>         // line 19
(isset($context["current"]) ? $context["current"] : null), "clientOptions" => array("loadUrl" => $this->env->getExtension('yii\twig\Extension')->path(array(0 => "conversations")), "baseUrl" => $this->getAttribute(        // line 22
(isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()), "templateUrl" => ($this->getAttribute(        // line 23
(isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()) . "/tmpl/conversation.twig"), "itemCssClass" => "conversation", "currentCssClass" => "current", "unreadCssClass" => "unread")));
        // line 30
        echo "    ";
        echo $this->getAttribute((isset($context["conversation"]) ? $context["conversation"] : null), "renderItems", array());
        echo "
    <div id=\"conversations-loader\" style=\"display: none\" class=\"text-center\">
        <img alt=\"Loading...\" src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()), "html", null, true);
        echo "/img/inf-square-loader.gif\"/>
    </div>
    ";
        // line 34
        $this->env->getExtension('yii\twig\Extension')->endWidget("conversation_widget");
        echo "
    ";
        // line 35
        $context["message"] = $this->env->getExtension('yii\twig\Extension')->beginWidget("message_widget", array("dataProvider" =>         // line 36
(isset($context["messageDataProvider"]) ? $context["messageDataProvider"] : null), "itemView" => ($this->getAttribute(        // line 37
(isset($context["asset"]) ? $context["asset"] : null), "sourcePath", array()) . "/tmpl/message.twig"), "formView" => ($this->getAttribute($this->getAttribute(        // line 38
(isset($context["this"]) ? $context["this"] : null), "context", array()), "viewPath", array()) . "/form.twig"), "user" =>         // line 39
(isset($context["user"]) ? $context["user"] : null), "contact" =>         // line 40
(isset($context["contact"]) ? $context["contact"] : null), "options" => array("class" => "message-wrap col-lg-8", "id" => "messenger"), "clientOptions" => array("loadUrl" => $this->getAttribute(        // line 46
(isset($context["current"]) ? $context["current"] : null), "loadUrl", array()), "sendUrl" => $this->getAttribute(        // line 47
(isset($context["current"]) ? $context["current"] : null), "sendUrl", array()), "sendMethod" => "post", "templateUrl" => ($this->getAttribute(        // line 49
(isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()) . "/tmpl/message.twig"), "baseUrl" => $this->getAttribute(        // line 50
(isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()), "container" => "#msg-container", "form" => "#msg-form", "itemCssClass" => "msg")));
        // line 57
        echo "    <div id=\"msg-container\" class=\"msg-wrap\">
        <div id=\"messages-loader\" style=\"display: none\" class=\"text-center\">
            <img alt=\"Loading...\" src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["asset"]) ? $context["asset"] : null), "baseUrl", array()), "html", null, true);
        echo "/img/inf-circle-loader.gif\"/>
        </div>
        ";
        // line 61
        $context["models"] = $this->getAttribute($this->getAttribute((isset($context["message"]) ? $context["message"] : null), "dataProvider", array()), "models", array());
        // line 62
        echo "        ";
        $context["keys"] = $this->getAttribute($this->getAttribute((isset($context["message"]) ? $context["message"] : null), "dataProvider", array()), "keys", array());
        // line 63
        echo "        ";
        $context["rows"] = array();
        // line 64
        echo "        ";
        $context["when"] = false;
        // line 65
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_reverse_filter($this->env, (isset($context["models"]) ? $context["models"] : null), true));
        foreach ($context['_seq'] as $context["index"] => $context["model"]) {
            // line 66
            echo "            ";
            if (((isset($context["when"]) ? $context["when"] : null) != $this->getAttribute($context["model"], "when", array()))) {
                // line 67
                echo "                ";
                $context["when"] = $this->getAttribute($context["model"], "when", array());
                // line 68
                echo "                ";
                $context["rows"] = twig_array_merge((isset($context["rows"]) ? $context["rows"] : null), array(0 => $this->getAttribute((isset($context["html"]) ? $context["html"] : null), "tag", array(0 => "div", 1 => (("<strong>" . (isset($context["when"]) ? $context["when"] : null)) . "</strong>"), 2 => array("class" => "alert alert-info msg-date")), "method")));
                // line 69
                echo "            ";
            }
            // line 70
            echo "            ";
            $context["rows"] = twig_array_merge((isset($context["rows"]) ? $context["rows"] : null), array(0 => $this->getAttribute((isset($context["message"]) ? $context["message"] : null), "renderItem", array(0 => $context["model"], 1 => $this->getAttribute((isset($context["keys"]) ? $context["keys"] : null), $context["index"], array(), "array"), 2 => $context["index"]), "method")));
            // line 71
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['index'], $context['model'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 72
        echo "        ";
        echo twig_join_filter((isset($context["rows"]) ? $context["rows"] : null), $this->getAttribute((isset($context["message"]) ? $context["message"] : null), "separator", array()));
        echo "
    </div>

    <div class=\"send-wrap \">
        ";
        // line 76
        echo $this->getAttribute((isset($context["message"]) ? $context["message"] : null), "renderForm", array());
        echo "
    </div>
    <div class=\"btn-panel\">
        <a id=\"msg-send\" href=\"\" class=\" col-lg-4 text-right btn   send-message-btn pull-right\" role=\"button\">
            <i class=\"fa fa-location-arrow\"></i>
            Send Message
        </a>
    </div>
    ";
        // line 84
        $this->env->getExtension('yii\twig\Extension')->endWidget("message_widget");
        echo "
</div>";
    }

    public function getTemplateName()
    {
        return "index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 84,  132 => 76,  124 => 72,  118 => 71,  115 => 70,  112 => 69,  109 => 68,  106 => 67,  103 => 66,  98 => 65,  95 => 64,  92 => 63,  89 => 62,  87 => 61,  82 => 59,  78 => 57,  76 => 50,  75 => 49,  74 => 47,  73 => 46,  72 => 40,  71 => 39,  70 => 38,  69 => 37,  68 => 36,  67 => 35,  63 => 34,  58 => 32,  52 => 30,  50 => 23,  49 => 22,  48 => 19,  47 => 18,  46 => 13,  45 => 12,  44 => 11,  37 => 7,  33 => 6,  30 => 5,  28 => 4,  23 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "index.twig", "B:\\xampp\\htdocs\\eurocon\\vendor\\bubasuma\\yii2-simplechat\\views\\default\\index.twig");
    }
}
