<?php

/* conversation.twig */
class __TwigTemplate_8f38cdcd3ff802f03f5a0cf386d65b27432e43df3806e71f101ad006d24dbb27 extends yii\twig\Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"media ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "itemCssClass", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "newMessages", array()), "count", array()) > 0)) ? ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "unreadCssClass", array())) : ("")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (((isset($context["isCurrent"]) ? $context["isCurrent"] : null)) ? ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "currentCssClass", array())) : ("")), "html", null, true);
        echo "\"
     data-key=\"";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["key"]) ? $context["key"] : null), "html", null, true);
        echo "\" data-contact=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array()), "id", array()), "html", null, true);
        echo "\" data-contactinfo=\"";
        echo twig_escape_filter($this->env, twig_jsonencode_filter($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array())));
        echo "\"
     data-unreadurl=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "unreadUrl", array()), "html", null, true);
        echo "\" data-readurl=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "readUrl", array()), "html", null, true);
        echo "\" data-deleteurl=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "deleteUrl", array()), "html", null, true);
        echo "\"
     data-loadurl=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "loadUrl", array()), "html", null, true);
        echo "\" data-sendurl=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["model"]) ? $context["model"] : null), "sendUrl", array()), "html", null, true);
        echo "\">
    <a class=\"pull-left\" href=\"#\">
        <img class=\"media-object\" alt=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array()), "name", array()), "html", null, true);
        echo "\" style=\"width: 50px; height: 50px;\" src=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "baseUrl", array()), "html", null, true);
        echo "/img/avatars/";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array()), "avatar", array()), "html", null, true);
        echo "\"/>
    </a>
    <div class=\"media-body\">
        <small class=\"pull-right time\"> ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "lastMessage", array()), "date", array()), "html", null, true);
        echo "</small>
        <h5 class=\"media-heading\">";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array()), "name", array()), "html", null, true);
        echo "</h5>
        <small>";
        // line 11
        echo ((($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "contact", array()), "id", array()) != $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "lastMessage", array()), "senderId", array()))) ? ("<i class=\"fa fa-reply\"></i>") : (""));
        echo " ";
        echo $this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "lastMessage", array()), "text", array());
        echo "</small>
        <span class=\"badge pull-right msg-new\">";
        // line 12
        echo twig_escape_filter($this->env, ((($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "newMessages", array()), "count", array()) > 0)) ? ($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "newMessages", array()), "count", array())) : ("")), "html", null, true);
        echo "</span>
        <ul class=\"pull-right list-inline\">
            <li><a class=\"close\" title=\"Mark as ";
        // line 14
        echo ((($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "newMessages", array()), "count", array()) > 0)) ? ("read") : ("unread"));
        echo "\"><small class=\"small-icon\" aria-hidden=\"true\"><i class=\"fa fa-circle";
        echo ((($this->getAttribute($this->getAttribute((isset($context["model"]) ? $context["model"] : null), "newMessages", array()), "count", array()) > 0)) ? ("") : ("-o"));
        echo "\"></i></small></a></li>
            <li><a class=\"close\" title=\"Archive\"><small class=\"small-icon\" aria-hidden=\"true\"><i class=\"fa fa-times\"></i></small></a></li>
        </ul>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "conversation.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 14,  75 => 12,  69 => 11,  65 => 10,  61 => 9,  51 => 6,  44 => 4,  36 => 3,  28 => 2,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "conversation.twig", "B:\\xampp\\htdocs\\eurocon\\vendor\\bubasuma\\yii2-simplechat\\assets\\tmpl\\conversation.twig");
    }
}
